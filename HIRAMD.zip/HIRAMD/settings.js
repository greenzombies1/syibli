//base by DGXeon
//recode by Always Ziyoo
//YouTube: @Ziyo232
//Telegram: t.me/ziyooffc

/* ● Always Ziyoo ( Andre ) di remehkan?? Tentu ini bukan Ancaman ! */

const fs = require('fs')
const chalk = require('chalk')

//owmner v card
global.ytname = "YT: Syibli sticker WhatsApp" //ur yt chanel name
global.socialm = "IG : syibli sticker WhatsApp" //ur github or insta name
global.location = "Indonesia" //ur location

global.botname = 'Syibli Sticker WhatsApp' // ur bot name
global.ownernumber = '6281239636296' // ur owner number
global.ownername = '©Syibli Sticker WhatsApp' // ur owner name
global.websitex = "https://whatsapp.com/channel/0029VawlozV3mFYBBz1HJz45" // updated link
global.wagc = "https://chat.whatsapp.com/BQurR9HHXZ31RoGJv1Is0A" // updated link
global.themeemoji = '🪀'
global.wm = "Syibli Sticker WhatsApp"
global.botscript = 'https://whatsapp.com/channel/0029VawlozV3mFYBBz1HJz45' // updated link
global.packname = "saluran WhatsApp"
global.author = "syibli sticker WhatsApp"
global.creator = "6283123448708@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["6283123448708"] // Premium User
global.hituet = 0

//bot sett
global.typemenu = 'v1' // menu type 'v1' => 'v8'
global.typereply = 'v1' // reply type 'v1' => 'v3'
global.autoblocknumber = '' //set autoblock country code
global.antiforeignnumber = '' //set anti foreign number country code
global.welcome = false //welcome/left in groups
global.anticall = true //bot blocks user when called
global.autoswview = true //auto status/story view
global.adminevent = false //show promote/demote message
global.groupevent = false //show update messages in group chat
//msg
global.mess = {
	limit: 'Your limit is up <\>',
	nsfw: '*Nsfw dimatikan di grup ini, beritahu admin agar fiturnya dinyalakan*',
    done: '*Done ✓*',
    error: '*Error !*',
    success: '*Succes*'
}
//thumbnail
global.thumb = fs.readFileSync('./XeonMedia/theme/cheemspic.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})