const { proto, delay, getContentType } = require('@adiwajshing/baileys')
const chalk = require('chalk')
const fs = require('fs')
const Crypto = require('crypto')
const axios = require('axios')

exports.smsg = (client, m, store) => {
    if (!m) return m

    const M = proto.WebMessageInfo

    if (m.key) {
        m.id = m.key.id
        m.isBaileys = m.id?.startsWith?.('BAE5') && m.id.length === 16
        m.chat = m.key.remoteJid
        m.fromMe = m.key.fromMe
        m.isGroup = m.chat.endsWith('@g.us')
        m.sender = client.decodeJid(
            m.fromMe && client.user?.id || 
            m.participant || 
            m.key.participant || 
            m.chat || ''
        )
        if (m.isGroup) {
            m.participant = client.decodeJid(m.key.participant || '') || ''
        }
    }

    if (m.message) {
    m.mtype = getContentType(m.message)
    if (m.mtype === 'viewOnceMessage') {
        const innerMsg = m.message[m.mtype]?.message
        const innerType = getContentType(innerMsg)
        m.msg = innerMsg?.[innerType] || {}
    } else {
        m.msg = m.message[m.mtype] || {}
    }

    m.body = (() => {
    try {
        if (!m.msg) return m.message?.conversation || m.text || ''
        if (m.mtype === 'listResponseMessage') return m.msg?.singleSelectReply?.selectedRowId || ''
        if (m.mtype === 'buttonsResponseMessage') return m.msg?.selectedButtonId || ''
        if (m.mtype === 'viewOnceMessage') return m.msg?.caption || ''
        return m.message?.conversation || m.msg?.caption || m.msg?.text || m.text || ''
    } catch (e) {
        return m.text || ''
    }
})()

        let quoted = m.quoted = m.msg?.contextInfo?.quotedMessage || null
        m.mentionedJid = m.msg?.contextInfo?.mentionedJid || []

        if (m.quoted) {
            let type = getContentType(m.quoted)
            m.quoted = m.quoted[type]

            if (['productMessage'].includes(type)) {
                type = getContentType(m.quoted)
                m.quoted = m.quoted[type]
            }

            if (typeof m.quoted === 'string') {
                m.quoted = { text: m.quoted }
            }

            m.quoted.mtype = type
            m.quoted.id = m.msg?.contextInfo?.stanzaId
            m.quoted.chat = m.msg?.contextInfo?.remoteJid || m.chat
            m.quoted.isBaileys = m.quoted.id?.startsWith?.('BAE5') && m.quoted.id.length === 16
            m.quoted.sender = client.decodeJid(m.msg?.contextInfo?.participant || '')
            m.quoted.fromMe = m.quoted.sender === client.user?.id
            m.quoted.text = m.quoted.text || 
                            m.quoted.caption || 
                            m.quoted.conversation || 
                            m.quoted.contentText || 
                            m.quoted.selectedDisplayText || 
                            m.quoted.title || ''
            m.quoted.mentionedJid = m.msg?.contextInfo?.mentionedJid || []

            m.getQuotedObj = m.getQuotedMessage = async () => {
                if (!m.quoted.id) return false
                let q = await store.loadMessage(m.chat, m.quoted.id, client)
                return exports.smsg(client, q, store)
            }

            let vM = m.quoted.fakeObj = M.fromObject({
                key: {
                    remoteJid: m.quoted.chat,
                    fromMe: m.quoted.fromMe,
                    id: m.quoted.id
                },
                message: quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {})
            })

            m.quoted.delete = () => client.sendMessage(m.quoted.chat, { delete: vM.key })
            m.quoted.download = () => client.downloadMediaMessage(m.quoted)
        }
    }

    if (m.msg?.url) {
        m.download = () => client.downloadMediaMessage(m.msg)
    }

    m.text = m.msg?.text || 
             m.msg?.caption || 
             m.message?.conversation || 
             m.msg?.contentText || 
             m.msg?.selectedDisplayText || 
             m.msg?.title || ''

    return m
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})