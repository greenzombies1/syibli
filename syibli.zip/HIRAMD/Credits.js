// Kalo mau Ambil Code Atau recode Boleh aja Tapi izin dulu kontol
// Sell sc 34k - 57k No Rip Deck gw enc ni No jual murah Jangan lupa komen Stor kalo balik modal

/* Reupload Atau Review Bot 
 * 1. Tag me @Ziyo232
 * 2. Tambahkan Saya ke Credits Kalo bisa
 *\
 
/* Thanks To
> Xeon ( Base / Creator )
> Always Ziyoo ( Saya :v / Add Fitur / Recode )
> Always Kyuu ( KyuuDev / Add Fitur )
> Subscriber ( Supporter )
> Whiskeysockets ( Baileys )
> All Creator Bot Whatsapp ( Creator / kang recode )
> 1 orang ga di kenal ( Tester )
> YASSxOFFC ( Teman Yg Kasih Base / Sc )
> Jarz ( Temen / Recode Bug )

[ AlwaysZiyoo From Always Compact ] */

/*         Sedikit Info        */
// Sepertinya sc Support termux Soalnya Di panel Cuman 100 mb an module nya
// McLareN lo warna apa bos :v
// +62